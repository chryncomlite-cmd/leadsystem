"use client";
import { useEffect, useState } from "react";
import { ErrorBanner, Field } from "./ui";
import { errText } from "@/lib/api";
import { STATUSES, type Lead, type LeadStatus } from "@/lib/types";

export interface LeadChanges {
  client_name?: string;
  phone?: string;
  email?: string | null;
  notes?: string | null;
  status?: LeadStatus;
}

/** Edit form shared by employees and managers. Sends only the fields that changed. */
export function LeadEditor({
  lead,
  onSave,
}: {
  lead: Pick<Lead, "client_name" | "phone" | "email" | "notes" | "status" | "version">;
  onSave: (changes: LeadChanges, version: number) => Promise<void>;
}) {
  const [f, setF] = useState(() => init(lead));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // A newer version arrived (after save, reload, or a conflict): reset the form.
  useEffect(() => {
    setF(init(lead));
    setError(null);
  }, [lead.version]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setF((x) => ({ ...x, [k]: e.target.value }));

  const changes: LeadChanges = {};
  if (f.client_name.trim() !== lead.client_name) changes.client_name = f.client_name.trim();
  if (f.phone.trim() !== lead.phone) changes.phone = f.phone.trim();
  if (f.email.trim() !== (lead.email ?? "")) changes.email = f.email.trim() || null;
  if (f.notes.trim() !== (lead.notes ?? "").trim()) changes.notes = f.notes.trim() || null;
  if (f.status !== lead.status) changes.status = f.status;
  const dirty = Object.keys(changes).length > 0;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!dirty) return;
    setBusy(true);
    setError(null);
    try {
      await onSave(changes, lead.version);
    } catch (err) {
      setError(errText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <ErrorBanner message={error} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Client name">
          <input className="input" required maxLength={120} value={f.client_name} onChange={set("client_name")} />
        </Field>
        <Field label="Phone">
          <input className="input" required inputMode="tel" value={f.phone} onChange={set("phone")} />
        </Field>
        <Field label="Email">
          <input className="input" type="email" value={f.email} onChange={set("email")} />
        </Field>
        <Field label="Status">
          <select className="input" value={f.status} onChange={set("status")}>
            {STATUSES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </Field>
      </div>
      <Field label="Notes">
        <textarea className="input min-h-[90px]" maxLength={4000} value={f.notes} onChange={set("notes")} />
      </Field>
      <div className="flex justify-end">
        <button className="btn-primary" disabled={!dirty || busy}>
          {busy ? "Saving..." : "Save changes"}
        </button>
      </div>
    </form>
  );
}

function init(l: Pick<Lead, "client_name" | "phone" | "email" | "notes" | "status">) {
  return {
    client_name: l.client_name,
    phone: l.phone,
    email: l.email ?? "",
    notes: l.notes ?? "",
    status: l.status,
  };
}

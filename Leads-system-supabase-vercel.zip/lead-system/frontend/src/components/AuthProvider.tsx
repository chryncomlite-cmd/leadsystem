"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import type { Role, User } from "@/lib/types";

interface AuthCtx {
  /** undefined = still checking, null = signed out */
  user: User | null | undefined;
  login: (email: string, password: string) => Promise<User>;
  logout: () => Promise<void>;
}
const Ctx = createContext<AuthCtx | null>(null);

export const homeFor = (role: Role) => (role === "SYSTEM_MANAGER" ? "/admin" : "/dashboard");

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  const router = useRouter();

  useEffect(() => {
    api<User>("/api/auth/me", { quiet: true })
      .then(setUser)
      .catch(() => setUser(null));
  }, []);

  // Any 401 from a later request means the session ended (expired, revoked,
  // deactivated, signed out elsewhere).
  useEffect(() => {
    const onExpired = () => {
      setUser(null);
      router.replace("/login");
    };
    window.addEventListener("auth:expired", onExpired);
    return () => window.removeEventListener("auth:expired", onExpired);
  }, [router]);

  // Sliding session: the API issues 30-minute tokens (12 h absolute cap).
  const signedIn = !!user;
  useEffect(() => {
    if (!signedIn) return;
    const t = setInterval(
      () => api<User>("/api/auth/refresh", { method: "POST", quiet: true }).catch(() => {}),
      10 * 60 * 1000,
    );
    return () => clearInterval(t);
  }, [signedIn]);

  const login = useCallback(async (email: string, password: string) => {
    const u = await api<User>("/api/auth/login", {
      method: "POST",
      body: { email, password },
      quiet: true,
    });
    setUser(u);
    return u;
  }, []);

  const logout = useCallback(async () => {
    try {
      await api("/api/auth/logout", { method: "POST", quiet: true });
    } finally {
      setUser(null);
      router.replace("/login");
    }
  }, [router]);

  const value = useMemo(() => ({ user, login, logout }), [user, login, logout]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth outside AuthProvider");
  return c;
}

"use client";
import { useCallback, useEffect, useState } from "react";
import { ActivityLog } from "@/components/ActivityLog";
import { LeadEditor, type LeadChanges } from "@/components/LeadEditor";
import { ErrorBanner, Modal, StatusBadge, useToast } from "@/components/ui";
import { api, ApiError, errText } from "@/lib/api";
import { fmtDateTime, formatRemaining } from "@/lib/format";
import type { Activity, Lead } from "@/lib/types";

export function LeadModal({
  leadId,
  deadline,
  now,
  onClose,
  onChanged,
}: {
  leadId: string;
  deadline: number;
  now: number;
  onClose: () => void;
  onChanged: () => void;
}) {
  const toast = useToast();
  const [lead, setLead] = useState<Lead | null>(null);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [l, a] = await Promise.all([
        api<Lead>(`/api/leads/${leadId}`),
        api<Activity[]>(`/api/leads/${leadId}/activities`),
      ]);
      setLead(l);
      setActivities(a);
    } catch (e) {
      if (e instanceof ApiError && e.status === 404) {
        toast("That client is no longer on your list.");
        onChanged();
        onClose();
      } else setError(errText(e));
    }
  }, [leadId, onChanged, onClose, toast]);
  useEffect(() => {
    load();
  }, [load]);

  async function save(changes: LeadChanges, version: number) {
    try {
      const updated = await api<Lead>(`/api/leads/${leadId}`, { method: "PATCH", body: { ...changes, version } });
      setLead(updated);
      toast("Saved.");
      onChanged();
      load();
    } catch (e) {
      if (e instanceof ApiError && e.code === "VERSION_CONFLICT") await load();
      throw e;
    }
  }

  async function addActivity(kind: "NOTE" | "CALL", body: string) {
    await api(`/api/leads/${leadId}/activities`, { method: "POST", body: { kind, body } });
    setActivities(await api<Activity[]>(`/api/leads/${leadId}/activities`));
  }

  return (
    <Modal title={lead?.client_name ?? "Client"} onClose={onClose} wide>
      <div className="space-y-5">
        <ErrorBanner message={error} />
        {lead && (
          <>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-600">
              <StatusBadge status={lead.status} />
              <span>
                Time left: <b className="text-slate-900">{formatRemaining(deadline - now)}</b>
              </span>
              <span>Entered {fmtDateTime(lead.entered_at)}</span>
              <span>Ends {fmtDateTime(lead.expires_at)}</span>
            </div>
            <LeadEditor lead={lead} onSave={save} />
            <hr />
            <ActivityLog items={activities} onAdd={addActivity} />
          </>
        )}
      </div>
    </Modal>
  );
}

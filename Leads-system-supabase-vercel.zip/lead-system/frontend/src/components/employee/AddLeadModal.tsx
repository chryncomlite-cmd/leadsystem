"use client";
import { useState } from "react";
import { ErrorBanner, Field, Modal, useToast } from "@/components/ui";
import { api, errText } from "@/lib/api";
import type { LeadCreated } from "@/lib/types";

export function AddLeadModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ client_name: "", phone: "", email: "", notes: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setF((x) => ({ ...x, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const lead = await api<LeadCreated>("/api/leads", {
        method: "POST",
        body: { ...f, email: f.email.trim() || null, notes: f.notes.trim() || null },
      });
      toast(
        lead.source === "CLAIMED"
          ? "This client was in the expired pool, so it's yours now with a fresh 21 days."
          : "Client added. You have 21 days.",
      );
      onCreated();
      onClose();
    } catch (err) {
      setError(errText(err));
      setBusy(false);
    }
  }

  return (
    <Modal title="Add a client" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <ErrorBanner message={error} />
        <Field label="Client name">
          <input className="input" required autoFocus maxLength={120} value={f.client_name} onChange={set("client_name")} />
        </Field>
        <Field label="Phone" hint="Local numbers like 0700 000 001 work.">
          <input className="input" required inputMode="tel" value={f.phone} onChange={set("phone")} />
        </Field>
        <Field label="Email (optional)">
          <input className="input" type="email" value={f.email} onChange={set("email")} />
        </Field>
        <Field label="Notes (optional)">
          <textarea className="input min-h-[80px]" maxLength={4000} value={f.notes} onChange={set("notes")} />
        </Field>
        <div className="flex justify-end gap-2 pt-1">
          <button type="button" className="btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button className="btn-primary" disabled={busy}>
            {busy ? "Adding..." : "Add client"}
          </button>
        </div>
      </form>
    </Modal>
  );
}

"use client";
import { useCallback, useEffect, useState } from "react";
import { ErrorBanner, Modal, Spinner } from "@/components/ui";
import { api, errText } from "@/lib/api";
import { fmtDateTime } from "@/lib/format";
import type { FeedStatus, FeedToken } from "@/lib/types";

export function FeedModal({ onClose }: { onClose: () => void }) {
  const [status, setStatus] = useState<FeedStatus | null>(null);
  const [fresh, setFresh] = useState<FeedToken | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const load = useCallback(() => {
    api<FeedStatus>("/api/feeds/token").then(setStatus).catch((e) => setError(errText(e)));
  }, []);
  useEffect(load, [load]);

  async function create() {
    setBusy(true);
    setError(null);
    try {
      const t = await api<FeedToken>("/api/feeds/token", { method: "POST" });
      // Rebuild the link on THIS site (Next proxies /feeds to the API), so it works
      // whatever PUBLIC_BASE_URL says on the server.
      const path = new URL(t.url).pathname;
      setFresh({
        ...t,
        url: `${window.location.origin}${path}`,
        webcal_url: `webcal://${window.location.host}${path}`,
      });
      load();
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  }

  async function revoke() {
    if (!confirm("Turn off your calendar link? Phones using it will stop receiving reminders.")) return;
    setBusy(true);
    try {
      await api("/api/feeds/token", { method: "DELETE" });
      setFresh(null);
      load();
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Calendar reminders" onClose={onClose}>
      <div className="space-y-4 text-sm text-slate-700">
        <p>
          Subscribe your phone&apos;s calendar to get a reminder on Day 1, 7, 14 and a warning on Day 20 for every client you
          own. Reminders appear at 09:00 and disappear when a client is solved or expires.
        </p>
        <ErrorBanner message={error} />
        {!status ? (
          <Spinner />
        ) : (
          <>
            <p className="text-slate-500">
              {status.active
                ? `Link active since ${fmtDateTime(status.created_at)}${status.last_used_at ? ` · last used ${fmtDateTime(status.last_used_at)}` : " · not used yet"}.`
                : "You don't have a calendar link yet."}
            </p>
            {fresh && (
              <div className="space-y-2 rounded-lg border border-emerald-200 bg-emerald-50 p-3">
                <p className="font-semibold text-emerald-800">Your private link (shown once, keep it secret)</p>
                <input className="input font-mono text-xs" readOnly value={fresh.url} onFocus={(e) => e.target.select()} />
                <div className="flex flex-wrap gap-2">
                  <button
                    className="btn-secondary"
                    onClick={() => navigator.clipboard.writeText(fresh.url).then(() => setCopied(true))}
                  >
                    {copied ? "Copied" : "Copy link"}
                  </button>
                  <a className="btn-primary" href={fresh.webcal_url}>
                    Open in Calendar app
                  </a>
                </div>
                <p className="text-xs text-slate-600">
                  iPhone: tap &quot;Open in Calendar app&quot;. Android/Google Calendar: Settings → Add calendar → From URL, and paste the link.
                  Google may ignore alarms on subscribed calendars, so check the events appear.
                </p>
              </div>
            )}
            <div className="flex flex-wrap gap-2">
              <button className="btn-primary" disabled={busy} onClick={create}>
                {status.active ? "Get a new link (old one stops working)" : "Create my link"}
              </button>
              {status.active && (
                <button className="btn-danger" disabled={busy} onClick={revoke}>
                  Turn off
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

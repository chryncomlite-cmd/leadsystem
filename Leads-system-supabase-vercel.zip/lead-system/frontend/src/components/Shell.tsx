"use client";
import Link from "next/link";
import { useAuth } from "./AuthProvider";

export function Shell({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  if (!user) return null;
  const manager = user.role === "SYSTEM_MANAGER";
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-4">
            <Link href={manager ? "/admin" : "/dashboard"} className="text-base font-bold text-brand-700">
              Lead Follow-Up
            </Link>
            <span className="hidden rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-600 sm:inline">
              {manager ? "Systems Manager" : "Employee"}
            </span>
          </div>
          <nav className="flex items-center gap-1 text-sm">
            <span className="mr-2 hidden text-slate-600 sm:inline">{user.full_name}</span>
            <Link href="/account" className="btn-ghost">
              Account
            </Link>
            <button className="btn-secondary" onClick={() => logout()}>
              Sign out
            </button>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6">{children}</main>
    </div>
  );
}

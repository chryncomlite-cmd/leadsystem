"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { homeFor, useAuth } from "./AuthProvider";
import { Shell } from "./Shell";
import { Spinner } from "./ui";
import type { Role } from "@/lib/types";

export function AuthGate({ role, children }: { role?: Role; children: React.ReactNode }) {
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (user === null) router.replace("/login");
    else if (user && role && user.role !== role) router.replace(homeFor(user.role));
  }, [user, role, router]);

  if (!user || (role && user.role !== role)) return <Spinner />;
  return <Shell>{children}</Shell>;
}

"use client";
import { useState } from "react";
import { ErrorBanner, Field, Modal, useToast } from "@/components/ui";
import { api, errText } from "@/lib/api";
import { useEmployees } from "./useEmployees";

export function ManagerAddLeadModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const toast = useToast();
  const employees = useEmployees(true);
  const [f, setF] = useState({ employee_id: "", client_name: "", phone: "", email: "", notes: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setF((x) => ({ ...x, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/manager/leads", {
        method: "POST",
        body: { ...f, email: f.email.trim() || null, notes: f.notes.trim() || null },
      });
      toast("Client created and assigned.");
      onCreated();
      onClose();
    } catch (err) {
      setError(errText(err));
      setBusy(false);
    }
  }

  return (
    <Modal title="Create a client for an employee" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <ErrorBanner message={error} />
        <Field label="Assign to">
          <select className="input" required value={f.employee_id} onChange={set("employee_id")}>
            <option value="">Choose an employee...</option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>
                {e.full_name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Client name">
          <input className="input" required maxLength={120} value={f.client_name} onChange={set("client_name")} />
        </Field>
        <Field label="Phone" hint="If this number is in the expired pool, it is given to the employee from there.">
          <input className="input" required inputMode="tel" value={f.phone} onChange={set("phone")} />
        </Field>
        <Field label="Email (optional)">
          <input className="input" type="email" value={f.email} onChange={set("email")} />
        </Field>
        <Field label="Notes (optional)">
          <textarea className="input min-h-[80px]" maxLength={4000} value={f.notes} onChange={set("notes")} />
        </Field>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button className="btn-primary" disabled={busy}>
            {busy ? "Creating..." : "Create"}
          </button>
        </div>
      </form>
    </Modal>
  );
}

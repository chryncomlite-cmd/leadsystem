"use client";
import { useCallback, useEffect, useState } from "react";
import { ErrorBanner, Pagination, Spinner, StatusBadge } from "@/components/ui";
import { api, errText } from "@/lib/api";
import { dayEndISO, dayStartISO, fmtDateTime } from "@/lib/format";
import { useDebounced } from "@/lib/hooks";
import { STATUSES, type ManagerLeadPage } from "@/lib/types";
import { ManagerAddLeadModal } from "./ManagerAddLeadModal";
import { ManagerLeadModal } from "./ManagerLeadModal";
import { useEmployees } from "./useEmployees";

const LIMIT = 50;

export function ClientsTab() {
  const employees = useEmployees(false);
  const [q, setQ] = useState("");
  const dq = useDebounced(q.trim(), 300);
  const [state, setState] = useState("");
  const [status, setStatus] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [sort, setSort] = useState("-entered_at");
  const [offset, setOffset] = useState(0);
  const [page, setPage] = useState<ManagerLeadPage | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const load = useCallback(async () => {
    try {
      setPage(
        await api<ManagerLeadPage>("/api/manager/leads", {
          query: {
            q: dq, state, status, employee_id: employeeId, sort, limit: LIMIT, offset,
            entered_from: dayStartISO(from), entered_to: dayEndISO(to),
          },
        }),
      );
      setError(null);
    } catch (e) {
      setError(errText(e));
    }
  }, [dq, state, status, employeeId, from, to, sort, offset]);

  useEffect(() => setOffset(0), [dq, state, status, employeeId, from, to, sort]);
  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-2">
        <input className="input !w-56" placeholder="Search name or phone" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input !w-auto" value={state} onChange={(e) => setState(e.target.value)}>
          <option value="">Any state</option>
          <option value="ACTIVE">Active</option>
          <option value="EXPIRED">Expired</option>
        </select>
        <select className="input !w-auto" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Any status</option>
          {STATUSES.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <select className="input !w-auto" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
          <option value="">Any employee</option>
          {employees.map((e) => (
            <option key={e.id} value={e.id}>
              {e.full_name}
            </option>
          ))}
        </select>
        <label className="text-xs text-slate-500">
          Entered from
          <input type="date" className="input mt-0.5" value={from} onChange={(e) => setFrom(e.target.value)} />
        </label>
        <label className="text-xs text-slate-500">
          to
          <input type="date" className="input mt-0.5" value={to} onChange={(e) => setTo(e.target.value)} />
        </label>
        <select className="input !w-auto" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="-entered_at">Newest entered</option>
          <option value="entered_at">Oldest entered</option>
          <option value="expires_at">Ending soonest</option>
          <option value="client_name">Name A-Z</option>
        </select>
        <button className="btn-primary ml-auto" onClick={() => setAdding(true)}>
          + Create client
        </button>
      </div>

      <ErrorBanner message={error} />
      {!page ? (
        <Spinner />
      ) : (
        <>
          <div className="card overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <th className="th">Client</th>
                  <th className="th">Phone</th>
                  <th className="th">Owner</th>
                  <th className="th">Status</th>
                  <th className="th">State</th>
                  <th className="th">Entered</th>
                  <th className="th">Window ends</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {page.items.map((l) => (
                  <tr key={l.id} className="cursor-pointer hover:bg-slate-50" onClick={() => setOpenId(l.id)}>
                    <td className="td font-medium text-slate-900">{l.client_name}</td>
                    <td className="td">{l.phone}</td>
                    <td className="td">{l.owner_name ?? <span className="text-slate-400">Pool</span>}</td>
                    <td className="td"><StatusBadge status={l.status} /></td>
                    <td className="td">{l.state === "ACTIVE" ? "Active" : <span className="text-slate-400">Expired</span>}</td>
                    <td className="td whitespace-nowrap">{fmtDateTime(l.entered_at)}</td>
                    <td className="td whitespace-nowrap">{l.state === "ACTIVE" ? fmtDateTime(l.expires_at) : "-"}</td>
                  </tr>
                ))}
                {page.items.length === 0 && (
                  <tr>
                    <td className="td text-slate-500" colSpan={7}>No clients match.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <Pagination offset={offset} limit={LIMIT} total={page.total} onChange={setOffset} />
        </>
      )}

      {openId && <ManagerLeadModal leadId={openId} onClose={() => setOpenId(null)} onChanged={load} />}
      {adding && <ManagerAddLeadModal onClose={() => setAdding(false)} onCreated={load} />}
    </div>
  );
}

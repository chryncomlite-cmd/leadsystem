"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";
import type { User } from "@/lib/types";

export function useEmployees(activeOnly = true) {
  const [employees, setEmployees] = useState<User[]>([]);
  useEffect(() => {
    api<User[]>("/api/manager/users", {
      query: { role: "EMPLOYEE", is_active: activeOnly ? true : undefined, limit: 1000 },
    })
      .then(setEmployees)
      .catch(() => setEmployees([]));
  }, [activeOnly]);
  return employees;
}

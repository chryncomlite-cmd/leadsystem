"use client";
import { useEffect, useState } from "react";
import { ErrorBanner, Spinner } from "@/components/ui";
import { api, errText } from "@/lib/api";
import { fmtDateTime } from "@/lib/format";
import { STATUSES, type ManagerStats } from "@/lib/types";

export function OverviewTab() {
  const [s, setS] = useState<ManagerStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = () => api<ManagerStats>("/api/manager/stats").then(setS).catch((e) => setError(errText(e)));
    load();
    const t = setInterval(load, 60_000);
    return () => clearInterval(t);
  }, []);

  if (error) return <ErrorBanner message={error} />;
  if (!s) return <Spinner />;
  const t = s.totals;

  const big: [string, number, string][] = [
    ["Total clients (ever)", t.total_clients, "text-slate-900"],
    ["Solved clients", t.solved_clients, "text-emerald-700"],
    ["Currently owned", t.active_clients, "text-brand-700"],
    ["Expired (in pool)", t.expired_clients, "text-slate-500"],
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {big.map(([label, v, c]) => (
          <div key={label} className="card px-4 py-3">
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</div>
            <div className={`text-3xl font-bold ${c}`}>{v}</div>
          </div>
        ))}
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full">
          <thead className="border-b border-slate-200 bg-slate-50">
            <tr>
              <th className="th">Pipeline status</th>
              <th className="th">All clients ever</th>
              <th className="th">Currently owned</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {STATUSES.map((st) => (
              <tr key={st}>
                <td className="td font-medium">{st}</td>
                <td className="td">{t.by_status[st]}</td>
                <td className="td">{t.active_by_status[st]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>
        <h2 className="mb-2 text-sm font-semibold">Employee performance</h2>
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <th className="th">Employee</th>
                <th className="th">Active</th>
                <th className="th">Solved</th>
                <th className="th">Lost</th>
                <th className="th">Handled</th>
                <th className="th" title="Solved / everything handled">Conversion</th>
                <th className="th" title="Solved / (solved + lost)">Closed conversion</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {s.employees.map((e) => (
                <tr key={e.employee_id} className={e.is_active ? "" : "opacity-50"}>
                  <td className="td">
                    <div className="font-medium">{e.full_name}</div>
                    <div className="text-xs text-slate-500">{e.email}</div>
                  </td>
                  <td className="td">{e.active_leads}</td>
                  <td className="td">{e.solved_leads}</td>
                  <td className="td">{e.lost_leads}</td>
                  <td className="td">{e.total_handled}</td>
                  <td className="td font-semibold">{e.conversion_pct}%</td>
                  <td className="td">{e.closed_conversion_pct}%</td>
                </tr>
              ))}
              {s.employees.length === 0 && (
                <tr>
                  <td className="td text-slate-500" colSpan={7}>
                    No employees yet. Create accounts in the Team tab.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-slate-500">Updated {fmtDateTime(s.generated_at)}</p>
      </div>
    </div>
  );
}

"use client";
import { useCallback, useEffect, useState } from "react";
import { ErrorBanner, Field, Modal, Spinner, useToast } from "@/components/ui";
import { api, errText } from "@/lib/api";
import { fmtDateTime } from "@/lib/format";
import type { Role, User } from "@/lib/types";

export function TeamTab() {
  const toast = useToast();
  const [users, setUsers] = useState<User[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [resetFor, setResetFor] = useState<User | null>(null);

  const load = useCallback(async () => {
    try {
      setUsers(await api<User[]>("/api/manager/users", { query: { limit: 1000 } }));
      setError(null);
    } catch (e) {
      setError(errText(e));
    }
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  async function toggle(u: User) {
    const verb = u.is_active ? "Deactivate" : "Reactivate";
    if (!confirm(`${verb} ${u.full_name}?${u.is_active ? " They are signed out immediately." : ""}`)) return;
    try {
      await api(`/api/manager/users/${u.id}/active`, { method: "PATCH", body: { is_active: !u.is_active } });
      toast(`${u.full_name} ${u.is_active ? "deactivated" : "reactivated"}.`);
      load();
    } catch (e) {
      toast(errText(e));
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between">
        <p className="text-sm text-slate-500">There is no public sign-up. Create accounts here and share the password privately.</p>
        <button className="btn-primary" onClick={() => setCreating(true)}>+ Add user</button>
      </div>
      <ErrorBanner message={error} />
      {!users ? (
        <Spinner />
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <th className="th">Name</th>
                <th className="th">Role</th>
                <th className="th">Last sign-in</th>
                <th className="th">Status</th>
                <th className="th" />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className={u.is_active ? "" : "opacity-60"}>
                  <td className="td">
                    <div className="font-medium text-slate-900">{u.full_name}</div>
                    <div className="text-xs text-slate-500">{u.email}</div>
                  </td>
                  <td className="td">{u.role === "SYSTEM_MANAGER" ? "Manager" : "Employee"}</td>
                  <td className="td whitespace-nowrap">{fmtDateTime(u.last_login_at)}</td>
                  <td className="td">{u.is_active ? "Active" : "Deactivated"}</td>
                  <td className="td whitespace-nowrap text-right">
                    <button className="btn-ghost" onClick={() => setResetFor(u)}>Reset password</button>
                    <button className="btn-ghost" onClick={() => toggle(u)}>{u.is_active ? "Deactivate" : "Reactivate"}</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {creating && <CreateUser onClose={() => setCreating(false)} onDone={load} />}
      {resetFor && <ResetPassword user={resetFor} onClose={() => setResetFor(null)} />}
    </div>
  );
}

function CreateUser({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ full_name: "", email: "", role: "EMPLOYEE" as Role, password: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/manager/users", { method: "POST", body: { ...f, email: f.email.trim(), full_name: f.full_name.trim() } });
      toast("User created.");
      onDone();
      onClose();
    } catch (err) {
      setError(errText(err));
      setBusy(false);
    }
  }
  return (
    <Modal title="Add a user" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <ErrorBanner message={error} />
        <Field label="Full name">
          <input className="input" required maxLength={120} value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} />
        </Field>
        <Field label="Email">
          <input className="input" type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        </Field>
        <Field label="Role">
          <select className="input" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value as Role })}>
            <option value="EMPLOYEE">Employee</option>
            <option value="SYSTEM_MANAGER">Systems Manager</option>
          </select>
        </Field>
        <Field label="Temporary password" hint="At least 12 characters.">
          <input className="input" type="text" autoComplete="off" required minLength={12} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        </Field>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={busy}>{busy ? "Creating..." : "Create user"}</button>
        </div>
      </form>
    </Modal>
  );
}

function ResetPassword({ user, onClose }: { user: User; onClose: () => void }) {
  const toast = useToast();
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api(`/api/manager/users/${user.id}/password`, { method: "PUT", body: { new_password: pw } });
      toast(`Password reset for ${user.full_name}. They are signed out everywhere and unlocked.`);
      onClose();
    } catch (err) {
      setError(errText(err));
      setBusy(false);
    }
  }
  return (
    <Modal title={`Reset password: ${user.full_name}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <ErrorBanner message={error} />
        <Field label="New password" hint="At least 12 characters. This also unlocks the account.">
          <input className="input" type="text" autoComplete="off" required minLength={12} value={pw} onChange={(e) => setPw(e.target.value)} />
        </Field>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={busy}>{busy ? "Saving..." : "Reset password"}</button>
        </div>
      </form>
    </Modal>
  );
}

"use client";
import { useCallback, useEffect, useState } from "react";
import { ActivityLog } from "@/components/ActivityLog";
import { LeadEditor, type LeadChanges } from "@/components/LeadEditor";
import { ErrorBanner, Modal, Spinner, StatusBadge, useToast } from "@/components/ui";
import { api, ApiError, errText } from "@/lib/api";
import { fmtDateTime } from "@/lib/format";
import type { ManagerLead, ManagerLeadDetail } from "@/lib/types";
import { useEmployees } from "./useEmployees";

export function ManagerLeadModal({
  leadId,
  onClose,
  onChanged,
}: {
  leadId: string;
  onClose: () => void;
  onChanged: () => void;
}) {
  const toast = useToast();
  const employees = useEmployees(true);
  const [d, setD] = useState<ManagerLeadDetail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [assignTo, setAssignTo] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setD(await api<ManagerLeadDetail>(`/api/manager/leads/${leadId}`));
    } catch (e) {
      setError(errText(e));
    }
  }, [leadId]);
  useEffect(() => {
    load();
  }, [load]);

  async function save(changes: LeadChanges, version: number) {
    try {
      await api<ManagerLead>(`/api/manager/leads/${leadId}`, { method: "PATCH", body: { ...changes, version } });
      toast("Saved.");
      onChanged();
      await load();
    } catch (e) {
      if (e instanceof ApiError && e.code === "VERSION_CONFLICT") await load();
      throw e;
    }
  }

  async function assign() {
    if (!assignTo) return;
    setBusy(true);
    setError(null);
    try {
      await api(`/api/manager/leads/${leadId}/assign`, { method: "POST", body: { employee_id: assignTo } });
      toast("Assigned with a fresh 21-day window.");
      setAssignTo("");
      onChanged();
      await load();
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(false);
    }
  }

  const lead = d?.lead;
  return (
    <Modal title={lead?.client_name ?? "Client"} onClose={onClose} wide>
      <div className="space-y-5">
        <ErrorBanner message={error} />
        {!d || !lead ? (
          <Spinner />
        ) : (
          <>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-600">
              <StatusBadge status={lead.status} />
              <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${lead.state === "ACTIVE" ? "bg-emerald-50 text-emerald-700" : "bg-slate-200 text-slate-700"}`}>
                {lead.state}
              </span>
              <span>Owner: <b className="text-slate-900">{lead.owner_name ?? "None (in pool)"}</b></span>
              <span>Entered {fmtDateTime(lead.entered_at)}</span>
              <span>{lead.state === "ACTIVE" ? `Ends ${fmtDateTime(lead.expires_at)}` : `Expired ${fmtDateTime(lead.expired_at)}`}</span>
            </div>

            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <div className="label">{lead.state === "EXPIRED" ? "Give back out" : "Reassign"}</div>
              <div className="flex flex-wrap gap-2">
                <select className="input !w-auto min-w-[14rem]" value={assignTo} onChange={(e) => setAssignTo(e.target.value)}>
                  <option value="">Choose an employee...</option>
                  {employees
                    .filter((e) => e.id !== lead.assigned_employee_id)
                    .map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.full_name}
                      </option>
                    ))}
                </select>
                <button className="btn-primary" disabled={!assignTo || busy} onClick={assign}>
                  Assign
                </button>
              </div>
              <p className="mt-1 text-xs text-slate-500">
                The new owner gets a fresh 21 days and the previous owner loses access immediately.
                {lead.state === "EXPIRED" ? " Status restarts at NEW." : " Status is kept."}
              </p>
            </div>

            <LeadEditor lead={lead} onSave={save} />

            <div>
              <h3 className="mb-2 text-sm font-semibold">Ownership history</h3>
              <ol className="space-y-1 text-sm">
                {d.assignments.map((a) => (
                  <li key={a.id} className="rounded-lg border border-slate-200 px-3 py-2">
                    <b>{a.employee_name}</b> <span className="text-slate-500">({a.source.toLowerCase()}{a.assigned_by_name ? ` by ${a.assigned_by_name}` : ""})</span>
                    <div className="text-xs text-slate-500">
                      {fmtDateTime(a.assigned_at)} → {a.ended_at ? `${fmtDateTime(a.ended_at)} (${a.end_reason?.toLowerCase()})` : "current"}
                    </div>
                  </li>
                ))}
              </ol>
            </div>
            <ActivityLog items={d.activities} />
          </>
        )}
      </div>
    </Modal>
  );
}

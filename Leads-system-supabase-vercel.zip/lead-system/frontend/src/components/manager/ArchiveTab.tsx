"use client";
import { Fragment, useCallback, useEffect, useState } from "react";
import { ErrorBanner, Pagination, Spinner, StatusBadge } from "@/components/ui";
import { api, errText } from "@/lib/api";
import { dayEndISO, dayStartISO, fmtDateTime } from "@/lib/format";
import { useDebounced } from "@/lib/hooks";
import type { ArchivePage } from "@/lib/types";
import { ManagerLeadModal } from "./ManagerLeadModal";
import { useEmployees } from "./useEmployees";

const LIMIT = 50;

export function ArchiveTab() {
  const employees = useEmployees(false);
  const [q, setQ] = useState("");
  const dq = useDebounced(q.trim(), 300);
  const [owner, setOwner] = useState("");
  const [pool, setPool] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [offset, setOffset] = useState(0);
  const [page, setPage] = useState<ArchivePage | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<number | null>(null);
  const [openLead, setOpenLead] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setPage(
        await api<ArchivePage>("/api/manager/archive", {
          query: {
            q: dq, previous_owner_id: owner, reassigned: pool === "" ? undefined : pool === "given",
            expired_from: dayStartISO(from), expired_to: dayEndISO(to), limit: LIMIT, offset,
          },
        }),
      );
      setError(null);
    } catch (e) {
      setError(errText(e));
    }
  }, [dq, owner, pool, from, to, offset]);

  useEffect(() => setOffset(0), [dq, owner, pool, from, to]);
  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-2">
        <input className="input !w-56" placeholder="Search name or phone" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input !w-auto" value={owner} onChange={(e) => setOwner(e.target.value)}>
          <option value="">Any previous owner</option>
          {employees.map((e) => (
            <option key={e.id} value={e.id}>{e.full_name}</option>
          ))}
        </select>
        <select className="input !w-auto" value={pool} onChange={(e) => setPool(e.target.value)}>
          <option value="">Pool + given out</option>
          <option value="waiting">Still in the pool</option>
          <option value="given">Already given back out</option>
        </select>
        <label className="text-xs text-slate-500">
          Expired from
          <input type="date" className="input mt-0.5" value={from} onChange={(e) => setFrom(e.target.value)} />
        </label>
        <label className="text-xs text-slate-500">
          to
          <input type="date" className="input mt-0.5" value={to} onChange={(e) => setTo(e.target.value)} />
        </label>
      </div>

      <ErrorBanner message={error} />
      {!page ? (
        <Spinner />
      ) : (
        <>
          <div className="card overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <th className="th">Client</th>
                  <th className="th">Phone</th>
                  <th className="th">Previous owner</th>
                  <th className="th">Status at expiry</th>
                  <th className="th">Entered</th>
                  <th className="th">Expired</th>
                  <th className="th">Outcome</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {page.items.map((a) => (
                  <Fragment key={a.id}>
                    <tr className="cursor-pointer hover:bg-slate-50" onClick={() => setExpanded(expanded === a.id ? null : a.id)}>
                      <td className="td font-medium text-slate-900">{a.client_name}</td>
                      <td className="td">{a.phone}</td>
                      <td className="td">{a.previous_owner_name}</td>
                      <td className="td"><StatusBadge status={a.status_at_expiry} /></td>
                      <td className="td whitespace-nowrap">{fmtDateTime(a.entered_at)}</td>
                      <td className="td whitespace-nowrap">{fmtDateTime(a.expired_at)}</td>
                      <td className="td whitespace-nowrap">
                        {a.reassigned_at ? `Given to ${a.reassigned_to_name ?? "?"}` : <span className="text-amber-700">In the pool</span>}
                      </td>
                    </tr>
                    {expanded === a.id && (
                      <tr className="bg-slate-50">
                        <td className="td" colSpan={7}>
                          <div className="space-y-2">
                            {a.notes && <p className="whitespace-pre-wrap"><b>Notes:</b> {a.notes}</p>}
                            <div>
                              <b>Ownership history:</b>
                              <ul className="ml-4 list-disc text-slate-600">
                                {a.ownership_history.map((h, i) => (
                                  <li key={i}>
                                    {String(h.employee_name ?? "?")} ({String(h.source ?? "").toLowerCase()}), {fmtDateTime(String(h.assigned_at ?? ""))}
                                    {h.end_reason ? `, ended: ${String(h.end_reason).toLowerCase()}` : ""}
                                  </li>
                                ))}
                              </ul>
                            </div>
                            <button className="btn-secondary" onClick={() => setOpenLead(a.lead_id)}>
                              Open client / give back out
                            </button>
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
                {page.items.length === 0 && (
                  <tr>
                    <td className="td text-slate-500" colSpan={7}>Nothing in the archive yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <Pagination offset={offset} limit={LIMIT} total={page.total} onChange={setOffset} />
        </>
      )}
      {openLead && <ManagerLeadModal leadId={openLead} onClose={() => setOpenLead(null)} onChanged={load} />}
    </div>
  );
}

"use client";
import { useState } from "react";
import { ErrorBanner } from "./ui";
import { errText } from "@/lib/api";
import { fmtDateTime } from "@/lib/format";
import type { Activity } from "@/lib/types";

const KIND_LABEL: Record<string, string> = {
  CREATED: "Entered",
  CLAIMED: "Claimed from pool",
  REASSIGNED: "Reassigned",
  EXPIRED: "Expired",
  STATUS_CHANGE: "Status changed",
  NOTE: "Note",
  CALL: "Call",
};

export function ActivityLog({
  items,
  onAdd,
}: {
  items: Activity[];
  onAdd?: (kind: "NOTE" | "CALL", body: string) => Promise<void>;
}) {
  const [kind, setKind] = useState<"NOTE" | "CALL">("CALL");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!onAdd || !body.trim()) return;
    setBusy(true);
    setError(null);
    try {
      await onAdd(kind, body.trim());
      setBody("");
    } catch (err) {
      setError(errText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold">Follow-up log</h3>
      {onAdd && (
        <form onSubmit={submit} className="space-y-2">
          <ErrorBanner message={error} />
          <div className="flex gap-2">
            <select className="input !w-28" value={kind} onChange={(e) => setKind(e.target.value as "NOTE" | "CALL")}>
              <option value="CALL">Call</option>
              <option value="NOTE">Note</option>
            </select>
            <input className="input" placeholder="What happened?" maxLength={2000} value={body} onChange={(e) => setBody(e.target.value)} />
            <button className="btn-primary" disabled={busy || !body.trim()}>
              Add
            </button>
          </div>
        </form>
      )}
      {items.length === 0 ? (
        <p className="text-sm text-slate-500">Nothing logged yet.</p>
      ) : (
        <ol className="space-y-2">
          {items.map((a) => (
            <li key={a.id} className="rounded-lg border border-slate-200 px-3 py-2 text-sm">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                <span className="font-semibold text-slate-700">
                  {KIND_LABEL[a.kind] ?? a.kind}
                  {a.kind === "STATUS_CHANGE" && a.from_status && a.to_status ? `: ${a.from_status} → ${a.to_status}` : ""}
                </span>
                <span>
                  {a.actor_name ?? "System"} · {fmtDateTime(a.created_at)}
                </span>
              </div>
              {a.body && <p className="mt-1 whitespace-pre-wrap text-slate-700">{a.body}</p>}
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

"use client";
import { useState } from "react";
import { useAuth } from "@/components/AuthProvider";
import { ErrorBanner, Field, useToast } from "@/components/ui";
import { api, errText } from "@/lib/api";

export default function AccountPage() {
  const { user, logout } = useAuth();
  const toast = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/change-password", {
        method: "POST",
        body: { current_password: current, new_password: next },
      });
      setCurrent("");
      setNext("");
      toast("Password changed. Other devices have been signed out.");
    } catch (err) {
      setError(errText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md space-y-6">
      <div className="card p-5">
        <h1 className="text-lg font-semibold">{user?.full_name}</h1>
        <p className="text-sm text-slate-500">{user?.email}</p>
      </div>
      <form onSubmit={submit} className="card space-y-4 p-5">
        <h2 className="font-semibold">Change password</h2>
        <ErrorBanner message={error} />
        <Field label="Current password">
          <input className="input" type="password" autoComplete="current-password" required value={current} onChange={(e) => setCurrent(e.target.value)} />
        </Field>
        <Field label="New password" hint="At least 12 characters.">
          <input className="input" type="password" autoComplete="new-password" required minLength={12} value={next} onChange={(e) => setNext(e.target.value)} />
        </Field>
        <button className="btn-primary" disabled={busy}>
          {busy ? "Saving..." : "Change password"}
        </button>
      </form>
      <button
        className="btn-secondary w-full"
        onClick={async () => {
          await api("/api/auth/logout-all", { method: "POST" }).catch(() => {});
          await logout();
        }}
      >
        Sign out of every device
      </button>
    </div>
  );
}

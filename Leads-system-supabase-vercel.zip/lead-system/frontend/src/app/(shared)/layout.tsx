import { AuthGate } from "@/components/AuthGate";

export default function SharedLayout({ children }: { children: React.ReactNode }) {
  return <AuthGate>{children}</AuthGate>;
}

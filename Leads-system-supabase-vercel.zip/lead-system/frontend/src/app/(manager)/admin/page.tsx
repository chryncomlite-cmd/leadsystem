"use client";
import { useState } from "react";
import { ArchiveTab } from "@/components/manager/ArchiveTab";
import { ClientsTab } from "@/components/manager/ClientsTab";
import { OverviewTab } from "@/components/manager/OverviewTab";
import { TeamTab } from "@/components/manager/TeamTab";

const TABS = [
  ["overview", "Overview"],
  ["clients", "All clients"],
  ["archive", "Expired archive"],
  ["team", "Team"],
] as const;
type Tab = (typeof TABS)[number][0];

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>("overview");
  return (
    <div className="space-y-5">
      <div className="flex gap-1 border-b border-slate-200">
        {TABS.map(([id, label]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`-mb-px border-b-2 px-4 py-2 text-sm font-medium ${tab === id ? "border-brand-600 text-brand-700" : "border-transparent text-slate-500 hover:text-slate-800"}`}
          >
            {label}
          </button>
        ))}
      </div>
      {tab === "overview" && <OverviewTab />}
      {tab === "clients" && <ClientsTab />}
      {tab === "archive" && <ArchiveTab />}
      {tab === "team" && <TeamTab />}
    </div>
  );
}

import { AuthGate } from "@/components/AuthGate";

export default function ManagerLayout({ children }: { children: React.ReactNode }) {
  return <AuthGate role="SYSTEM_MANAGER">{children}</AuthGate>;
}

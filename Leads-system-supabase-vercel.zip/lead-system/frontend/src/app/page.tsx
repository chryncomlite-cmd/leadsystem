"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { homeFor, useAuth } from "@/components/AuthProvider";
import { Spinner } from "@/components/ui";

export default function Index() {
  const { user } = useAuth();
  const router = useRouter();
  useEffect(() => {
    if (user === undefined) return;
    router.replace(user ? homeFor(user.role) : "/login");
  }, [user, router]);
  return <Spinner />;
}

import { AuthGate } from "@/components/AuthGate";

export default function EmployeeLayout({ children }: { children: React.ReactNode }) {
  return <AuthGate role="EMPLOYEE">{children}</AuthGate>;
}

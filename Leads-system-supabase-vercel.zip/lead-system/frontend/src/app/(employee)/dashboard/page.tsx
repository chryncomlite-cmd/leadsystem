"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { AddLeadModal } from "@/components/employee/AddLeadModal";
import { FeedModal } from "@/components/employee/FeedModal";
import { LeadModal } from "@/components/employee/LeadModal";
import { ErrorBanner, Pagination, Spinner, StatusBadge } from "@/components/ui";
import { api, errText } from "@/lib/api";
import { formatRemaining, urgency } from "@/lib/format";
import { useDebounced, useNow } from "@/lib/hooks";
import { STATUSES, type Lead, type LeadPage, type LeadStats, type LeadStatus } from "@/lib/types";

const LIMIT = 24;
const URGENCY_STYLE = {
  ok: "text-slate-700",
  soon: "text-amber-600",
  critical: "text-red-600",
} as const;

export default function Dashboard() {
  const [status, setStatus] = useState<LeadStatus | "">("");
  const [q, setQ] = useState("");
  const dq = useDebounced(q.trim(), 300);
  const [sort, setSort] = useState("expires_at");
  const [offset, setOffset] = useState(0);

  const [page, setPage] = useState<LeadPage | null>(null);
  const [stats, setStats] = useState<LeadStats | null>(null);
  const [fetchedAt, setFetchedAt] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const [openId, setOpenId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [feed, setFeed] = useState(false);

  const now = useNow(1000);
  const lastLoad = useRef(0);

  const load = useCallback(async () => {
    lastLoad.current = Date.now();
    try {
      const [p, s] = await Promise.all([
        api<LeadPage>("/api/leads", { query: { status, q: dq, sort, limit: LIMIT, offset } }),
        api<LeadStats>("/api/leads/stats"),
      ]);
      setPage(p);
      setStats(s);
      setFetchedAt(Date.now());
      setError(null);
    } catch (e) {
      setError(errText(e));
    }
  }, [status, dq, sort, offset]);

  useEffect(() => {
    setOffset(0);
  }, [status, dq, sort]);
  useEffect(() => {
    load();
  }, [load]);
  // Keep the list honest while the tab stays open.
  useEffect(() => {
    const t = setInterval(load, 60_000);
    return () => clearInterval(t);
  }, [load]);

  // The moment a countdown reaches zero, ask the server (it hides the lead).
  const deadline = (l: Lead) => fetchedAt + l.seconds_remaining * 1000;
  const anyDue = page?.items.some((l) => deadline(l) <= now) ?? false;
  useEffect(() => {
    if (anyDue && Date.now() - lastLoad.current > 5000) load();
  }, [anyDue, load]);

  const cards: [string, number | undefined, string][] = [
    ["Total", stats?.total, "text-slate-900"],
    ["New", stats?.new, "text-sky-700"],
    ["Pending", stats?.pending, "text-amber-700"],
    ["Saving", stats?.saving, "text-violet-700"],
    ["Solved", stats?.solved, "text-emerald-700"],
    ["Ending in 3 days", stats?.expiring_soon, "text-red-600"],
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {cards.map(([label, value, color]) => (
          <div key={label} className="card px-4 py-3">
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</div>
            <div className={`text-2xl font-bold ${color}`}>{value ?? "-"}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <input className="input !w-full sm:!w-64" placeholder="Search name or phone" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="flex flex-wrap gap-1">
          {(["", ...STATUSES] as const).map((s) => (
            <button
              key={s || "ALL"}
              onClick={() => setStatus(s)}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold ${status === s ? "bg-brand-600 text-white" : "bg-white text-slate-600 ring-1 ring-slate-300 hover:bg-slate-50"}`}
            >
              {s || "All"}
            </button>
          ))}
        </div>
        <select className="input !w-auto" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="expires_at">Ending soonest</option>
          <option value="-entered_at">Newest first</option>
          <option value="entered_at">Oldest first</option>
          <option value="client_name">Name A-Z</option>
        </select>
        <div className="ml-auto flex gap-2">
          <button className="btn-secondary" onClick={() => setFeed(true)}>
            Calendar reminders
          </button>
          <button className="btn-primary" onClick={() => setAdding(true)}>
            + Add client
          </button>
        </div>
      </div>

      <ErrorBanner message={error} />
      {!page ? (
        <Spinner />
      ) : page.items.length === 0 ? (
        <div className="card p-10 text-center text-sm text-slate-500">
          {dq || status ? "No clients match your filters." : "No clients yet. Add your first one."}
        </div>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {page.items.map((l) => {
              const left = deadline(l) - now;
              return (
                <button key={l.id} onClick={() => setOpenId(l.id)} className="card p-4 text-left transition hover:border-brand-500 hover:shadow">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate font-semibold">{l.client_name}</div>
                      <div className="text-sm text-slate-500">{l.phone}</div>
                    </div>
                    <StatusBadge status={l.status} />
                  </div>
                  {l.notes && <p className="mt-2 line-clamp-2 text-sm text-slate-600">{l.notes}</p>}
                  <div className="mt-3 flex items-center justify-between text-xs">
                    <span className="text-slate-500">Time left</span>
                    <span className={`font-mono text-sm font-bold ${URGENCY_STYLE[urgency(left)]}`}>{formatRemaining(left)}</span>
                  </div>
                </button>
              );
            })}
          </div>
          <Pagination offset={offset} limit={LIMIT} total={page.total} onChange={setOffset} />
        </>
      )}

      {adding && <AddLeadModal onClose={() => setAdding(false)} onCreated={load} />}
      {feed && <FeedModal onClose={() => setFeed(false)} />}
      {openId && (() => {
        const l = page?.items.find((x) => x.id === openId);
        return (
          <LeadModal
            leadId={openId}
            deadline={l ? deadline(l) : now}
            now={now}
            onClose={() => setOpenId(null)}
            onChanged={load}
          />
        );
      })()}
    </div>
  );
}

import type { LeadStatus } from "./types";

export function formatRemaining(ms: number): string {
  if (ms <= 0) return "Expired";
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m ${s % 60}s`;
}

export type Urgency = "ok" | "soon" | "critical";
export function urgency(ms: number): Urgency {
  if (ms <= 24 * 3600 * 1000) return "critical";
  if (ms <= 3 * 24 * 3600 * 1000) return "soon";
  return "ok";
}

export function fmtDateTime(iso: string | null | undefined): string {
  if (!iso) return "-";
  return new Date(iso).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" });
}
export function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "-";
  return new Date(iso).toLocaleDateString("en-GB", { dateStyle: "medium" });
}

export const STATUS_STYLES: Record<LeadStatus, string> = {
  NEW: "bg-sky-100 text-sky-800",
  PENDING: "bg-amber-100 text-amber-800",
  SAVING: "bg-violet-100 text-violet-800",
  SOLVED: "bg-emerald-100 text-emerald-800",
};

/** yyyy-mm-dd from a date input -> ISO start of that local day. */
export const dayStartISO = (d: string) => (d ? new Date(`${d}T00:00:00`).toISOString() : "");
/** yyyy-mm-dd -> ISO start of the NEXT local day (exclusive upper bound). */
export function dayEndISO(d: string) {
  if (!d) return "";
  const x = new Date(`${d}T00:00:00`);
  x.setDate(x.getDate() + 1);
  return x.toISOString();
}

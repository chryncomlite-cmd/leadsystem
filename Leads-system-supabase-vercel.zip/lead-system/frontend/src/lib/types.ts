export type Role = "EMPLOYEE" | "SYSTEM_MANAGER";
export type LeadStatus = "NEW" | "PENDING" | "SAVING" | "SOLVED";
export const STATUSES: LeadStatus[] = ["NEW", "PENDING", "SAVING", "SOLVED"];

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: Role;
  is_active: boolean;
  last_login_at: string | null;
  created_at: string | null;
}

export interface Lead {
  id: string;
  client_name: string;
  phone: string;
  email: string | null;
  notes: string | null;
  status: LeadStatus;
  entered_at: string;
  assigned_at: string;
  expires_at: string;
  seconds_remaining: number;
  version: number;
}
export interface LeadCreated extends Lead {
  source: "ENTERED" | "CLAIMED" | "ASSIGNED";
}
export interface LeadPage {
  items: Lead[];
  total: number;
  server_time: string;
}
export interface LeadStats {
  total: number;
  new: number;
  pending: number;
  saving: number;
  solved: number;
  expiring_soon: number;
}

export interface ManagerLead extends Lead {
  state: "ACTIVE" | "EXPIRED";
  assigned_employee_id: string | null;
  owner_name: string | null;
  created_by: string;
  expired_at: string | null;
  solved_at: string | null;
}
export interface ManagerLeadPage {
  items: ManagerLead[];
  total: number;
  server_time: string;
}

export interface Activity {
  id: number;
  kind: string;
  body: string | null;
  from_status: string | null;
  to_status: string | null;
  actor_id: string | null;
  actor_name: string | null;
  created_at: string;
}
export interface Assignment {
  id: number;
  employee_id: string;
  employee_name: string;
  source: string;
  assigned_by_name: string | null;
  assigned_at: string;
  ended_at: string | null;
  end_reason: string | null;
}
export interface ManagerLeadDetail {
  lead: ManagerLead;
  assignments: Assignment[];
  activities: Activity[];
}

export interface ArchiveRow {
  id: number;
  lead_id: string;
  client_name: string;
  phone: string;
  email: string | null;
  notes: string | null;
  status_at_expiry: LeadStatus;
  previous_owner_id: string | null;
  previous_owner_name: string;
  entered_at: string;
  assigned_at: string;
  expired_at: string;
  ownership_history: Record<string, unknown>[];
  reassigned_at: string | null;
  reassigned_to: string | null;
  reassigned_to_name: string | null;
  reassigned_by: string | null;
}
export interface ArchivePage {
  items: ArchiveRow[];
  total: number;
}

export type StatusCounts = Record<LeadStatus, number>;
export interface ManagerStats {
  totals: {
    total_clients: number;
    solved_clients: number;
    active_clients: number;
    expired_clients: number;
    by_status: StatusCounts;
    active_by_status: StatusCounts;
  };
  employees: {
    employee_id: string;
    full_name: string;
    email: string;
    is_active: boolean;
    active_leads: number;
    solved_leads: number;
    lost_leads: number;
    total_handled: number;
    conversion_pct: number;
    closed_conversion_pct: number;
  }[];
  generated_at: string;
}

export interface FeedStatus {
  active: boolean;
  created_at: string | null;
  last_used_at: string | null;
}
export interface FeedToken {
  url: string;
  webcal_url: string;
  created_at: string;
}

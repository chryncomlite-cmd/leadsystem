export class ApiError extends Error {
  status: number;
  code?: string;
  detail: unknown;
  constructor(status: number, message: string, detail: unknown, code?: string) {
    super(message);
    this.status = status;
    this.detail = detail;
    this.code = code;
  }
}

function messageFrom(detail: unknown, status: number): string {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    // FastAPI/Pydantic validation errors
    return detail
      .map((d) => String((d as { msg?: string }).msg ?? "Invalid value").replace(/^Value error, /, ""))
      .join(". ");
  }
  if (detail && typeof detail === "object" && "message" in detail) {
    return String((detail as { message: unknown }).message);
  }
  if (status === 403) return "You don't have permission to do that.";
  if (status === 429) return "Too many attempts. Please wait and try again.";
  return `Something went wrong (${status}). Please try again.`;
}

type Query = Record<string, string | number | boolean | null | undefined>;

export interface ApiOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  query?: Query;
  /** Don't treat a 401 as "session expired" (used by login and the first /me check). */
  quiet?: boolean;
}

export async function api<T = void>(path: string, opts: ApiOptions = {}): Promise<T> {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(opts.query ?? {})) {
    if (v !== undefined && v !== null && v !== "") qs.set(k, String(v));
  }
  const q = qs.toString();
  const url = q ? `${path}?${q}` : path;

  let res: Response;
  try {
    res = await fetch(url, {
      method: opts.method ?? "GET",
      credentials: "same-origin",
      headers: opts.body !== undefined ? { "Content-Type": "application/json" } : undefined,
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      cache: "no-store",
    });
  } catch {
    throw new ApiError(0, "Can't reach the server. Check your connection.", null);
  }

  if (res.status === 204) return undefined as T;

  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON body (e.g. a platform error page) */
  }

  if (!res.ok) {
    if (res.status === 401 && !opts.quiet && typeof window !== "undefined") {
      window.dispatchEvent(new Event("auth:expired"));
    }
    const detail = (data as { detail?: unknown } | null)?.detail ?? null;
    const code =
      detail && typeof detail === "object" && !Array.isArray(detail)
        ? (detail as { code?: string }).code
        : undefined;
    throw new ApiError(res.status, messageFrom(detail, res.status), detail, code);
  }
  return data as T;
}

export const errText = (e: unknown): string =>
  e instanceof ApiError ? e.message : "Something went wrong. Please try again.";

import { NextResponse, type NextRequest } from "next/server";

// Cheap first gate: no session cookie -> login. The real checks (role, expiry,
// revocation) happen in the API on every request; this just avoids a flash of
// a protected page.
export function middleware(req: NextRequest) {
  const name = process.env.SESSION_COOKIE_NAME || "lead_session";
  if (!req.cookies.get(name)) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/dashboard/:path*", "/admin/:path*", "/account/:path*"] };

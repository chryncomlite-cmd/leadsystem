/** @type {import('next').NextConfig} */

// The browser only ever talks to THIS origin. Next proxies the API and the
// calendar feed to the FastAPI project, so the session cookie is first-party
// (SameSite=Lax works, no CORS, no third-party-cookie problems).
const backend = (process.env.BACKEND_URL || "http://localhost:8000").replace(/\/$/, "");

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async rewrites() {
    return [
      { source: "/api/:path*", destination: `${backend}/api/:path*` },
      { source: "/feeds/:path*", destination: `${backend}/feeds/:path*` },
    ];
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "no-referrer" },
        ],
      },
    ];
  },
};

export default nextConfig;

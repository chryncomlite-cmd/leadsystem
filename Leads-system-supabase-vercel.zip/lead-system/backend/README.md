# Backend — Step 2: Authentication and RBAC

## Run it

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env            # set JWT_SECRET and DATABASE_URL

psql "$PGURL" -f ../db/migrations/001_init_schema.up.sql
psql "$PGURL" -f ../db/migrations/002_lead_queries.up.sql
MANAGER_PASSWORD='choose-a-long-passphrase' \
  python -m scripts.create_manager --email you@company.com --name "Your Name"

uvicorn app.main:app --reload --proxy-headers
```

## Test it

Needs an empty PostgreSQL database whose name ends in `_test`. The schema is dropped and rebuilt from the migration on every run, and the suite refuses to touch any other database name.

```bash
DATABASE_URL=postgresql+asyncpg://user:pw@localhost:5432/leadsystem_test pytest
```

## Endpoints

| Method | Path | Access |
|---|---|---|
| POST | `/api/auth/login` | public |
| POST | `/api/auth/logout` | public (clears this device's cookie) |
| POST | `/api/auth/logout-all` | signed in (revokes every device) |
| GET | `/api/auth/me` | signed in |
| POST | `/api/auth/refresh` | signed in (sliding session, 12 h absolute cap) |
| POST | `/api/auth/change-password` | signed in (signs out other devices) |
| POST | `/api/manager/users` | SYSTEM_MANAGER |
| GET | `/api/manager/users` | SYSTEM_MANAGER (`role`, `is_active`, `limit`, `offset`) |
| PATCH | `/api/manager/users/{id}/active` | SYSTEM_MANAGER |
| PUT | `/api/manager/users/{id}/password` | SYSTEM_MANAGER (reset and unlock) |

There is no public sign-up. Managers create employee accounts.

## Lead endpoints (Step 3)

**Employee** (`EMPLOYEE` only; managers use the manager routes below)

| Method | Path | What it does |
|---|---|---|
| POST | `/api/leads` | Enter a client. Typing the number of an expired client claims it from the pool instead |
| GET | `/api/leads` | My live clients. Filters: `status`, `q`, `sort`, `limit`, `offset`. Each row carries `seconds_remaining` and the response carries `server_time` for the countdown timers |
| GET | `/api/leads/stats` | My counts by status, plus `expiring_soon` (ends within 3 days) |
| GET / PATCH | `/api/leads/{id}` | Read / update. PATCH needs the `version` you last read |
| GET / POST | `/api/leads/{id}/activities` | Call and note log |

**Systems Manager**

| Method | Path | What it does |
|---|---|---|
| GET | `/api/manager/stats` | Total clients, solved clients, status breakdown (all clients and currently owned), per-employee conversion audit |
| GET | `/api/manager/leads` | Every lead with owner and input date/time. Filters: `state`, `status`, `employee_id`, `q`, `entered_from`, `entered_to`, `sort` |
| POST | `/api/manager/leads` | Create a client and assign it to an employee |
| GET / PATCH | `/api/manager/leads/{id}` | Detail with assignment history and activity / edit any lead, expired or not |
| POST | `/api/manager/leads/{id}/assign` | Assign or reassign to an employee |
| GET | `/api/manager/archive` | The expired archive. Filters: `previous_owner_id`, `reassigned`, `q`, `expired_from`, `expired_to` |

**Calendar feed**

| Method | Path | What it does |
|---|---|---|
| POST / GET / DELETE | `/api/feeds/token` | Create or rotate my private feed URL (shown once) / status / revoke |
| GET | `/feeds/{token}.ics` | The subscription feed itself (public; the token is the credential) |

### Rules worth knowing

- **Day 22 is enforced twice.** Every employee query and the feed require `expires_at > now()`, so a lead disappears on time even if the hourly worker is late.
- **Other people's clients answer 404, not 403**, so an employee cannot learn that a client exists.
- **Claiming.** Employees never browse the expired pool. Typing a pool number claims it: new 21-day window, status back to `NEW`, and the claimer's details replace the old ones (the previous owner's version stays in the archive). The original input time is kept. Set `RECLAIM_COOLDOWN_DAYS` above 0 to stop a previous owner re-claiming their own client straight away.
- **Reassigning.** An active lead keeps its status (the new owner sees where it got to); an expired lead restarts at `NEW`. Both get a fresh 21 days, and the old owner loses access immediately.
- **Conversion.** `conversion_pct` = solved / everything handled (active + archived), so in-progress clients count against it. `closed_conversion_pct` = solved / (solved + lost), finished outcomes only. Solved clients keep their credit after they expire.
- **Reminders.** Day 1, 7, 14 and the Day 20 warning fire at 09:00 local time (`FOLLOWUP_TIMEZONE`, `FOLLOWUP_HOUR`). A solved client stops generating reminders; re-opening it restores them.
- **Feed limits.** Apple Calendar normally honours the alarms in a subscribed feed. Google Calendar generally ignores alarms in subscribed calendars, which is why the Google Calendar API push (Step 4) is the reliable route for Android alerts. Test the feed on one iPhone and one Android phone before rolling out. The token is part of the URL, so exclude `/feeds/` from your proxy's access logs.

## Security design

- **Argon2id**, 64 MiB memory, 3 passes, 2 lanes, with a random 16-byte salt per hash. The salt and parameters live inside each stored hash, and a hash is upgraded automatically at next login if the parameters were raised.
- **Bounded hashing pool.** At most `MAX_CONCURRENT_HASHES` (default 8) hashes run at once, so peak memory is 8 x 64 MiB = 512 MiB even if 200 users log in together. Size this to your server.
- **Session** is a 30-minute JWT in an HttpOnly, Secure, SameSite=Lax cookie. The algorithm is pinned to HS256, which rejects `alg=none`.
- **Live revocation.** Every request re-reads the user row, so deactivating, demoting or resetting a user takes effect on the next request. Bumping `token_version` signs out every device.
- **Brute force.** 5 failures lock the account for 15 minutes. Attempts on one account are serialised with a row lock, so parallel guesses cannot beat the counter. Unknown emails run a dummy Argon2 verify so response time doesn't reveal which accounts exist.
- **CSRF.** State-changing requests must come from an origin listed in `ALLOWED_ORIGINS`, on top of SameSite cookies. This is meant for the browser app, so scripts calling the API must send an `Origin` header.
- **Audit log** records logins, failures, blocks, password changes and user administration.

## Known gaps (planned)

- Per-IP rate limiting needs Redis, which arrives with the Celery step.
- Run the API behind PgBouncer (transaction mode) and a TLS-terminating proxy that sets `X-Forwarded-For`; start uvicorn with `--proxy-headers` and a trusted-proxy list.
- Deactivating an employee does not yet release their active leads. That rule belongs to Step 3 (lead endpoints).

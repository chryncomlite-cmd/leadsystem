import json
from datetime import datetime
from enum import Enum
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

from app.services.phone import normalize_phone


class LeadStatus(str, Enum):
    NEW = "NEW"
    PENDING = "PENDING"
    SAVING = "SAVING"
    SOLVED = "SOLVED"


class LeadState(str, Enum):
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"


def _strip(v: Any) -> Any:
    return v.strip() if isinstance(v, str) else v


def _blank_to_none(v: Any) -> Any:
    v = _strip(v)
    return None if v == "" else v


# ---------------------------------------------------------------- input
class LeadCreate(BaseModel):
    client_name: str = Field(min_length=1, max_length=120)
    phone: str = Field(min_length=5, max_length=32)
    email: EmailStr | None = None
    notes: str | None = Field(default=None, max_length=4000)

    _strip_required = field_validator("client_name", "phone", mode="before")(_strip)
    _blank_optional = field_validator("email", "notes", mode="before")(_blank_to_none)

    @field_validator("phone")
    @classmethod
    def _phone_is_valid(cls, v: str) -> str:
        normalize_phone(v)  # raises ValueError -> 422
        return v


class ManagerLeadCreate(LeadCreate):
    employee_id: UUID


class LeadUpdate(BaseModel):
    version: int = Field(ge=1, description="The version you last read; guards against lost updates")
    client_name: str | None = Field(default=None, min_length=1, max_length=120)
    phone: str | None = Field(default=None, min_length=5, max_length=32)
    email: EmailStr | None = None
    notes: str | None = Field(default=None, max_length=4000)
    status: LeadStatus | None = None

    _strip_required = field_validator("client_name", "phone", mode="before")(_strip)
    _blank_optional = field_validator("email", "notes", mode="before")(_blank_to_none)

    @field_validator("phone")
    @classmethod
    def _phone_is_valid(cls, v: str | None) -> str | None:
        if v is not None:
            normalize_phone(v)
        return v

    @model_validator(mode="after")
    def _validate_changes(self):
        sent = self.model_fields_set - {"version"}
        if not sent:
            raise ValueError("Nothing to update")
        for name in ("client_name", "phone", "status"):
            if name in sent and getattr(self, name) is None:
                raise ValueError(f"{name} cannot be null")
        return self

    def changes(self) -> dict[str, Any]:
        out = {k: getattr(self, k) for k in self.model_fields_set - {"version"}}
        if isinstance(out.get("status"), LeadStatus):
            out["status"] = out["status"].value
        return out


class AssignRequest(BaseModel):
    employee_id: UUID


class ActivityCreate(BaseModel):
    kind: Literal["NOTE", "CALL"]
    body: str = Field(min_length=1, max_length=2000)

    _strip_body = field_validator("body", mode="before")(_strip)


# --------------------------------------------------------------- output
class LeadOut(BaseModel):
    id: UUID
    client_name: str
    phone: str
    email: str | None = None
    notes: str | None = None
    status: LeadStatus
    entered_at: datetime
    assigned_at: datetime
    expires_at: datetime
    seconds_remaining: int  # computed by the server, so a wrong phone clock can't extend a lead
    version: int


class LeadCreated(LeadOut):
    source: Literal["ENTERED", "CLAIMED", "ASSIGNED"]


class LeadPage(BaseModel):
    items: list[LeadOut]
    total: int
    server_time: datetime


class LeadStats(BaseModel):
    total: int
    new: int
    pending: int
    saving: int
    solved: int
    expiring_soon: int  # ownership ends within 3 days


class ManagerLeadOut(LeadOut):
    state: LeadState
    assigned_employee_id: UUID | None = None
    owner_name: str | None = None
    created_by: UUID
    expired_at: datetime | None = None
    solved_at: datetime | None = None


class ManagerLeadCreated(ManagerLeadOut):
    source: Literal["ENTERED", "CLAIMED", "ASSIGNED"]


class ManagerLeadPage(BaseModel):
    items: list[ManagerLeadOut]
    total: int
    server_time: datetime


class ActivityOut(BaseModel):
    id: int
    kind: str
    body: str | None = None
    from_status: str | None = None
    to_status: str | None = None
    actor_id: UUID | None = None
    actor_name: str | None = None
    created_at: datetime


class AssignmentOut(BaseModel):
    id: int
    employee_id: UUID
    employee_name: str
    source: str
    assigned_by_name: str | None = None
    assigned_at: datetime
    ended_at: datetime | None = None
    end_reason: str | None = None


class ManagerLeadDetail(BaseModel):
    lead: ManagerLeadOut
    assignments: list[AssignmentOut]
    activities: list[ActivityOut]


class ArchiveOut(BaseModel):
    id: int
    lead_id: UUID
    client_name: str
    phone: str
    email: str | None = None
    notes: str | None = None
    status_at_expiry: LeadStatus
    previous_owner_id: UUID | None = None
    previous_owner_name: str
    entered_at: datetime
    assigned_at: datetime
    expired_at: datetime
    ownership_history: list[dict[str, Any]] = []
    reassigned_at: datetime | None = None
    reassigned_to: UUID | None = None
    reassigned_to_name: str | None = None
    reassigned_by: UUID | None = None

    @field_validator("ownership_history", mode="before")
    @classmethod
    def _decode_json(cls, v: Any) -> Any:
        return json.loads(v) if isinstance(v, str) else v


class ArchivePage(BaseModel):
    items: list[ArchiveOut]
    total: int


class StatusCounts(BaseModel):
    NEW: int = 0
    PENDING: int = 0
    SAVING: int = 0
    SOLVED: int = 0


class ClientTotals(BaseModel):
    total_clients: int
    solved_clients: int
    active_clients: int
    expired_clients: int
    by_status: StatusCounts  # every client ever tracked
    active_by_status: StatusCounts  # only clients currently owned


class EmployeePerformance(BaseModel):
    employee_id: UUID
    full_name: str
    email: str
    is_active: bool
    active_leads: int
    solved_leads: int
    lost_leads: int
    total_handled: int
    conversion_pct: float
    closed_conversion_pct: float


class ManagerStats(BaseModel):
    totals: ClientTotals
    employees: list[EmployeePerformance]
    generated_at: datetime

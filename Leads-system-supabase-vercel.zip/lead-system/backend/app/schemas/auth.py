from datetime import datetime
from enum import Enum
from typing import Annotated
from uuid import UUID

from pydantic import AfterValidator, BaseModel, EmailStr, Field, model_validator

from app.core.config import get_settings

settings = get_settings()


class Role(str, Enum):
    EMPLOYEE = "EMPLOYEE"
    SYSTEM_MANAGER = "SYSTEM_MANAGER"


def _check_password(value: str) -> str:
    if len(value) < settings.min_password_length:
        raise ValueError(f"Password must be at least {settings.min_password_length} characters")
    if len(value) > 128:
        raise ValueError("Password must be at most 128 characters")
    return value


NewPassword = Annotated[str, AfterValidator(_check_password)]


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)


class UserOut(BaseModel):
    id: UUID
    email: str
    full_name: str
    role: Role
    is_active: bool
    last_login_at: datetime | None = None
    created_at: datetime | None = None


class CreateUserRequest(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=1, max_length=120)
    role: Role = Role.EMPLOYEE
    password: NewPassword

    @model_validator(mode="after")
    def _password_not_email(self):
        if self.password.lower() == str(self.email).lower():
            raise ValueError("Password must not be the email address")
        return self


class SetActiveRequest(BaseModel):
    is_active: bool


class ResetPasswordRequest(BaseModel):
    new_password: NewPassword


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=256)
    new_password: NewPassword

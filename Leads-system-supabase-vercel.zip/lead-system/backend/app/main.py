from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import text

from app.core.config import get_settings
from app.core.db import SessionLocal, engine
from app.middleware.http_guards import origin_guard, security_headers
from app.routers import auth, cron, feeds, leads, manager, users

settings = get_settings()
is_prod = settings.environment == "production"


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    await engine.dispose()


app = FastAPI(
    title="Lead Follow-Up & Ownership Management",
    lifespan=lifespan,
    docs_url=None if is_prod else "/docs",
    redoc_url=None,
    openapi_url=None if is_prod else "/openapi.json",
)

app.middleware("http")(origin_guard)
app.middleware("http")(security_headers)

app.include_router(auth.router)
app.include_router(cron.router)
app.include_router(users.router)
app.include_router(leads.router)
app.include_router(manager.router)
app.include_router(feeds.api_router)
app.include_router(feeds.public_router)


@app.get("/healthz", include_in_schema=False)
async def healthz():
    async with SessionLocal() as session:
        await session.execute(text("SELECT 1"))
    return {"status": "ok"}

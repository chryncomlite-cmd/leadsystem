"""Manager-only user administration. There is no public sign-up: accounts are
created here (or by scripts/create_manager.py for the very first manager)."""
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.db import get_db
from app.core.security import hash_password
from app.middleware.auth import AuthUser
from app.middleware.rbac import require_manager
from app.routers.auth import USER_COLUMNS, client_ip, user_out
from app.schemas.auth import (
    CreateUserRequest,
    ResetPasswordRequest,
    Role,
    SetActiveRequest,
    UserOut,
)
from app.services.audit import write_audit

router = APIRouter(
    prefix="/api/manager/users",
    tags=["manager: users"],
    dependencies=[Depends(require_manager)],
)


@router.post("", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(
    body: CreateUserRequest,
    request: Request,
    manager: AuthUser = Depends(require_manager),
    db: AsyncSession = Depends(get_db),
):
    password_hash = await hash_password(body.password)
    try:
        row = (
            await db.execute(
                text(
                    f"""
                    INSERT INTO users (email, full_name, role, password_hash)
                    VALUES (CAST(CAST(:email AS text) AS citext), :name,
                            CAST(CAST(:role AS text) AS user_role), :hash)
                    RETURNING {USER_COLUMNS}
                    """
                ),
                {
                    "email": str(body.email),
                    "name": body.full_name.strip(),
                    "role": body.role.value,
                    "hash": password_hash,
                },
            )
        ).mappings().one()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already exists")

    await write_audit(
        db,
        actor_id=manager.id,
        action="USER_CREATED",
        entity_type="user",
        entity_id=str(row["id"]),
        ip=client_ip(request),
        details={"role": body.role.value},
    )
    await db.commit()
    return user_out(row)


@router.get("", response_model=list[UserOut])
async def list_users(
    role: Role | None = None,
    is_active: bool | None = None,
    limit: int = Query(500, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    rows = (
        await db.execute(
            text(
                f"""
                SELECT {USER_COLUMNS} FROM users
                WHERE (CAST(:role AS text) IS NULL OR role = CAST(CAST(:role AS text) AS user_role))
                  AND (CAST(:active AS boolean) IS NULL OR is_active = CAST(:active AS boolean))
                ORDER BY full_name, id
                LIMIT :limit OFFSET :offset
                """
            ),
            {
                "role": role.value if role else None,
                "active": is_active,
                "limit": limit,
                "offset": offset,
            },
        )
    ).mappings().all()
    return [user_out(r) for r in rows]


@router.patch("/{user_id}/active", response_model=UserOut)
async def set_active(
    user_id: UUID,
    body: SetActiveRequest,
    request: Request,
    manager: AuthUser = Depends(require_manager),
    db: AsyncSession = Depends(get_db),
):
    if user_id == manager.id and not body.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="You cannot deactivate your own account"
        )
    row = (
        await db.execute(
            text(
                f"""
                UPDATE users SET is_active = :active,
                                 token_version = token_version + 1,  -- kills live sessions
                                 failed_login_count = 0, locked_until = NULL
                WHERE id = :id
                RETURNING {USER_COLUMNS}
                """
            ),
            {"active": body.is_active, "id": user_id},
        )
    ).mappings().first()
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    await write_audit(
        db,
        actor_id=manager.id,
        action="USER_ACTIVATED" if body.is_active else "USER_DEACTIVATED",
        entity_type="user",
        entity_id=str(user_id),
        ip=client_ip(request),
    )
    await db.commit()
    return user_out(row)


@router.put("/{user_id}/password", response_model=UserOut)
async def reset_password(
    user_id: UUID,
    body: ResetPasswordRequest,
    request: Request,
    manager: AuthUser = Depends(require_manager),
    db: AsyncSession = Depends(get_db),
):
    """Manager sets a new password (forgotten password / unlock). The user's
    existing sessions are revoked and any lockout is cleared."""
    new_hash = await hash_password(body.new_password)
    row = (
        await db.execute(
            text(
                f"""
                UPDATE users SET password_hash = :h, token_version = token_version + 1,
                                 failed_login_count = 0, locked_until = NULL
                WHERE id = :id
                RETURNING {USER_COLUMNS}
                """
            ),
            {"h": new_hash, "id": user_id},
        )
    ).mappings().first()
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    await write_audit(
        db,
        actor_id=manager.id,
        action="PASSWORD_RESET_BY_MANAGER",
        entity_type="user",
        entity_id=str(user_id),
        ip=client_ip(request),
    )
    await db.commit()
    return user_out(row)

import ipaddress
import time
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.db import get_db
from app.core.security import (
    create_access_token,
    hash_password,
    needs_rehash,
    verify_dummy,
    verify_password,
)
from app.middleware.auth import AuthUser, get_current_user
from app.schemas.auth import ChangePasswordRequest, LoginRequest, UserOut
from app.services.audit import write_audit

settings = get_settings()
router = APIRouter(prefix="/api/auth", tags=["auth"])

INVALID_CREDENTIALS = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password"
)

USER_COLUMNS = "id, email, full_name, role, is_active, last_login_at, created_at"


def client_ip(request: Request) -> str | None:
    host = request.client.host if request.client else None
    try:
        return str(ipaddress.ip_address(host)) if host else None
    except ValueError:
        return None


def set_session_cookie(response: Response, token: str) -> None:
    response.set_cookie(
        key=settings.cookie_name,
        value=token,
        max_age=settings.access_token_minutes * 60,
        httponly=True,  # not readable from JavaScript
        secure=settings.cookie_secure,
        samesite=settings.cookie_samesite,
        path="/",
    )


def clear_session_cookie(response: Response) -> None:
    response.delete_cookie(
        key=settings.cookie_name,
        path="/",
        httponly=True,
        secure=settings.cookie_secure,
        samesite=settings.cookie_samesite,
    )


def user_out(row) -> UserOut:
    return UserOut(
        id=row["id"],
        email=str(row["email"]),
        full_name=row["full_name"],
        role=row["role"],
        is_active=row["is_active"],
        last_login_at=row["last_login_at"],
        created_at=row["created_at"],
    )


async def register_failure(db: AsyncSession, user_id: UUID) -> None:
    """Atomically count a failed attempt; lock the account when the limit is hit."""
    await db.execute(
        text(
            """
            UPDATE users SET
              failed_login_count = CASE WHEN failed_login_count + 1 >= :max_fails
                                        THEN 0 ELSE failed_login_count + 1 END,
              locked_until = CASE WHEN failed_login_count + 1 >= :max_fails
                                  THEN now() + make_interval(mins => :lock_mins)
                                  ELSE locked_until END
            WHERE id = :id
            """
        ),
        {
            "id": user_id,
            "max_fails": settings.max_failed_logins,
            "lock_mins": settings.lockout_minutes,
        },
    )


@router.post("/login", response_model=UserOut)
async def login(
    body: LoginRequest,
    request: Request,
    response: Response,
    db: AsyncSession = Depends(get_db),
):
    ip = client_ip(request)

    # FOR UPDATE serialises concurrent attempts on the same account, so a burst
    # of parallel guesses cannot slip past the lockout counter.
    row = (
        await db.execute(
            text(
                """
                SELECT id, email, full_name, role, password_hash, is_active,
                       token_version, last_login_at, created_at,
                       (locked_until IS NOT NULL AND locked_until > now()) AS is_locked,
                       COALESCE(EXTRACT(EPOCH FROM (locked_until - now())), 0) AS lock_seconds
                FROM users
                WHERE email = CAST(CAST(:email AS text) AS citext)
                FOR UPDATE
                """
            ),
            {"email": str(body.email)},
        )
    ).mappings().first()

    if row is None:
        await verify_dummy()  # same cost as a real check: no user enumeration by timing
        await write_audit(
            db, actor_id=None, action="LOGIN_FAILED", ip=ip, details={"reason": "unknown_user"}
        )
        await db.commit()
        raise INVALID_CREDENTIALS

    if row["is_locked"]:
        await write_audit(db, actor_id=row["id"], action="LOGIN_BLOCKED", ip=ip)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many failed attempts. Try again later.",
            headers={"Retry-After": str(max(1, int(row["lock_seconds"])))},
        )

    password_ok = await verify_password(row["password_hash"], body.password)
    if not password_ok:
        await register_failure(db, row["id"])
        await write_audit(
            db, actor_id=row["id"], action="LOGIN_FAILED", ip=ip, details={"reason": "bad_password"}
        )
        await db.commit()
        raise INVALID_CREDENTIALS

    if not row["is_active"]:
        await write_audit(
            db, actor_id=row["id"], action="LOGIN_FAILED", ip=ip, details={"reason": "inactive"}
        )
        await db.commit()
        raise INVALID_CREDENTIALS

    # Transparent upgrade when cost parameters were raised after this hash was made.
    new_hash = await hash_password(body.password) if needs_rehash(row["password_hash"]) else None
    updated = (
        await db.execute(
            text(
                """
                UPDATE users SET failed_login_count = 0, locked_until = NULL,
                                 last_login_at = now(),
                                 password_hash = COALESCE(:new_hash, password_hash)
                WHERE id = :id
                RETURNING last_login_at
                """
            ),
            {"id": row["id"], "new_hash": new_hash},
        )
    ).mappings().one()
    await write_audit(db, actor_id=row["id"], action="LOGIN", ip=ip)
    await db.commit()

    set_session_cookie(
        response, create_access_token(row["id"], row["role"], row["token_version"])
    )
    return user_out({**row, "last_login_at": updated["last_login_at"]})


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(response: Response):
    clear_session_cookie(response)


@router.post("/logout-all", status_code=status.HTTP_204_NO_CONTENT)
async def logout_all(
    request: Request,
    response: Response,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Sign out every device: bumping token_version invalidates all issued tokens."""
    await db.execute(
        text("UPDATE users SET token_version = token_version + 1 WHERE id = :id"),
        {"id": user.id},
    )
    await write_audit(db, actor_id=user.id, action="LOGOUT_ALL", ip=client_ip(request))
    await db.commit()
    clear_session_cookie(response)


@router.get("/me", response_model=UserOut)
async def me(user: AuthUser = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    row = (
        await db.execute(text(f"SELECT {USER_COLUMNS} FROM users WHERE id = :id"), {"id": user.id})
    ).mappings().one()
    return user_out(row)


@router.post("/refresh", response_model=UserOut)
async def refresh(
    response: Response,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Sliding session: re-issue the short-lived token, up to MAX_SESSION_HOURS
    after the original login."""
    if time.time() - user.auth_time > settings.max_session_hours * 3600:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Session expired")
    set_session_cookie(
        response,
        create_access_token(user.id, user.role.value, user.token_version, auth_time=user.auth_time),
    )
    row = (
        await db.execute(text(f"SELECT {USER_COLUMNS} FROM users WHERE id = :id"), {"id": user.id})
    ).mappings().one()
    return user_out(row)


@router.post("/change-password", response_model=UserOut)
async def change_password(
    body: ChangePasswordRequest,
    request: Request,
    response: Response,
    user: AuthUser = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    ip = client_ip(request)
    current = (
        await db.execute(
            text("SELECT password_hash FROM users WHERE id = :id FOR UPDATE"), {"id": user.id}
        )
    ).mappings().one()

    if not await verify_password(current["password_hash"], body.current_password):
        # A stolen session must not be able to brute-force the current password.
        await register_failure(db, user.id)
        await write_audit(
            db, actor_id=user.id, action="PASSWORD_CHANGE_FAILED", ip=ip
        )
        await db.commit()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Current password is incorrect")

    if body.new_password == body.current_password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="New password must differ from the current one",
        )

    new_hash = await hash_password(body.new_password)
    row = (
        await db.execute(
            text(
                f"""
                UPDATE users SET password_hash = :h, token_version = token_version + 1,
                                 failed_login_count = 0, locked_until = NULL
                WHERE id = :id
                RETURNING {USER_COLUMNS}, token_version
                """
            ),
            {"h": new_hash, "id": user.id},
        )
    ).mappings().one()
    await write_audit(db, actor_id=user.id, action="PASSWORD_CHANGED", ip=ip)
    await db.commit()

    # Every other device is now signed out; this one gets a fresh token.
    set_session_cookie(
        response, create_access_token(user.id, user.role.value, row["token_version"])
    )
    return user_out(row)

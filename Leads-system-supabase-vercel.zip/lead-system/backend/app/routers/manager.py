"""Systems Manager endpoints: global read/write over every lead, the expired
archive, performance statistics and reassignment."""
from datetime import datetime
from typing import Literal
from uuid import UUID
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.db import get_db
from app.middleware.auth import AuthUser
from app.middleware.rbac import require_manager
from app.routers.auth import client_ip
from app.schemas.leads import (
    ArchiveOut,
    ArchivePage,
    AssignmentOut,
    AssignRequest,
    ActivityOut,
    ClientTotals,
    EmployeePerformance,
    LeadState,
    LeadStatus,
    LeadUpdate,
    ManagerLeadCreate,
    ManagerLeadCreated,
    ManagerLeadDetail,
    ManagerLeadOut,
    ManagerLeadPage,
    ManagerStats,
    StatusCounts,
)
from app.services.audit import write_audit
from app.services.leads import (
    MANAGER_COLS,
    MANAGER_FROM,
    InvalidAssignee,
    LeadConflict,
    LeadNotFound,
    VersionConflict,
    assign_lead,
    conflict_http,
    enter_lead,
    fetch_activities,
    fetch_manager_lead,
    search_clause,
    update_lead,
    version_http,
)

settings = get_settings()
router = APIRouter(
    prefix="/api/manager", tags=["manager"], dependencies=[Depends(require_manager)]
)

SORTS = {
    "-entered_at": "l.entered_at DESC, l.id",
    "entered_at": "l.entered_at ASC, l.id",
    "expires_at": "l.expires_at ASC, l.id",
    "client_name": "lower(l.client_name) ASC, l.id",
}

LEAD_NOT_FOUND = HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Client not found")
BAD_ASSIGNEE = HTTPException(
    status_code=422,
    detail="The assignee must be an active employee",
)


def _aware(dt: datetime | None) -> datetime | None:
    """Date filters without an offset are read in the business timezone."""
    if dt is not None and dt.tzinfo is None:
        return dt.replace(tzinfo=ZoneInfo(settings.followup_timezone))
    return dt


# ---------------------------------------------------------------- statistics
@router.get("/stats", response_model=ManagerStats)
async def stats(db: AsyncSession = Depends(get_db)):
    """Total clients, solved clients, the status breakdown (new / pending /
    saving / solved) and a per-employee conversion audit."""
    rows = (
        await db.execute(
            text("SELECT state, status, count(*) AS c FROM leads GROUP BY state, status")
        )
    ).mappings().all()

    by_status = {s.value: 0 for s in LeadStatus}
    active_by_status = dict(by_status)
    active = expired = 0
    for r in rows:
        by_status[r["status"]] += r["c"]
        if r["state"] == "ACTIVE":
            active += r["c"]
            active_by_status[r["status"]] += r["c"]
        else:
            expired += r["c"]

    employees = (
        await db.execute(
            text("SELECT * FROM v_employee_conversion ORDER BY conversion_pct DESC, full_name")
        )
    ).mappings().all()

    return ManagerStats(
        totals=ClientTotals(
            total_clients=active + expired,
            solved_clients=by_status["SOLVED"],
            active_clients=active,
            expired_clients=expired,
            by_status=StatusCounts(**by_status),
            active_by_status=StatusCounts(**active_by_status),
        ),
        employees=[EmployeePerformance(**e) for e in employees],
        generated_at=await db.scalar(text("SELECT now()")),
    )


# -------------------------------------------------------------------- leads
@router.get("/leads", response_model=ManagerLeadPage)
async def list_leads(
    state: LeadState | None = None,
    status_filter: LeadStatus | None = Query(None, alias="status"),
    employee_id: UUID | None = None,
    q: str | None = Query(None, max_length=100),
    entered_from: datetime | None = None,
    entered_to: datetime | None = None,
    sort: Literal["-entered_at", "entered_at", "expires_at", "client_name"] = "-entered_at",
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    where = ["TRUE"]
    params: dict = {}
    if state:
        where.append("l.state = CAST(CAST(:state AS text) AS lead_state)")
        params["state"] = state.value
    if status_filter:
        where.append("l.status = CAST(CAST(:status AS text) AS lead_status)")
        params["status"] = status_filter.value
    if employee_id:
        where.append("l.assigned_employee_id = :emp")
        params["emp"] = employee_id
    if entered_from:
        where.append("l.entered_at >= :efrom")
        params["efrom"] = _aware(entered_from)
    if entered_to:
        where.append("l.entered_at < :eto")
        params["eto"] = _aware(entered_to)
    if q and q.strip():
        where.append(search_clause(q, params))
    clause = " AND ".join(where)

    total = await db.scalar(text(f"SELECT count(*) FROM leads l WHERE {clause}"), params)
    rows = (
        await db.execute(
            text(
                f"SELECT {MANAGER_COLS} {MANAGER_FROM} WHERE {clause} "
                f"ORDER BY {SORTS[sort]} LIMIT :limit OFFSET :offset"
            ),
            {**params, "limit": limit, "offset": offset},
        )
    ).mappings().all()
    return ManagerLeadPage(
        items=[ManagerLeadOut(**r) for r in rows],
        total=total,
        server_time=await db.scalar(text("SELECT now()")),
    )


@router.post("/leads", response_model=ManagerLeadCreated, status_code=status.HTTP_201_CREATED)
async def create_lead(
    body: ManagerLeadCreate,
    request: Request,
    manager: AuthUser = Depends(require_manager),
    db: AsyncSession = Depends(get_db),
):
    """Create a client and assign it to an employee (21 days start now). If the
    number belongs to an expired client, that client is re-assigned instead."""
    try:
        await _require_assignable(db, body.employee_id)  # before touching any data
        lead_id, source = await enter_lead(
            db,
            actor_id=manager.id,
            owner_id=body.employee_id,
            by_manager=True,
            name=body.client_name,
            phone=body.phone,
            email=str(body.email) if body.email else None,
            notes=body.notes,
        )
    except LeadConflict as exc:
        await db.rollback()
        raise conflict_http(exc, expose_lead_id=True)
    except InvalidAssignee:
        await db.rollback()
        raise BAD_ASSIGNEE
    await write_audit(
        db, actor_id=manager.id, action="LEAD_CREATED", entity_type="lead",
        entity_id=str(lead_id), ip=client_ip(request),
        details={"assigned_to": str(body.employee_id), "source": source},
    )
    await db.commit()
    return ManagerLeadCreated(**await fetch_manager_lead(db, lead_id), source=source)


async def _require_assignable(db: AsyncSession, employee_id: UUID) -> None:
    target = (
        await db.execute(
            text("SELECT role, is_active FROM users WHERE id = :id"), {"id": employee_id}
        )
    ).mappings().first()
    if target is None or target["role"] != "EMPLOYEE" or not target["is_active"]:
        raise InvalidAssignee


@router.get("/leads/{lead_id}", response_model=ManagerLeadDetail)
async def lead_detail(lead_id: UUID, db: AsyncSession = Depends(get_db)):
    lead = await fetch_manager_lead(db, lead_id)
    if lead is None:
        raise LEAD_NOT_FOUND
    assignments = (
        await db.execute(
            text(
                """
                SELECT a.id, a.employee_id, e.full_name AS employee_name, a.source,
                       b.full_name AS assigned_by_name, a.assigned_at, a.ended_at, a.end_reason
                FROM lead_assignments a
                JOIN users e ON e.id = a.employee_id
                LEFT JOIN users b ON b.id = a.assigned_by
                WHERE a.lead_id = :id ORDER BY a.assigned_at, a.id
                """
            ),
            {"id": lead_id},
        )
    ).mappings().all()
    return ManagerLeadDetail(
        lead=ManagerLeadOut(**lead),
        assignments=[AssignmentOut(**a) for a in assignments],
        activities=[ActivityOut(**a) for a in await fetch_activities(db, lead_id)],
    )


@router.patch("/leads/{lead_id}", response_model=ManagerLeadOut)
async def patch_lead(
    lead_id: UUID,
    body: LeadUpdate,
    request: Request,
    manager: AuthUser = Depends(require_manager),
    db: AsyncSession = Depends(get_db),
):
    changes = body.changes()
    try:
        await update_lead(
            db, lead_id=lead_id, actor_id=manager.id, owner_scope=None,
            version=body.version, changes=changes,
        )
    except LeadNotFound:
        await db.rollback()
        raise LEAD_NOT_FOUND
    except VersionConflict as exc:
        await db.rollback()
        raise version_http(exc)
    except LeadConflict as exc:
        await db.rollback()
        raise conflict_http(exc, expose_lead_id=True)
    await write_audit(
        db, actor_id=manager.id, action="LEAD_UPDATED", entity_type="lead",
        entity_id=str(lead_id), ip=client_ip(request), details={"fields": sorted(changes)},
    )
    await db.commit()
    return ManagerLeadOut(**await fetch_manager_lead(db, lead_id))


@router.post("/leads/{lead_id}/assign", response_model=ManagerLeadOut)
async def assign(
    lead_id: UUID,
    body: AssignRequest,
    request: Request,
    manager: AuthUser = Depends(require_manager),
    db: AsyncSession = Depends(get_db),
):
    """Assign or reassign a lead, expired or not, to an employee with a fresh
    21-day window."""
    try:
        previous = await assign_lead(
            db, lead_id=lead_id, employee_id=body.employee_id, actor_id=manager.id
        )
    except LeadNotFound:
        await db.rollback()
        raise LEAD_NOT_FOUND
    except InvalidAssignee:
        await db.rollback()
        raise BAD_ASSIGNEE
    except LeadConflict as exc:
        await db.rollback()
        raise conflict_http(exc, expose_lead_id=True)
    await write_audit(
        db, actor_id=manager.id, action="LEAD_REASSIGNED", entity_type="lead",
        entity_id=str(lead_id), ip=client_ip(request),
        details={
            "from_state": previous["state"],
            "from_employee": str(previous["owner_id"]) if previous["owner_id"] else None,
            "to_employee": str(body.employee_id),
        },
    )
    await db.commit()
    return ManagerLeadOut(**await fetch_manager_lead(db, lead_id))


# ------------------------------------------------------------------ archive
@router.get("/archive", response_model=ArchivePage)
async def archive(
    previous_owner_id: UUID | None = None,
    reassigned: bool | None = Query(None, description="true = already given back out, false = still waiting in the pool"),
    q: str | None = Query(None, max_length=100),
    expired_from: datetime | None = None,
    expired_to: datetime | None = None,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """The expired_clients_archive table: who owned each client, when it expired,
    and whether it has been given back out."""
    where = ["TRUE"]
    params: dict = {}
    if previous_owner_id:
        where.append("a.previous_owner_id = :owner")
        params["owner"] = previous_owner_id
    if reassigned is not None:
        where.append("a.reassigned_at IS NOT NULL" if reassigned else "a.reassigned_at IS NULL")
    if expired_from:
        where.append("a.expired_at >= :xfrom")
        params["xfrom"] = _aware(expired_from)
    if expired_to:
        where.append("a.expired_at < :xto")
        params["xto"] = _aware(expired_to)
    if q and q.strip():
        where.append(search_clause(q, params, name_col="a.client_name", phone_col="a.phone"))
    clause = " AND ".join(where)

    total = await db.scalar(
        text(f"SELECT count(*) FROM expired_clients_archive a WHERE {clause}"), params
    )
    rows = (
        await db.execute(
            text(
                f"""
                SELECT a.id, a.lead_id, a.client_name, a.phone, a.email, a.notes,
                       a.status_at_expiry, a.previous_owner_id, a.previous_owner_name,
                       a.entered_at, a.assigned_at, a.expired_at, a.ownership_history,
                       a.reassigned_at, a.reassigned_to, rt.full_name AS reassigned_to_name,
                       a.reassigned_by
                FROM expired_clients_archive a
                LEFT JOIN users rt ON rt.id = a.reassigned_to
                WHERE {clause}
                ORDER BY a.expired_at DESC, a.id DESC
                LIMIT :limit OFFSET :offset
                """
            ),
            {**params, "limit": limit, "offset": offset},
        )
    ).mappings().all()
    return ArchivePage(items=[ArchiveOut(**r) for r in rows], total=total)

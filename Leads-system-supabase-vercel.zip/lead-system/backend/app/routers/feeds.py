"""Tokenised .ics subscription feed.

An employee creates a private URL once and subscribes to it from the phone's
Calendar app (webcal://...). Only the SHA-256 of the token is stored, so a
database leak cannot reveal working feed URLs. Rotating or deleting the token
cuts off every device that subscribed with the old one.
"""
import hashlib
import secrets
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.db import get_db
from app.middleware.auth import AuthUser
from app.middleware.rbac import require_employee
from app.services.ics import build_calendar
from app.services.leads import OWNER_VISIBLE

settings = get_settings()

api_router = APIRouter(
    prefix="/api/feeds", tags=["calendar feed"], dependencies=[Depends(require_employee)]
)
public_router = APIRouter(tags=["calendar feed"])


class FeedTokenOut(BaseModel):
    url: str
    webcal_url: str
    created_at: datetime


class FeedStatus(BaseModel):
    active: bool
    created_at: datetime | None = None
    last_used_at: datetime | None = None


def _digest(token: str) -> bytes:
    return hashlib.sha256(token.encode()).digest()


@api_router.post("/token", response_model=FeedTokenOut, status_code=status.HTTP_201_CREATED)
async def create_token(
    user: AuthUser = Depends(require_employee), db: AsyncSession = Depends(get_db)
):
    """Creates (or rotates) your private feed URL. It is shown once; any previous
    URL stops working immediately."""
    raw = secrets.token_urlsafe(32)
    try:
        await db.execute(
            text(
                "UPDATE calendar_feed_tokens SET revoked_at = now() "
                "WHERE user_id = :u AND revoked_at IS NULL"
            ),
            {"u": user.id},
        )
        row = (
            await db.execute(
                text(
                    "INSERT INTO calendar_feed_tokens (user_id, token_hash) "
                    "VALUES (:u, :h) RETURNING created_at"
                ),
                {"u": user.id, "h": _digest(raw)},
            )
        ).mappings().one()
    except IntegrityError:  # two rotations at the same instant
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Try again")
    await db.commit()

    base = settings.public_base_url.rstrip("/")
    url = f"{base}/feeds/{raw}.ics"
    webcal = "webcal://" + url.split("://", 1)[1]
    return FeedTokenOut(url=url, webcal_url=webcal, created_at=row["created_at"])


@api_router.get("/token", response_model=FeedStatus)
async def token_status(
    user: AuthUser = Depends(require_employee), db: AsyncSession = Depends(get_db)
):
    row = (
        await db.execute(
            text(
                "SELECT created_at, last_used_at FROM calendar_feed_tokens "
                "WHERE user_id = :u AND revoked_at IS NULL"
            ),
            {"u": user.id},
        )
    ).mappings().first()
    if row is None:
        return FeedStatus(active=False)
    return FeedStatus(active=True, created_at=row["created_at"], last_used_at=row["last_used_at"])


@api_router.delete("/token", status_code=status.HTTP_204_NO_CONTENT)
async def revoke_token(
    user: AuthUser = Depends(require_employee), db: AsyncSession = Depends(get_db)
):
    await db.execute(
        text(
            "UPDATE calendar_feed_tokens SET revoked_at = now() "
            "WHERE user_id = :u AND revoked_at IS NULL"
        ),
        {"u": user.id},
    )
    await db.commit()


@public_router.get("/feeds/{token}.ics", include_in_schema=False)
async def calendar_feed(token: str, db: AsyncSession = Depends(get_db)):
    """Public by design (calendar apps can't log in): the token is the credential.
    Unknown, revoked and deactivated-user tokens all answer the same 404."""
    owner = (
        await db.execute(
            text(
                """
                SELECT t.id AS token_id, u.id AS user_id, u.full_name
                FROM calendar_feed_tokens t JOIN users u ON u.id = t.user_id
                WHERE t.token_hash = :h AND t.revoked_at IS NULL
                  AND u.is_active AND u.role = 'EMPLOYEE'
                """
            ),
            {"h": _digest(token)},
        )
    ).mappings().first()
    if owner is None:
        # Same body as the framework's own 404, so a bad token is indistinguishable
        # from a path that doesn't exist.
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Not Found")

    # Throttled so a client polling every minute doesn't write on every request.
    await db.execute(
        text(
            "UPDATE calendar_feed_tokens SET last_used_at = now() WHERE id = :id "
            "AND (last_used_at IS NULL OR last_used_at < now() - interval '1 minute')"
        ),
        {"id": owner["token_id"]},
    )
    # The same visibility rule as the dashboard: expired and overdue leads never appear.
    leads = (
        await db.execute(
            text(
                f"""
                SELECT l.id, l.client_name, l.phone, l.status, l.assigned_at, l.expires_at,
                       l.version, l.updated_at, l.solved_at
                FROM leads l WHERE {OWNER_VISIBLE}
                ORDER BY l.expires_at LIMIT 2000
                """
            ),
            {"uid": owner["user_id"]},
        )
    ).mappings().all()
    await db.commit()

    body = build_calendar(calendar_name=f"Lead follow-ups - {owner['full_name']}", leads=leads)
    return Response(
        content=body,
        media_type="text/calendar; charset=utf-8",
        headers={"Cache-Control": "private, max-age=300"},
    )

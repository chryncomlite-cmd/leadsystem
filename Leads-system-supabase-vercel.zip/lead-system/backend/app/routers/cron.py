"""Scheduled jobs, callable by Vercel Cron.

Primary scheduler: pg_cron inside Supabase (db/supabase/schedule_expiry.sql).
This endpoint is the fallback, e.g. when pg_cron isn't enabled. Vercel Cron sends
`Authorization: Bearer $CRON_SECRET` on its own when CRON_SECRET is set.
"""
import secrets

from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.db import get_db

settings = get_settings()
router = APIRouter(prefix="/api/cron", tags=["cron"], include_in_schema=False)


def require_cron_secret(authorization: str | None = Header(default=None)) -> None:
    configured = settings.cron_secret
    if configured is None:
        # Not configured: behave like a path that doesn't exist.
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Not Found")
    supplied = (authorization or "").removeprefix("Bearer ").strip()
    if not secrets.compare_digest(supplied.encode(), configured.get_secret_value().encode()):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized")


@router.get("/expire", dependencies=[Depends(require_cron_secret)])
async def expire(db: AsyncSession = Depends(get_db)):
    """Moves every lead past Day 21 into the expired pool (idempotent)."""
    expired = await db.scalar(text("SELECT expire_due_leads()"))
    await db.commit()
    return {"expired": expired}

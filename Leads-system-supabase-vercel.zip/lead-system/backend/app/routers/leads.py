"""Employee-facing lead endpoints.

Every query is scoped to the caller's own ACTIVE, unexpired leads. A lead that
belongs to someone else, or has expired, answers 404 exactly as a lead that never
existed would, so nothing about other people's clients leaks.
"""
from typing import Literal
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.db import get_db
from app.middleware.auth import AuthUser
from app.middleware.rbac import require_employee
from app.schemas.leads import (
    ActivityCreate,
    ActivityOut,
    LeadCreate,
    LeadCreated,
    LeadOut,
    LeadPage,
    LeadStats,
    LeadStatus,
    LeadUpdate,
)
from app.services.leads import (
    LEAD_COLS,
    OWNER_VISIBLE,
    LeadConflict,
    LeadNotFound,
    VersionConflict,
    conflict_http,
    enter_lead,
    fetch_activities,
    fetch_owner_lead,
    log_activity,
    search_clause,
    update_lead,
    version_http,
)

router = APIRouter(
    prefix="/api/leads", tags=["leads"], dependencies=[Depends(require_employee)]
)

SORTS = {
    "expires_at": "l.expires_at ASC, l.id",
    "entered_at": "l.entered_at ASC, l.id",
    "-entered_at": "l.entered_at DESC, l.id",
    "client_name": "lower(l.client_name) ASC, l.id",
}

NOT_FOUND = HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Client not found")


@router.post("", response_model=LeadCreated, status_code=status.HTTP_201_CREATED)
async def create_lead(
    body: LeadCreate,
    user: AuthUser = Depends(require_employee),
    db: AsyncSession = Depends(get_db),
):
    """Enter a new client. If the number belongs to an expired client in the pool,
    it is claimed instead (source = CLAIMED). Either way the 21 days start now."""
    try:
        lead_id, source = await enter_lead(
            db,
            actor_id=user.id,
            owner_id=user.id,
            by_manager=False,
            name=body.client_name,
            phone=body.phone,
            email=str(body.email) if body.email else None,
            notes=body.notes,
        )
    except LeadConflict as exc:
        await db.rollback()
        # Only reveal the lead id when it is the caller's own lead.
        raise conflict_http(exc, expose_lead_id=exc.code == "ALREADY_YOURS")
    await db.commit()
    row = await fetch_owner_lead(db, lead_id, user.id)
    return LeadCreated(**row, source=source)


@router.get("", response_model=LeadPage)
async def list_leads(
    status_filter: LeadStatus | None = Query(None, alias="status"),
    q: str | None = Query(None, max_length=100),
    sort: Literal["expires_at", "entered_at", "-entered_at", "client_name"] = "expires_at",
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    user: AuthUser = Depends(require_employee),
    db: AsyncSession = Depends(get_db),
):
    where = [OWNER_VISIBLE]
    params: dict = {"uid": user.id}
    if status_filter:
        where.append("l.status = CAST(CAST(:status AS text) AS lead_status)")
        params["status"] = status_filter.value
    if q and q.strip():
        where.append(search_clause(q, params))
    clause = " AND ".join(where)

    total = await db.scalar(text(f"SELECT count(*) FROM leads l WHERE {clause}"), params)
    rows = (
        await db.execute(
            text(
                f"SELECT {LEAD_COLS} FROM leads l WHERE {clause} "
                f"ORDER BY {SORTS[sort]} LIMIT :limit OFFSET :offset"
            ),
            {**params, "limit": limit, "offset": offset},
        )
    ).mappings().all()
    server_time = await db.scalar(text("SELECT now()"))
    return LeadPage(items=[LeadOut(**r) for r in rows], total=total, server_time=server_time)


@router.get("/stats", response_model=LeadStats)
async def my_stats(user: AuthUser = Depends(require_employee), db: AsyncSession = Depends(get_db)):
    row = (
        await db.execute(
            text(
                f"""
                SELECT count(*) AS total,
                       count(*) FILTER (WHERE l.status = 'NEW')     AS n_new,
                       count(*) FILTER (WHERE l.status = 'PENDING') AS n_pending,
                       count(*) FILTER (WHERE l.status = 'SAVING')  AS n_saving,
                       count(*) FILTER (WHERE l.status = 'SOLVED')  AS n_solved,
                       count(*) FILTER (WHERE l.expires_at < now() + interval '3 days') AS n_soon
                FROM leads l WHERE {OWNER_VISIBLE}
                """
            ),
            {"uid": user.id},
        )
    ).mappings().one()
    return LeadStats(
        total=row["total"], new=row["n_new"], pending=row["n_pending"],
        saving=row["n_saving"], solved=row["n_solved"], expiring_soon=row["n_soon"],
    )


@router.get("/{lead_id}", response_model=LeadOut)
async def get_lead(
    lead_id: UUID, user: AuthUser = Depends(require_employee), db: AsyncSession = Depends(get_db)
):
    row = await fetch_owner_lead(db, lead_id, user.id)
    if row is None:
        raise NOT_FOUND
    return LeadOut(**row)


@router.patch("/{lead_id}", response_model=LeadOut)
async def patch_lead(
    lead_id: UUID,
    body: LeadUpdate,
    user: AuthUser = Depends(require_employee),
    db: AsyncSession = Depends(get_db),
):
    try:
        await update_lead(
            db,
            lead_id=lead_id,
            actor_id=user.id,
            owner_scope=user.id,
            version=body.version,
            changes=body.changes(),
        )
    except LeadNotFound:
        await db.rollback()
        raise NOT_FOUND
    except VersionConflict as exc:
        await db.rollback()
        raise version_http(exc)
    except LeadConflict as exc:
        await db.rollback()
        raise conflict_http(exc, expose_lead_id=False)
    await db.commit()
    return LeadOut(**await fetch_owner_lead(db, lead_id, user.id))


@router.get("/{lead_id}/activities", response_model=list[ActivityOut])
async def list_activities(
    lead_id: UUID, user: AuthUser = Depends(require_employee), db: AsyncSession = Depends(get_db)
):
    if await fetch_owner_lead(db, lead_id, user.id) is None:
        raise NOT_FOUND
    return [ActivityOut(**r) for r in await fetch_activities(db, lead_id)]


@router.post(
    "/{lead_id}/activities", response_model=ActivityOut, status_code=status.HTTP_201_CREATED
)
async def add_activity(
    lead_id: UUID,
    body: ActivityCreate,
    user: AuthUser = Depends(require_employee),
    db: AsyncSession = Depends(get_db),
):
    """Log a call or note against one of your clients."""
    if await fetch_owner_lead(db, lead_id, user.id) is None:
        raise NOT_FOUND
    activity_id = await log_activity(db, lead_id, user.id, body.kind, body=body.body)
    await db.commit()
    (row,) = await fetch_activities(db, lead_id, activity_id=activity_id)
    return ActivityOut(**row)

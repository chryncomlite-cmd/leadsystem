"""Role-based access control guards.

Usage:
    router = APIRouter(dependencies=[Depends(require_manager)])   # whole router
    async def handler(user: AuthUser = Depends(require_employee)) # one route

Employee routes are EMPLOYEE-only on purpose: managers reach lead data through
the /api/manager/* routes, which keep their global view and every override
action separate from the employee-scoped queries.
"""
from fastapi import Depends, HTTPException, status

from app.middleware.auth import AuthUser, get_current_user
from app.schemas.auth import Role


def require_roles(*allowed: Role):
    async def guard(user: AuthUser = Depends(get_current_user)) -> AuthUser:
        if user.role not in allowed:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient permissions"
            )
        return user

    return guard


require_employee = require_roles(Role.EMPLOYEE)
require_manager = require_roles(Role.SYSTEM_MANAGER)

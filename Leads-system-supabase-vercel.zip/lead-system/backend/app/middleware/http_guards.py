"""HTTP-level protections: CSRF origin check and security headers."""
from urllib.parse import urlsplit

from fastapi import Request
from fastapi.responses import JSONResponse

from app.core.config import get_settings

settings = get_settings()

_UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}


def _origin_of(url: str | None) -> str | None:
    if not url:
        return None
    parts = urlsplit(url)
    if not parts.scheme or not parts.netloc:
        return None
    return f"{parts.scheme}://{parts.netloc}"


async def origin_guard(request: Request, call_next):
    """Defence in depth on top of SameSite cookies: every state-changing request
    must come from a configured browser origin (Origin, else Referer)."""
    if request.method in _UNSAFE_METHODS:
        origin = request.headers.get("origin") or _origin_of(request.headers.get("referer"))
        if origin not in settings.allowed_origins:
            return JSONResponse(status_code=403, content={"detail": "Origin not allowed"})
    return await call_next(request)


async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    if settings.environment == "production":
        response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
    return response

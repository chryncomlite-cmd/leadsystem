"""Authentication dependency: cookie -> verified JWT -> live user row."""
from dataclasses import dataclass
from typing import Annotated
from uuid import UUID

import jwt
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.db import get_db
from app.core.security import decode_access_token
from app.schemas.auth import Role

settings = get_settings()


@dataclass(frozen=True)
class AuthUser:
    id: UUID
    email: str
    full_name: str
    role: Role
    token_version: int
    auth_time: int


def _unauthorized() -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Cookie"},
    )


async def get_current_user(
    request: Request, db: AsyncSession = Depends(get_db)
) -> AuthUser:
    token = request.cookies.get(settings.cookie_name)
    if not token:
        raise _unauthorized()
    try:
        claims = decode_access_token(token)
        user_id = UUID(claims["sub"])
        token_version = int(claims["tv"])
        auth_time = int(claims.get("at", claims["iat"]))
    except (jwt.InvalidTokenError, ValueError, KeyError, TypeError):
        raise _unauthorized()

    # The database is authoritative for role, active flag and revocation, so a
    # deactivated, demoted or password-reset user loses access on the very next
    # request instead of when the token expires.
    row = (
        await db.execute(
            text(
                "SELECT id, email, full_name, role, is_active, token_version "
                "FROM users WHERE id = :id"
            ),
            {"id": user_id},
        )
    ).mappings().first()
    if row is None or not row["is_active"] or row["token_version"] != token_version:
        raise _unauthorized()

    user = AuthUser(
        id=row["id"],
        email=str(row["email"]),
        full_name=row["full_name"],
        role=Role(row["role"]),
        token_version=row["token_version"],
        auth_time=auth_time,
    )
    request.state.user = user
    return user


CurrentUser = Annotated[AuthUser, Depends(get_current_user)]

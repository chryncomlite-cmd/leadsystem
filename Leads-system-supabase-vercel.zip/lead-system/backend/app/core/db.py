import uuid
from collections.abc import AsyncIterator

from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from app.core.config import get_settings

settings = get_settings()


def build_engine_args() -> tuple[str, dict]:
    """Translate DATABASE_URL + settings into (url, create_async_engine kwargs).

    Handles what asyncpg does not understand by itself:
      * ?sslmode=require (libpq-style, as copied from the Supabase dashboard)
      * Supabase's pooler (Supavisor) in transaction mode, which cannot keep
        server-side prepared statements between queries
      * serverless hosts (Vercel), where a connection pool inside a short-lived
        function only wastes connections: the Supabase pooler does the pooling.
    """
    url = make_url(settings.database_url)
    query = dict(url.query)
    sslmode = query.pop("sslmode", None)
    url = url.set(query=query)

    host = url.host or ""
    is_supabase = host.endswith(".supabase.com") or host.endswith(".supabase.co")

    use_ssl = settings.db_ssl
    if use_ssl is None:
        use_ssl = (sslmode in {"require", "verify-ca", "verify-full"}) or is_supabase

    use_pgbouncer = settings.db_pgbouncer
    if use_pgbouncer is None:
        use_pgbouncer = "pooler.supabase.com" in host and url.port == 6543

    connect_args: dict = {}
    if use_ssl:
        connect_args["ssl"] = "require"
    if use_pgbouncer:
        connect_args.update(
            statement_cache_size=0,  # asyncpg's own cache
            prepared_statement_cache_size=0,  # SQLAlchemy's asyncpg adapter cache
            prepared_statement_name_func=lambda: f"__asyncpg_{uuid.uuid4()}__",
        )

    kwargs: dict = {"pool_pre_ping": True, "connect_args": connect_args}
    if settings.db_null_pool:
        kwargs["poolclass"] = NullPool
    else:
        # 200+ concurrent users: keep the pool modest and put the pooler in front
        # in production rather than raising pool_size.
        kwargs.update(pool_size=settings.db_pool_size, max_overflow=settings.db_max_overflow)
    return url.render_as_string(hide_password=False), kwargs


_url, _kwargs = build_engine_args()
engine = create_async_engine(_url, **_kwargs)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False)


async def get_db() -> AsyncIterator[AsyncSession]:
    async with SessionLocal() as session:
        yield session

"""Password hashing (Argon2id) and session-token helpers."""
import asyncio
import secrets
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

import jwt
from argon2 import PasswordHasher, Type
from argon2.exceptions import InvalidHashError, VerificationError

from app.core.config import get_settings

settings = get_settings()

# Argon2id with a fresh random 16-byte salt per hash. The salt and cost
# parameters are embedded in the encoded string, so every account carries
# its own salt and old hashes stay verifiable after the parameters change.
_hasher = PasswordHasher(
    time_cost=settings.argon2_time_cost,
    memory_cost=settings.argon2_memory_kib,
    parallelism=settings.argon2_parallelism,
    hash_len=32,
    salt_len=16,
    type=Type.ID,
)

# Each hash holds ~memory_cost KiB while running. A dedicated, bounded pool
# caps peak memory (workers x memory_cost) when many users log in at once and
# keeps the event loop free.
_executor = ThreadPoolExecutor(
    max_workers=settings.max_concurrent_hashes, thread_name_prefix="argon2"
)

# Verified against when the account does not exist, so "unknown email" and
# "wrong password" take the same time.
_DUMMY_HASH = _hasher.hash("timing-equalisation-dummy-password")


def _verify(encoded: str, password: str) -> bool:
    try:
        return _hasher.verify(encoded, password)
    except (VerificationError, InvalidHashError):
        return False


async def hash_password(password: str) -> str:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_executor, _hasher.hash, password)


async def verify_password(encoded: str, password: str) -> bool:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_executor, _verify, encoded, password)


async def verify_dummy() -> None:
    await verify_password(_DUMMY_HASH, "not-the-password")


def needs_rehash(encoded: str) -> bool:
    return _hasher.check_needs_rehash(encoded)


# ---------------------------------------------------------------------------
# Session tokens
# ---------------------------------------------------------------------------
def create_access_token(
    user_id: uuid.UUID | str,
    role: str,
    token_version: int,
    auth_time: int | None = None,
) -> str:
    now = int(time.time())
    payload = {
        "sub": str(user_id),
        "role": role,  # informational only; the DB role is authoritative
        "tv": token_version,  # bump users.token_version to revoke every session
        "at": auth_time if auth_time is not None else now,  # original login time
        "iat": now,
        "exp": now + settings.access_token_minutes * 60,
        "jti": secrets.token_hex(8),
    }
    return jwt.encode(
        payload, settings.jwt_secret.get_secret_value(), algorithm=settings.jwt_algorithm
    )


def decode_access_token(token: str) -> dict:
    """Raises jwt.InvalidTokenError on any problem (bad signature, expired, ...)."""
    return jwt.decode(
        token,
        settings.jwt_secret.get_secret_value(),
        algorithms=[settings.jwt_algorithm],  # pins HS256; rejects alg=none
        options={"require": ["exp", "sub", "tv", "iat"]},
    )

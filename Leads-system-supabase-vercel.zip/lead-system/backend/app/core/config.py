from functools import lru_cache
from typing import Literal

from pydantic import SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    environment: Literal["development", "production", "test"] = "development"

    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/leadsystem"
    db_pool_size: int = 20
    db_max_overflow: int = 30
    # Serverless / Supabase. None = auto-detect from the URL (a *.pooler.supabase.com
    # host means TLS on, and port 6543 means transaction-mode pgbouncer).
    db_ssl: bool | None = None
    db_pgbouncer: bool | None = None  # disable asyncpg prepared-statement caching
    db_null_pool: bool = False  # True on Vercel: no pool held between invocations

    # Bearer token Vercel Cron sends to /api/cron/expire (set CRON_SECRET in Vercel).
    cron_secret: SecretStr | None = None

    # --- sessions -------------------------------------------------------
    jwt_secret: SecretStr
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 30
    max_session_hours: int = 12
    cookie_name: str = "lead_session"
    cookie_secure: bool = True
    cookie_samesite: Literal["lax", "strict"] = "lax"
    allowed_origins: list[str] = ["http://localhost:3000"]

    # --- Argon2id (OWASP "high" profile: 64 MiB, t=3) ------------------
    argon2_memory_kib: int = 65536
    argon2_time_cost: int = 3
    argon2_parallelism: int = 2
    max_concurrent_hashes: int = 8

    # --- login hardening -------------------------------------------------
    max_failed_logins: int = 5
    lockout_minutes: int = 15
    min_password_length: int = 12

    # --- leads, follow-ups, calendar feed -------------------------------
    default_country_code: str = "256"  # prefixed to local numbers such as 0700 000 001
    followup_timezone: str = "Africa/Kampala"
    followup_hour: int = 9  # local hour at which Day 1/7/14/20 reminders fire
    public_base_url: str = "http://localhost:8000"  # used to build .ics feed URLs
    # Days a previous owner must wait before re-claiming their own expired lead.
    # 0 = no restriction. Prevents keeping a client forever by re-entering it on Day 22.
    reclaim_cooldown_days: int = 0

    @field_validator("jwt_secret")
    @classmethod
    def _secret_long_enough(cls, v: SecretStr) -> SecretStr:
        if len(v.get_secret_value()) < 32:
            raise ValueError("JWT_SECRET must be at least 32 characters")
        return v

    @field_validator("database_url")
    @classmethod
    def _asyncpg_scheme(cls, v: str) -> str:
        """Supabase hands out postgresql:// URLs; SQLAlchemy needs the asyncpg driver."""
        for prefix in ("postgresql://", "postgres://"):
            if v.startswith(prefix):
                return "postgresql+asyncpg://" + v[len(prefix):]
        return v

    @field_validator("allowed_origins")
    @classmethod
    def _normalise_origins(cls, v: list[str]) -> list[str]:
        return [o.rstrip("/") for o in v]


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]

"""Core lead transactions.

Nothing here commits: the router owns the transaction, so a failure anywhere
(including a unique-violation race) rolls the whole operation back.
"""
import re
from typing import Any
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.services.followups import cancel_followups, schedule_followups
from app.services.phone import normalize_phone

settings = get_settings()

# ----------------------------------------------------------------- SQL pieces
LEAD_COLS = """
    l.id, l.client_name, l.phone, l.email, l.notes, l.status,
    l.entered_at, l.assigned_at, l.expires_at, l.version,
    CAST(GREATEST(EXTRACT(EPOCH FROM (l.expires_at - now())), 0) AS integer) AS seconds_remaining
"""
MANAGER_COLS = LEAD_COLS + """,
    l.state, l.assigned_employee_id, o.full_name AS owner_name,
    l.created_by, l.expired_at, l.solved_at
"""
MANAGER_FROM = "FROM leads l LEFT JOIN users o ON o.id = l.assigned_employee_id"

# What an employee may see. The expires_at test is deliberate: the hourly worker
# can be late, but a lead must never show on Day 22.
OWNER_VISIBLE = "l.assigned_employee_id = :uid AND l.state = 'ACTIVE' AND l.expires_at > now()"


# ------------------------------------------------------------------ errors
class LeadConflict(Exception):
    def __init__(self, code: str, lead_id: UUID | None = None):
        self.code, self.lead_id = code, lead_id


class VersionConflict(Exception):
    def __init__(self, current_version: int):
        self.current_version = current_version


class LeadNotFound(Exception):
    pass


class InvalidAssignee(Exception):
    pass


CONFLICT_MESSAGES = {
    "ALREADY_YOURS": "You already have this client.",
    "OWNED_BY_OTHER": "This client is already being followed up by another employee.",
    "COOLDOWN": "This client can't be claimed by you right now.",
    "ALREADY_ACTIVE": "This client already has an active owner.",
    "PHONE_IN_USE": "Another active client already uses this phone number.",
}


def conflict_http(exc: LeadConflict, *, expose_lead_id: bool) -> HTTPException:
    detail: dict[str, Any] = {"code": exc.code, "message": CONFLICT_MESSAGES[exc.code]}
    if expose_lead_id and exc.lead_id is not None:
        detail["lead_id"] = str(exc.lead_id)
    return HTTPException(status_code=status.HTTP_409_CONFLICT, detail=detail)


def version_http(exc: VersionConflict) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_409_CONFLICT,
        detail={
            "code": "VERSION_CONFLICT",
            "message": "This client was changed by someone else. Reload and try again.",
            "current_version": exc.current_version,
        },
    )


# ------------------------------------------------------------------ helpers
async def log_activity(
    db: AsyncSession,
    lead_id: UUID,
    actor_id: UUID | None,
    kind: str,
    body: str | None = None,
    from_status: str | None = None,
    to_status: str | None = None,
) -> int:
    return await db.scalar(
        text(
            """
            INSERT INTO lead_activities (lead_id, actor_id, kind, from_status, to_status, body)
            VALUES (:lead, :actor, :kind,
                    CAST(CAST(:fs AS text) AS lead_status),
                    CAST(CAST(:ts AS text) AS lead_status), :body)
            RETURNING id
            """
        ),
        {"lead": lead_id, "actor": actor_id, "kind": kind, "fs": from_status, "ts": to_status, "body": body},
    )


async def fetch_activities(
    db: AsyncSession, lead_id: UUID, *, activity_id: int | None = None, limit: int = 200
):
    return (
        await db.execute(
            text(
                """
                SELECT a.id, a.kind, a.body, a.from_status, a.to_status, a.actor_id,
                       u.full_name AS actor_name, a.created_at
                FROM lead_activities a LEFT JOIN users u ON u.id = a.actor_id
                WHERE a.lead_id = :lead AND (CAST(:aid AS bigint) IS NULL OR a.id = :aid)
                ORDER BY a.id DESC LIMIT :limit
                """
            ),
            {"lead": lead_id, "aid": activity_id, "limit": limit},
        )
    ).mappings().all()


async def _record_assignment(
    db: AsyncSession, lead_id: UUID, employee_id: UUID, assigned_by: UUID | None, source: str
) -> None:
    await db.execute(
        text(
            """
            INSERT INTO lead_assignments (lead_id, employee_id, assigned_by, source)
            VALUES (:lead, :emp, :by, CAST(CAST(:src AS text) AS assignment_source))
            """
        ),
        {"lead": lead_id, "emp": employee_id, "by": assigned_by, "src": source},
    )


async def _close_open_assignment(db: AsyncSession, lead_id: UUID, reason: str) -> None:
    await db.execute(
        text(
            """
            UPDATE lead_assignments
            SET ended_at = now(), end_reason = CAST(CAST(:reason AS text) AS assignment_end)
            WHERE lead_id = :lead AND ended_at IS NULL
            """
        ),
        {"lead": lead_id, "reason": reason},
    )


def search_clause(q: str, params: dict[str, Any], name_col: str = "l.client_name",
                  phone_col: str = "l.phone_normalized") -> str:
    """Case-insensitive name search plus digits-only phone search. LIKE wildcards
    typed by the user are escaped so '100%' means a literal percent sign."""
    escaped = q.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    params["pat"] = f"%{escaped}%"
    parts = [f"{name_col} ILIKE :pat ESCAPE '\\'"]
    digits = re.sub(r"\D", "", q)
    if len(digits) >= 3:
        params["dpat"] = f"%{digits}%"
        parts.append(f"{phone_col} LIKE :dpat")
    return "(" + " OR ".join(parts) + ")"


async def fetch_owner_lead(db: AsyncSession, lead_id: UUID, owner_id: UUID):
    return (
        await db.execute(
            text(f"SELECT {LEAD_COLS} FROM leads l WHERE l.id = :id AND {OWNER_VISIBLE}"),
            {"id": lead_id, "uid": owner_id},
        )
    ).mappings().first()


async def fetch_manager_lead(db: AsyncSession, lead_id: UUID):
    return (
        await db.execute(
            text(f"SELECT {MANAGER_COLS} {MANAGER_FROM} WHERE l.id = :id"), {"id": lead_id}
        )
    ).mappings().first()


# --------------------------------------------------------- enter / claim lead
async def enter_lead(
    db: AsyncSession,
    *,
    actor_id: UUID,
    owner_id: UUID,
    by_manager: bool,
    name: str,
    phone: str,
    email: str | None,
    notes: str | None,
) -> tuple[UUID, str]:
    """Employee enters a client, or a manager creates one for an employee.

    * new phone number           -> new lead, 21-day window starts now
    * number of an EXPIRED lead  -> that lead is claimed from the pool (employees
                                    never browse the pool; they just type the number)
    * number of an ACTIVE lead   -> conflict
    Returns (lead_id, source).
    """
    pnorm = normalize_phone(phone)
    new_source = "ASSIGNED" if by_manager else "ENTERED"
    pool_source = "ASSIGNED" if by_manager else "CLAIMED"

    # Locks the existing row so two simultaneous claims serialise.
    existing = (
        await db.execute(
            text(
                """
                SELECT id, state, assigned_employee_id FROM leads
                WHERE phone_normalized = :p
                ORDER BY (state = 'ACTIVE') DESC, expired_at DESC NULLS LAST
                LIMIT 1 FOR UPDATE
                """
            ),
            {"p": pnorm},
        )
    ).mappings().first()

    if existing is not None:
        if existing["state"] == "ACTIVE":
            if by_manager:
                raise LeadConflict("ALREADY_ACTIVE", existing["id"])
            mine = existing["assigned_employee_id"] == owner_id
            raise LeadConflict("ALREADY_YOURS" if mine else "OWNED_BY_OTHER", existing["id"])

        if not by_manager and settings.reclaim_cooldown_days > 0:
            recent = await db.scalar(
                text(
                    """
                    SELECT 1 FROM expired_clients_archive
                    WHERE lead_id = :lead AND previous_owner_id = :emp
                      AND expired_at > now() - make_interval(days => :days)
                    LIMIT 1
                    """
                ),
                {"lead": existing["id"], "emp": owner_id, "days": settings.reclaim_cooldown_days},
            )
            if recent:
                raise LeadConflict("COOLDOWN")

        await _activate_expired(
            db,
            lead_id=existing["id"],
            employee_id=owner_id,
            actor_id=actor_id,
            source=pool_source,
            refresh={"name": name, "phone": phone, "email": email, "notes": notes},
        )
        return existing["id"], pool_source

    try:
        row = (
            await db.execute(
                text(
                    """
                    INSERT INTO leads (client_name, phone, phone_normalized, email, notes,
                                       assigned_employee_id, created_by)
                    VALUES (:name, :phone, :pn, CAST(CAST(:email AS text) AS citext), :notes,
                            :owner, :actor)
                    RETURNING id, assigned_at
                    """
                ),
                {"name": name, "phone": phone, "pn": pnorm, "email": email, "notes": notes,
                 "owner": owner_id, "actor": actor_id},
            )
        ).mappings().one()
    except IntegrityError:  # lost a race with another insert of the same number
        raise LeadConflict("ALREADY_ACTIVE" if by_manager else "OWNED_BY_OTHER")

    await _record_assignment(db, row["id"], owner_id, actor_id, new_source)
    await schedule_followups(db, row["id"], owner_id, row["assigned_at"])
    await log_activity(db, row["id"], actor_id, "CREATED")
    return row["id"], new_source


async def _activate_expired(
    db: AsyncSession,
    *,
    lead_id: UUID,
    employee_id: UUID,
    actor_id: UUID,
    source: str,  # CLAIMED | ASSIGNED
    refresh: dict[str, Any] | None,
) -> None:
    """EXPIRED -> ACTIVE for a new owner with a fresh 21-day window and status NEW.
    When refresh is given the new owner's input replaces the stored details; the
    previous owner's version stays in expired_clients_archive for managers."""
    extra = ""
    params: dict[str, Any] = {"id": lead_id, "emp": employee_id}
    if refresh is not None:
        extra = (", client_name = :name, phone = :phone, "
                 "email = CAST(CAST(:email AS text) AS citext), notes = :notes")
        params.update(refresh)
    try:
        row = (
            await db.execute(
                text(
                    f"""
                    UPDATE leads SET state = 'ACTIVE', assigned_employee_id = :emp,
                                     assigned_at = now(), expired_at = NULL, status = 'NEW'
                                     {extra}
                    WHERE id = :id AND state = 'EXPIRED'
                    RETURNING assigned_at
                    """
                ),
                params,
            )
        ).mappings().first()
    except IntegrityError:  # another active lead already uses this number
        raise LeadConflict("PHONE_IN_USE")
    if row is None:  # someone else claimed it between our lock and update
        raise LeadConflict("OWNED_BY_OTHER")

    await _close_open_assignment(db, lead_id, "EXPIRED")
    await db.execute(
        text(
            """
            UPDATE expired_clients_archive
            SET reassigned_at = now(), reassigned_to = :emp, reassigned_by = :by
            WHERE id = (SELECT id FROM expired_clients_archive
                        WHERE lead_id = :lead AND reassigned_at IS NULL
                        ORDER BY expired_at DESC LIMIT 1)
            """
        ),
        {"emp": employee_id, "by": actor_id, "lead": lead_id},
    )
    await _record_assignment(db, lead_id, employee_id, actor_id, source)
    await schedule_followups(db, lead_id, employee_id, row["assigned_at"])
    await log_activity(db, lead_id, actor_id, "CLAIMED" if source == "CLAIMED" else "REASSIGNED")


# ------------------------------------------------------------ manager assign
async def assign_lead(
    db: AsyncSession, *, lead_id: UUID, employee_id: UUID, actor_id: UUID
) -> dict[str, Any]:
    """Give any lead (active or expired) to an employee with a fresh 21-day window.

    ACTIVE lead  -> handed over mid-pipeline: status is kept so the new owner
                    sees where the previous one got to.
    EXPIRED lead -> back into circulation: status restarts at NEW.
    """
    lead = (
        await db.execute(
            text("SELECT id, state, assigned_employee_id FROM leads WHERE id = :id FOR UPDATE"),
            {"id": lead_id},
        )
    ).mappings().first()
    if lead is None:
        raise LeadNotFound

    target = (
        await db.execute(
            text("SELECT role, is_active FROM users WHERE id = :id"), {"id": employee_id}
        )
    ).mappings().first()
    if target is None or target["role"] != "EMPLOYEE" or not target["is_active"]:
        raise InvalidAssignee

    previous = {"state": lead["state"], "owner_id": lead["assigned_employee_id"]}

    if lead["state"] == "EXPIRED":
        await _activate_expired(
            db, lead_id=lead_id, employee_id=employee_id, actor_id=actor_id,
            source="ASSIGNED", refresh=None,
        )
        return previous

    if lead["assigned_employee_id"] == employee_id:
        raise LeadConflict("ALREADY_ACTIVE", lead_id)

    old_owner = lead["assigned_employee_id"]
    await cancel_followups(db, lead_id, old_owner)
    await _close_open_assignment(db, lead_id, "REASSIGNED")
    row = (
        await db.execute(
            text(
                "UPDATE leads SET assigned_employee_id = :emp, assigned_at = now() "
                "WHERE id = :id RETURNING assigned_at"
            ),
            {"emp": employee_id, "id": lead_id},
        )
    ).mappings().one()
    await _record_assignment(db, lead_id, employee_id, actor_id, "REASSIGNED")
    await schedule_followups(db, lead_id, employee_id, row["assigned_at"])
    await log_activity(db, lead_id, actor_id, "REASSIGNED")
    return previous


# ------------------------------------------------------------------- update
async def update_lead(
    db: AsyncSession,
    *,
    lead_id: UUID,
    actor_id: UUID,
    owner_scope: UUID | None,
    version: int,
    changes: dict[str, Any],
) -> None:
    """Optimistic-locked edit. owner_scope restricts an employee to their own
    visible leads (anything else is reported as not found, never as forbidden, so
    the existence of other people's clients isn't revealed); None = manager."""
    params: dict[str, Any] = {"id": lead_id}
    scope = ""
    if owner_scope is not None:
        scope = f"AND {OWNER_VISIBLE}"
        params["uid"] = owner_scope

    cur = (
        await db.execute(
            text(
                f"""
                SELECT l.id, l.status, l.version, l.state, l.assigned_employee_id, l.assigned_at
                FROM leads l WHERE l.id = :id {scope} FOR UPDATE
                """
            ),
            params,
        )
    ).mappings().first()
    if cur is None:
        raise LeadNotFound
    if cur["version"] != version:
        raise VersionConflict(cur["version"])

    sets: list[str] = []
    upd: dict[str, Any] = {"id": lead_id}
    if "client_name" in changes:
        sets.append("client_name = :client_name")
        upd["client_name"] = changes["client_name"]
    if "phone" in changes:
        sets += ["phone = :phone", "phone_normalized = :pn"]
        upd["phone"], upd["pn"] = changes["phone"], normalize_phone(changes["phone"])
    if "email" in changes:
        sets.append("email = CAST(CAST(:email AS text) AS citext)")
        upd["email"] = changes["email"]
    if "notes" in changes:
        sets.append("notes = :notes")
        upd["notes"] = changes["notes"]
    if "status" in changes:
        sets.append("status = CAST(CAST(:status AS text) AS lead_status)")
        upd["status"] = changes["status"]

    try:
        await db.execute(text(f"UPDATE leads SET {', '.join(sets)} WHERE id = :id"), upd)
    except IntegrityError:
        raise LeadConflict("PHONE_IN_USE")

    new_status = changes.get("status")
    if new_status is not None and new_status != cur["status"]:
        await log_activity(
            db, lead_id, actor_id, "STATUS_CHANGE", from_status=cur["status"], to_status=new_status
        )
        owner = cur["assigned_employee_id"]
        if cur["state"] == "ACTIVE" and owner is not None:
            # Solved clients stop generating reminders; re-opening restores them.
            if new_status == "SOLVED":
                await cancel_followups(db, lead_id, owner)
            elif cur["status"] == "SOLVED":
                await schedule_followups(db, lead_id, owner, cur["assigned_at"])

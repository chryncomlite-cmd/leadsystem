import json
from typing import Any
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


async def write_audit(
    db: AsyncSession,
    *,
    actor_id: UUID | None,
    action: str,
    entity_type: str | None = None,
    entity_id: str | None = None,
    ip: str | None = None,
    details: dict[str, Any] | None = None,
) -> None:
    """Appends to audit_log in the caller's transaction (caller commits)."""
    await db.execute(
        text(
            """
            INSERT INTO audit_log (actor_id, action, entity_type, entity_id, ip, details)
            VALUES (:actor, :action, :etype, :eid,
                    CAST(CAST(:ip AS text) AS inet),
                    CAST(CAST(:details AS text) AS jsonb))
            """
        ),
        {
            "actor": actor_id,
            "action": action,
            "etype": entity_type,
            "eid": entity_id,
            "ip": ip,
            "details": json.dumps(details) if details is not None else None,
        },
    )

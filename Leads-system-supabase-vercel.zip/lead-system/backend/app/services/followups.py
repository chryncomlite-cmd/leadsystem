"""Follow-up reminder schedule (Day 1, 7, 14 and the Day 20 warning).

Rows in calendar_events are the work queue for the Google Calendar sync worker.
The .ics feed does not read them: it computes the same schedule from the leads,
so it works for employees who never connect Google.
"""
from datetime import datetime, time, timedelta, timezone
from uuid import UUID
from zoneinfo import ZoneInfo

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings

FOLLOWUP_DAYS = {"DAY_1": 1, "DAY_7": 7, "DAY_14": 14, "DAY_20_WARNING": 20}


def followup_schedule(assigned_at: datetime) -> dict[str, datetime]:
    """UTC instant of each reminder: N days after the local date of assignment, at
    FOLLOWUP_HOUR local time (so nobody is alerted at 23:00 because that is when a
    lead happened to be entered)."""
    settings = get_settings()
    tz = ZoneInfo(settings.followup_timezone)
    base = assigned_at.astimezone(tz).date()
    fire_at = time(settings.followup_hour, 0)
    return {
        kind: datetime.combine(base + timedelta(days=days), fire_at, tzinfo=tz).astimezone(timezone.utc)
        for kind, days in FOLLOWUP_DAYS.items()
    }


async def schedule_followups(
    db: AsyncSession, lead_id: UUID, employee_id: UUID, assigned_at: datetime
) -> None:
    for kind, starts_at in followup_schedule(assigned_at).items():
        await db.execute(
            text(
                """
                INSERT INTO calendar_events (lead_id, employee_id, kind, starts_at)
                VALUES (:lead, :emp, CAST(CAST(:kind AS text) AS calendar_kind), :starts)
                ON CONFLICT (lead_id, employee_id, kind) DO UPDATE
                  SET starts_at = EXCLUDED.starts_at, sync = 'PENDING',
                      attempts = 0, last_error = NULL
                """
            ),
            {"lead": lead_id, "emp": employee_id, "kind": kind, "starts": starts_at},
        )


async def cancel_followups(db: AsyncSession, lead_id: UUID, employee_id: UUID) -> None:
    """Marks events CANCELLED. The sync worker deletes any copy already pushed to
    Google (rows that still carry a google_event_id)."""
    await db.execute(
        text(
            "UPDATE calendar_events SET sync = 'CANCELLED' "
            "WHERE lead_id = :lead AND employee_id = :emp AND sync <> 'CANCELLED'"
        ),
        {"lead": lead_id, "emp": employee_id},
    )

import re

from app.core.config import get_settings


def normalize_phone(raw: str) -> str:
    """Digits-only form used to detect the same client typed in different styles.

    0700 000 001 / +256 700 000 001 / 700000001 / 00256700000001 -> 256700000001
    """
    raw = raw.strip()
    digits = re.sub(r"\D", "", raw)
    if not digits:
        raise ValueError("Phone number must contain digits")

    if raw.startswith("+"):
        pass  # already international
    elif digits.startswith("00"):
        digits = digits[2:]
    elif digits.startswith("0"):
        digits = get_settings().default_country_code + digits[1:]
    elif len(digits) <= 9:
        digits = get_settings().default_country_code + digits

    if not 9 <= len(digits) <= 15:
        raise ValueError("Enter a valid phone number")
    return digits

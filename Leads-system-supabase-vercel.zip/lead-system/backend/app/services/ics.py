"""RFC 5545 calendar feed: VEVENT reminders and one VTODO per lead, with VALARMs."""
from collections.abc import Mapping, Sequence
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from app.core.config import get_settings
from app.services.followups import followup_schedule

KIND_LABEL = {
    "DAY_1": "Day 1 follow-up",
    "DAY_7": "Day 7 follow-up",
    "DAY_14": "Day 14 follow-up",
    "DAY_20_WARNING": "EXPIRES TOMORROW",
}


def escape_text(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")
        .replace("\r", "")
    )


def fold(line: str) -> str:
    """Lines may not exceed 75 octets; continuation lines start with one space.
    Never splits inside a multi-byte UTF-8 character."""
    if len(line.encode()) <= 75:
        return line
    parts: list[str] = []
    current = b""
    limit = 75
    for ch in line:
        encoded = ch.encode()
        if len(current) + len(encoded) > limit:
            parts.append(current.decode())
            current, limit = b"", 74
        current += encoded
    parts.append(current.decode())
    return "\r\n ".join(parts)


def _utc(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _alarms(kind: str, summary: str) -> list[str]:
    minutes_before = 60 if kind == "DAY_20_WARNING" else 15
    return [
        "BEGIN:VALARM",
        "ACTION:DISPLAY",
        f"DESCRIPTION:{escape_text(summary)}",
        f"TRIGGER:-PT{minutes_before}M",
        "END:VALARM",
        "BEGIN:VALARM",  # sound at the moment the event starts
        "ACTION:AUDIO",
        "TRIGGER:PT0S",
        "END:VALARM",
    ]


def build_calendar(*, calendar_name: str, leads: Sequence[Mapping]) -> str:
    """leads need: id, client_name, phone, status, assigned_at, expires_at,
    version, updated_at, solved_at."""
    tz = ZoneInfo(get_settings().followup_timezone)
    out = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Lead Follow-Up System//Follow-Ups//EN",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        f"X-WR-CALNAME:{escape_text(calendar_name)}",
        "REFRESH-INTERVAL;VALUE=DURATION:PT1H",
        "X-PUBLISHED-TTL:PT1H",
    ]

    for lead in leads:
        expires_local = lead["expires_at"].astimezone(tz)
        details = (
            f"Phone: {lead['phone']}\n"
            f"Status: {lead['status']}\n"
            f"Ownership ends: {expires_local:%a %d %b %Y %H:%M} ({expires_local.tzname()})"
        )
        stamp = _utc(lead["updated_at"])  # stable between fetches unless the lead changes
        solved = lead["status"] == "SOLVED"

        # No point nagging about a client that is already solved.
        if not solved:
            for kind, starts in followup_schedule(lead["assigned_at"]).items():
                summary = f"{KIND_LABEL[kind]}: {lead['client_name']}"
                out += [
                    "BEGIN:VEVENT",
                    f"UID:{lead['id']}-{kind.lower()}@leads.local",
                    f"DTSTAMP:{stamp}",
                    f"SEQUENCE:{lead['version']}",
                    f"DTSTART:{_utc(starts)}",
                    f"DTEND:{_utc(starts + timedelta(minutes=30))}",
                    f"SUMMARY:{escape_text(summary)}",
                    f"DESCRIPTION:{escape_text(details)}",
                    f"PRIORITY:{1 if kind == 'DAY_20_WARNING' else 5}",
                    "STATUS:CONFIRMED",
                    "TRANSP:TRANSPARENT",
                    *_alarms(kind, summary),
                    "END:VEVENT",
                ]

        # Task for Reminders / task apps that read VTODO from a subscription.
        todo = [
            "BEGIN:VTODO",
            f"UID:{lead['id']}-expiry@leads.local",
            f"DTSTAMP:{stamp}",
            f"SEQUENCE:{lead['version']}",
            f"DUE:{_utc(lead['expires_at'])}",
            f"SUMMARY:{escape_text('Close out: ' + lead['client_name'])}",
            f"DESCRIPTION:{escape_text(details)}",
            "PRIORITY:1",
        ]
        if solved:
            todo += ["STATUS:COMPLETED", f"COMPLETED:{_utc(lead['solved_at'] or lead['updated_at'])}"]
        else:
            todo += [
                "STATUS:NEEDS-ACTION",
                "BEGIN:VALARM",
                "ACTION:DISPLAY",
                f"DESCRIPTION:{escape_text('Ownership ends tomorrow: ' + lead['client_name'])}",
                "TRIGGER;RELATED=END:-P1D",
                "END:VALARM",
            ]
        todo.append("END:VTODO")
        out += todo

    out.append("END:VCALENDAR")
    return "\r\n".join(fold(line) for line in out) + "\r\n"

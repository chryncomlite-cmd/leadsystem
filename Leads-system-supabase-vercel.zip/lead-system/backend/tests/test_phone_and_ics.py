"""Pure unit tests (no HTTP, no database rows)."""
from datetime import datetime, timezone

import pytest
from icalendar import Calendar

from app.services.followups import followup_schedule
from app.services.ics import build_calendar, escape_text, fold
from app.services.phone import normalize_phone


@pytest.mark.parametrize(
    "raw",
    ["0700123456", "0700 123 456", "+256 700 123 456", "700123456", "00256700123456", "(0700) 123-456"],
)
def test_every_common_way_of_typing_a_ugandan_number_normalises_the_same(raw):
    assert normalize_phone(raw) == "256700123456"


def test_foreign_numbers_keep_their_own_country_code():
    assert normalize_phone("+44 7911 123456") == "447911123456"


@pytest.mark.parametrize("raw", ["", "abc", "12", "0700", "+" + "1" * 16])
def test_invalid_numbers_are_rejected(raw):
    with pytest.raises(ValueError):
        normalize_phone(raw)


def test_followups_fire_at_9am_local_on_days_1_7_14_and_20():
    # 22:30 UTC on 17 Nov is already 01:30 on 18 Nov in Kampala, so "Day 1" is 19 Nov.
    sched = followup_schedule(datetime(2026, 11, 17, 22, 30, tzinfo=timezone.utc))
    assert sched["DAY_1"] == datetime(2026, 11, 19, 6, 0, tzinfo=timezone.utc)  # 09:00 EAT
    assert sched["DAY_7"] == datetime(2026, 11, 25, 6, 0, tzinfo=timezone.utc)
    assert sched["DAY_14"] == datetime(2026, 12, 2, 6, 0, tzinfo=timezone.utc)
    assert sched["DAY_20_WARNING"] == datetime(2026, 12, 8, 6, 0, tzinfo=timezone.utc)


def test_day_20_warning_always_precedes_expiry():
    assigned = datetime(2026, 11, 17, 21, 59, tzinfo=timezone.utc)  # late evening, worst case
    from datetime import timedelta

    assert followup_schedule(assigned)["DAY_20_WARNING"] < assigned + timedelta(days=21)


def test_ics_escaping_and_folding():
    assert escape_text("a,b;c\\d\ne") == "a\\,b\\;c\\\\d\\ne"
    long_line = "SUMMARY:" + "é" * 80  # multi-byte characters must not be split
    folded = fold(long_line)
    assert "\r\n " in folded
    for physical in folded.split("\r\n"):
        assert len(physical.encode()) <= 75
    assert folded.replace("\r\n ", "") == long_line


def _lead(**over):
    base = {
        "id": "11111111-2222-3333-4444-555555555555",
        "client_name": "Grace, Auma; Jr",
        "phone": "0700 123 456",
        "status": "PENDING",
        "assigned_at": datetime(2026, 11, 17, 6, 0, tzinfo=timezone.utc),
        "expires_at": datetime(2026, 12, 8, 6, 0, tzinfo=timezone.utc),
        "version": 3,
        "updated_at": datetime(2026, 11, 18, 6, 0, tzinfo=timezone.utc),
        "solved_at": None,
    }
    return {**base, **over}


def test_built_calendar_is_valid_and_has_alarms():
    text = build_calendar(calendar_name="Test", leads=[_lead()])
    assert text.endswith("\r\n") and "\n" not in text.replace("\r\n", "")  # CRLF only

    cal = Calendar.from_ical(text)  # a real RFC 5545 parser accepts it
    events = list(cal.walk("VEVENT"))
    assert len(events) == 4
    lead_id = _lead()["id"]
    assert {str(e["UID"]) for e in events} == {
        f"{lead_id}-{kind}@leads.local" for kind in ("day_1", "day_7", "day_14", "day_20_warning")
    }
    for ev in events:
        alarms = [c for c in ev.subcomponents if c.name == "VALARM"]
        assert sorted(str(a["ACTION"]) for a in alarms) == ["AUDIO", "DISPLAY"]
        assert ev["SEQUENCE"] == 3
    warning = next(e for e in events if str(e["UID"]).endswith("day_20_warning@leads.local"))
    assert warning["PRIORITY"] == 1 and "EXPIRES TOMORROW" in str(warning["SUMMARY"])
    assert "Grace, Auma; Jr" in str(events[0]["SUMMARY"])  # escaping round-trips

    (todo,) = cal.walk("VTODO")
    assert str(todo["STATUS"]) == "NEEDS-ACTION" and todo["DUE"].dt == _lead()["expires_at"]


def test_solved_lead_gets_no_reminders_only_a_completed_task():
    solved_at = datetime(2026, 11, 19, 8, 0, tzinfo=timezone.utc)
    text = build_calendar(calendar_name="Test", leads=[_lead(status="SOLVED", solved_at=solved_at)])
    cal = Calendar.from_ical(text)
    assert list(cal.walk("VEVENT")) == []
    (todo,) = cal.walk("VTODO")
    assert str(todo["STATUS"]) == "COMPLETED" and todo["COMPLETED"].dt == solved_at


def test_calendar_is_stable_between_fetches():
    leads = [_lead()]
    assert build_calendar(calendar_name="T", leads=leads) == build_calendar(calendar_name="T", leads=leads)

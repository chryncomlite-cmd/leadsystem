import asyncio
import uuid
from datetime import timedelta

import pytest

from app.core.config import get_settings
from tests.helpers import expire, login_client, new_phone, parse_dt, seed_expired, seed_lead

MISSING = "00000000-0000-0000-0000-00000000beef"


# ---------------------------------------------------------------- entering
async def test_entering_a_client_starts_the_21_day_window_and_schedules_reminders(employee_client, pg):
    r = await employee_client.post(
        "/api/leads",
        json={"client_name": "  Grace Auma ", "phone": "0700 123 456",
              "email": "grace@leadtest.com", "notes": "Wants 3-bedroom"},
    )
    assert r.status_code == 201, r.text
    lead = r.json()
    assert (lead["source"], lead["status"], lead["client_name"]) == ("ENTERED", "NEW", "Grace Auma")
    assert parse_dt(lead["expires_at"]) - parse_dt(lead["assigned_at"]) == timedelta(days=21)
    assert 21 * 86400 - 60 < lead["seconds_remaining"] <= 21 * 86400

    lead_id = uuid.UUID(lead["id"])
    events = await pg.fetch("SELECT kind, sync FROM calendar_events WHERE lead_id = $1 ORDER BY starts_at", lead_id)
    assert [e["kind"] for e in events] == ["DAY_1", "DAY_7", "DAY_14", "DAY_20_WARNING"]
    assert {e["sync"] for e in events} == {"PENDING"}
    assignment = await pg.fetchrow("SELECT source, ended_at FROM lead_assignments WHERE lead_id = $1", lead_id)
    assert assignment["source"] == "ENTERED" and assignment["ended_at"] is None
    assert await pg.fetchval("SELECT count(*) FROM lead_activities WHERE lead_id = $1 AND kind = 'CREATED'", lead_id) == 1


@pytest.mark.parametrize(
    "payload",
    [
        {"phone": "0700123456"},                                   # no name
        {"client_name": "A", "phone": "123"},                      # too short
        {"client_name": "A", "phone": "not-a-number"},
        {"client_name": "A", "phone": "0700123456", "email": "nope"},
        {"client_name": "   ", "phone": "0700123456"},
    ],
)
async def test_invalid_input_is_rejected(employee_client, payload):
    assert (await employee_client.post("/api/leads", json=payload)).status_code == 422


async def test_same_number_typed_differently_is_the_same_client(employee_client, pg):
    first = await employee_client.post("/api/leads", json={"client_name": "A", "phone": "0711 000 222"})
    again = await employee_client.post("/api/leads", json={"client_name": "A2", "phone": "+256711000222"})
    assert again.status_code == 409
    detail = again.json()["detail"]
    assert detail["code"] == "ALREADY_YOURS" and detail["lead_id"] == first.json()["id"]


async def test_another_employee_cannot_enter_a_client_and_learns_nothing_about_the_owner(
    new_client, make_user
):
    alice, bob = await make_user(), await make_user()
    a, b = await login_client(new_client, alice), await login_client(new_client, bob)
    phone = new_phone()
    assert (await a.post("/api/leads", json={"client_name": "Shared", "phone": phone})).status_code == 201

    r = await b.post("/api/leads", json={"client_name": "Shared", "phone": phone})
    assert r.status_code == 409
    assert r.json()["detail"]["code"] == "OWNED_BY_OTHER"
    assert "lead_id" not in r.json()["detail"]
    assert alice["email"] not in r.text and "Test Employee" not in r.text


async def test_ten_employees_racing_for_the_same_number_produce_exactly_one_owner(new_client, make_user):
    users = [await make_user() for _ in range(10)]
    clients = [await login_client(new_client, u) for u in users]
    phone = new_phone()
    results = await asyncio.gather(
        *[c.post("/api/leads", json={"client_name": "Contested", "phone": phone}) for c in clients]
    )
    codes = sorted(r.status_code for r in results)
    assert codes == [201] + [409] * 9


# --------------------------------------------------------------- visibility
async def test_dashboard_shows_only_my_active_unexpired_leads(employee_client, new_client, make_user, pg):
    me, other = employee_client.user, await make_user()
    mine = await seed_lead(pg, me, name="Mine fresh")
    await seed_lead(pg, me, name="Mine overdue", age_days=21.5)     # window over, worker hasn't run
    await seed_expired(pg, me, name="Mine expired")
    await seed_lead(pg, other, name="Someone elses")

    r = await employee_client.get("/api/leads")
    assert r.status_code == 200
    body = r.json()
    assert [i["id"] for i in body["items"]] == [str(mine)] and body["total"] == 1
    assert "server_time" in body


@pytest.mark.parametrize("hidden", ["other", "expired", "overdue", "missing"])
async def test_hidden_leads_answer_404_on_every_endpoint(hidden, employee_client, make_user, pg):
    me = employee_client.user
    if hidden == "other":
        lead = await seed_lead(pg, await make_user())
    elif hidden == "expired":
        lead = await seed_expired(pg, me)
    elif hidden == "overdue":
        lead = await seed_lead(pg, me, age_days=21.5)
    else:
        lead = MISSING

    c = employee_client
    assert (await c.get(f"/api/leads/{lead}")).status_code == 404
    assert (await c.patch(f"/api/leads/{lead}", json={"version": 1, "notes": "x"})).status_code == 404
    assert (await c.get(f"/api/leads/{lead}/activities")).status_code == 404
    assert (await c.post(f"/api/leads/{lead}/activities", json={"kind": "NOTE", "body": "x"})).status_code == 404


# ------------------------------------------------------------------ updates
async def test_update_status_version_and_solved_lifecycle(employee_client, pg):
    created = (await employee_client.post("/api/leads", json={"client_name": "Flow", "phone": new_phone()})).json()
    lead_id, url = uuid.UUID(created["id"]), f"/api/leads/{created['id']}"

    r = await employee_client.patch(url, json={"version": created["version"], "status": "PENDING", "notes": "called"})
    assert r.status_code == 200 and r.json()["status"] == "PENDING" and r.json()["version"] == created["version"] + 1

    stale = await employee_client.patch(url, json={"version": created["version"], "notes": "late edit"})
    assert stale.status_code == 409
    assert stale.json()["detail"] == {
        "code": "VERSION_CONFLICT",
        "message": "This client was changed by someone else. Reload and try again.",
        "current_version": r.json()["version"],
    }

    solved = await employee_client.patch(url, json={"version": r.json()["version"], "status": "SOLVED"})
    assert solved.status_code == 200
    assert await pg.fetchval("SELECT solved_at IS NOT NULL FROM leads WHERE id = $1", lead_id)
    # a solved client stops generating reminders...
    assert {e["sync"] for e in await pg.fetch("SELECT sync FROM calendar_events WHERE lead_id = $1", lead_id)} == {"CANCELLED"}

    reopened = await employee_client.patch(url, json={"version": solved.json()["version"], "status": "SAVING"})
    assert reopened.status_code == 200
    assert await pg.fetchval("SELECT solved_at IS NULL FROM leads WHERE id = $1", lead_id)
    # ...and re-opening restores them
    assert {e["sync"] for e in await pg.fetch("SELECT sync FROM calendar_events WHERE lead_id = $1", lead_id)} == {"PENDING"}

    log = await employee_client.get(f"{url}/activities")
    changes = [(a["from_status"], a["to_status"]) for a in log.json() if a["kind"] == "STATUS_CHANGE"]
    assert changes == [("SOLVED", "SAVING"), ("PENDING", "SOLVED"), ("NEW", "PENDING")]  # newest first


async def test_patch_validation(employee_client):
    created = (await employee_client.post(
        "/api/leads", json={"client_name": "V", "phone": new_phone(), "email": "v@leadtest.com"})).json()
    url, v = f"/api/leads/{created['id']}", created["version"]

    for bad in ({"version": v}, {"notes": "x"}, {"version": v, "status": "DONE"},
                {"version": v, "client_name": None}, {"version": 0, "notes": "x"}):
        assert (await employee_client.patch(url, json=bad)).status_code == 422, bad

    cleared = await employee_client.patch(url, json={"version": v, "email": ""})
    assert cleared.status_code == 200 and cleared.json()["email"] is None


async def test_phone_edit_cannot_collide_with_someone_elses_client(new_client, make_user, pg):
    a, b = await make_user(), await make_user()
    taken = new_phone()
    await seed_lead(pg, a, phone=taken)
    mine = await seed_lead(pg, b)
    cb = await login_client(new_client, b)

    r = await cb.patch(f"/api/leads/{mine}", json={"version": 1, "phone": taken})
    assert r.status_code == 409 and r.json()["detail"]["code"] == "PHONE_IN_USE"
    fine = await cb.patch(f"/api/leads/{mine}", json={"version": 1, "phone": new_phone()})
    assert fine.status_code == 200


# --------------------------------------------------------------- claiming
async def test_entering_the_number_of_an_expired_client_claims_it_from_the_pool(new_client, make_user, pg):
    previous, claimer = await make_user(), await make_user()
    phone = new_phone()
    old_id = await seed_expired(pg, previous, phone=phone, status="PENDING", notes="secret old notes")
    c = await login_client(new_client, claimer)

    r = await c.post("/api/leads", json={"client_name": "Fresh Name", "phone": phone, "notes": "mine"})
    assert r.status_code == 201, r.text
    lead = r.json()
    assert lead["id"] == str(old_id) and lead["source"] == "CLAIMED"
    assert lead["status"] == "NEW" and lead["notes"] == "mine"
    assert "secret old notes" not in r.text
    assert parse_dt(lead["expires_at"]) - parse_dt(lead["assigned_at"]) == timedelta(days=21)

    row = await pg.fetchrow("SELECT state, entered_at, expired_at FROM leads WHERE id = $1", old_id)
    assert row["state"] == "ACTIVE" and row["expired_at"] is None
    assert row["entered_at"] < parse_dt(lead["assigned_at"]) - timedelta(days=20)  # original input time kept
    archive = await pg.fetchrow("SELECT reassigned_to, reassigned_at FROM expired_clients_archive WHERE lead_id = $1", old_id)
    assert archive["reassigned_to"] == claimer["id"] and archive["reassigned_at"] is not None
    sources = [a["source"] for a in await pg.fetch("SELECT source FROM lead_assignments WHERE lead_id = $1 ORDER BY id", old_id)]
    assert sources == ["ENTERED", "CLAIMED"]

    # the previous owner no longer sees it, the claimer does
    prev_client = await login_client(new_client, previous)
    assert (await prev_client.get(f"/api/leads/{old_id}")).status_code == 404
    assert (await c.get(f"/api/leads/{old_id}")).status_code == 200


async def test_reclaim_cooldown_blocks_only_the_previous_owner(new_client, make_user, pg, monkeypatch):
    monkeypatch.setattr(get_settings(), "reclaim_cooldown_days", 7)
    previous, other = await make_user(), await make_user()
    phone = new_phone()
    await seed_expired(pg, previous, phone=phone)

    cp = await login_client(new_client, previous)
    blocked = await cp.post("/api/leads", json={"client_name": "Again", "phone": phone})
    assert blocked.status_code == 409 and blocked.json()["detail"]["code"] == "COOLDOWN"

    co = await login_client(new_client, other)
    assert (await co.post("/api/leads", json={"client_name": "Other", "phone": phone})).status_code == 201


# ------------------------------------------------------ activities and stats
async def test_calls_and_notes_are_logged_newest_first(employee_client):
    lead = (await employee_client.post("/api/leads", json={"client_name": "Log", "phone": new_phone()})).json()
    base = f"/api/leads/{lead['id']}/activities"

    note = await employee_client.post(base, json={"kind": "NOTE", "body": "  prefers evenings "})
    call = await employee_client.post(base, json={"kind": "CALL", "body": "No answer"})
    assert note.status_code == call.status_code == 201
    assert note.json()["body"] == "prefers evenings" and note.json()["actor_name"] == "Test Employee"

    kinds = [a["kind"] for a in (await employee_client.get(base)).json()]
    assert kinds == ["CALL", "NOTE", "CREATED"]
    assert (await employee_client.post(base, json={"kind": "EMAIL", "body": "x"})).status_code == 422
    assert (await employee_client.post(base, json={"kind": "NOTE", "body": "  "})).status_code == 422


async def test_my_stats_count_only_my_visible_leads(employee_client, make_user, pg):
    me, other = employee_client.user, await make_user()
    await seed_lead(pg, me)
    await seed_lead(pg, me)
    await seed_lead(pg, me, status="PENDING")
    await seed_lead(pg, me, status="SAVING", age_days=19)         # ends in ~2 days
    await seed_lead(pg, me, status="SOLVED")
    await seed_lead(pg, me, age_days=21.5)                         # overdue: excluded
    await seed_expired(pg, me)                                     # expired: excluded
    await seed_lead(pg, other)                                     # not mine: excluded

    r = await employee_client.get("/api/leads/stats")
    assert r.json() == {"total": 5, "new": 2, "pending": 1, "saving": 1, "solved": 1, "expiring_soon": 1}


async def test_filters_search_sort_and_paging(employee_client, pg):
    me, tag = employee_client.user, uuid.uuid4().hex[:8]
    await seed_lead(pg, me, name=f"{tag} Charlie", phone="0700111222", status="PENDING")
    await seed_lead(pg, me, name=f"{tag} alice", phone="0700333444")
    await seed_lead(pg, me, name=f"{tag} Bob 100% Real", phone="0700555666")

    async def names(**params):
        r = await employee_client.get("/api/leads", params={"q": tag, **params})
        assert r.status_code == 200, r.text
        return [i["client_name"].removeprefix(f"{tag} ") for i in r.json()["items"]], r.json()["total"]

    assert await names(sort="client_name") == (["alice", "Bob 100% Real", "Charlie"], 3)
    assert (await names(status="PENDING"))[0] == ["Charlie"]
    assert await names(sort="client_name", limit=2, offset=2) == (["Charlie"], 3)  # total ignores paging

    by_phone = await employee_client.get("/api/leads", params={"q": "333 444"})
    assert [i["client_name"] for i in by_phone.json()["items"]] == [f"{tag} alice"]
    percent = await employee_client.get("/api/leads", params={"q": "%"})
    assert [i["client_name"] for i in percent.json()["items"]] == [f"{tag} Bob 100% Real"]  # wildcard is literal


# --------------------------------------------------------------------- RBAC
async def test_unauthenticated_and_manager_sessions_are_refused(new_client, manager_client):
    assert (await new_client().get("/api/leads")).status_code == 401
    assert (await manager_client.get("/api/leads")).status_code == 403
    assert (await manager_client.post("/api/leads", json={"client_name": "x", "phone": new_phone()})).status_code == 403

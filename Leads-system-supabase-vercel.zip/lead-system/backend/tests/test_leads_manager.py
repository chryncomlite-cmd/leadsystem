import uuid
from datetime import timedelta

import pytest

from tests.helpers import expire, login_client, new_phone, parse_dt, seed_expired, seed_lead

MISSING = "00000000-0000-0000-0000-00000000beef"


async def two_employees(new_client, make_user):
    users = [await make_user(), await make_user()]
    return users, [await login_client(new_client, u) for u in users]


# --------------------------------------------------------------------- stats
async def test_stats_totals_status_breakdown_and_conversion(manager_client, make_user, pg):
    e1, e2 = await make_user(), await make_user()
    before = (await manager_client.get("/api/manager/stats")).json()["totals"]

    await seed_lead(pg, e1)
    await seed_lead(pg, e1)
    await seed_lead(pg, e1, status="PENDING")
    await seed_lead(pg, e1, status="SOLVED")
    await seed_expired(pg, e1, status="SOLVED")      # credit survives the move to the archive
    await seed_expired(pg, e1, status="PENDING")
    await seed_expired(pg, e1, status="NEW")

    stats = (await manager_client.get("/api/manager/stats")).json()
    after = stats["totals"]

    def delta(*path):
        a, b = after, before
        for p in path:
            a, b = a[p], b[p]
        return a - b

    assert delta("total_clients") == 7 and delta("active_clients") == 4 and delta("expired_clients") == 3
    assert delta("solved_clients") == 2
    assert [delta("by_status", s) for s in ("NEW", "PENDING", "SAVING", "SOLVED")] == [3, 2, 0, 2]
    assert [delta("active_by_status", s) for s in ("NEW", "PENDING", "SAVING", "SOLVED")] == [2, 1, 0, 1]

    # the API agrees with the database view
    view = await pg.fetchrow("SELECT * FROM v_client_totals")
    assert (after["total_clients"], after["solved_clients"], after["active_clients"], after["expired_clients"]) == (
        view["total_clients"], view["solved_clients"], view["active_clients"], view["expired_clients"])

    perf = {e["employee_id"]: e for e in stats["employees"]}
    one = perf[str(e1["id"])]
    assert (one["active_leads"], one["solved_leads"], one["lost_leads"], one["total_handled"]) == (4, 2, 2, 7)
    assert one["conversion_pct"] == 28.6          # 2 solved / 7 handled
    assert one["closed_conversion_pct"] == 50.0   # 2 solved / (2 solved + 2 lost)
    idle = perf[str(e2["id"])]
    assert (idle["total_handled"], idle["conversion_pct"], idle["closed_conversion_pct"]) == (0, 0, 0)


# --------------------------------------------------------------------- lists
async def test_manager_sees_every_lead_with_owner_and_input_time(manager_client, make_user, pg):
    e1, e2 = await make_user(), await make_user()
    tag = uuid.uuid4().hex[:8]
    await seed_lead(pg, e1, name=f"{tag} one")
    await seed_lead(pg, e2, name=f"{tag} two", status="SAVING")
    old = await seed_lead(pg, e1, name=f"{tag} older", age_days=10)
    gone = await seed_expired(pg, e2, name=f"{tag} gone")

    async def get(**params):
        r = await manager_client.get("/api/manager/leads", params={"q": tag, **params})
        assert r.status_code == 200, r.text
        return r.json()

    everything = await get()
    assert everything["total"] == 4
    first = next(i for i in everything["items"] if i["client_name"].endswith("one"))
    assert first["owner_name"] == "Test Employee" and first["state"] == "ACTIVE"
    assert parse_dt(first["entered_at"]) and first["expires_at"]   # input date and time visible

    assert {i["client_name"][9:] for i in (await get(employee_id=str(e1["id"])))["items"]} == {"one", "older"}
    assert [i["id"] for i in (await get(state="EXPIRED"))["items"]] == [str(gone)]
    assert (await get(state="EXPIRED"))["items"][0]["owner_name"] is None
    assert [i["client_name"][9:] for i in (await get(status="SAVING"))["items"]] == ["two"]

    recent = await get(entered_from=(parse_dt((await get())["server_time"]) - timedelta(days=5)).isoformat())
    assert recent["total"] == 2 and str(old) not in [i["id"] for i in recent["items"]]
    # sorted: gone, older, one, two -> skipping the first leaves "older", "one"
    assert [i["client_name"][9:] for i in (await get(sort="client_name", limit=2, offset=1))["items"]] == ["older", "one"]


async def test_lead_detail_shows_history_and_activity(manager_client, new_client, make_user):
    emp = await make_user()
    c = await login_client(new_client, emp)
    lead = (await c.post("/api/leads", json={"client_name": "Detail", "phone": new_phone()})).json()
    await c.post(f"/api/leads/{lead['id']}/activities", json={"kind": "CALL", "body": "Spoke to client"})

    r = await manager_client.get(f"/api/manager/leads/{lead['id']}")
    assert r.status_code == 200
    body = r.json()
    assert body["lead"]["owner_name"] == "Test Employee"
    assert [(a["source"], a["employee_name"], a["ended_at"]) for a in body["assignments"]] == [("ENTERED", "Test Employee", None)]
    assert {a["kind"] for a in body["activities"]} == {"CREATED", "CALL"}
    assert (await manager_client.get(f"/api/manager/leads/{MISSING}")).status_code == 404


# ------------------------------------------------------------------- editing
async def test_manager_can_edit_any_lead_including_expired_and_edits_are_audited(manager_client, make_user, pg):
    e1 = await make_user()
    active, expired = await seed_lead(pg, e1), await seed_expired(pg, e1)

    r = await manager_client.patch(f"/api/manager/leads/{active}", json={"version": 1, "notes": "VIP", "status": "PENDING"})
    assert r.status_code == 200 and r.json()["notes"] == "VIP"
    r2 = await manager_client.patch(f"/api/manager/leads/{expired}", json={"version": 2, "client_name": "Renamed"})
    assert r2.status_code == 200 and r2.json()["state"] == "EXPIRED" and r2.json()["assigned_employee_id"] is None

    stale = await manager_client.patch(f"/api/manager/leads/{active}", json={"version": 1, "notes": "again"})
    assert stale.status_code == 409 and stale.json()["detail"]["code"] == "VERSION_CONFLICT"
    assert (await manager_client.patch(f"/api/manager/leads/{MISSING}", json={"version": 1, "notes": "x"})).status_code == 404

    audit = await pg.fetchrow(
        "SELECT details FROM audit_log WHERE action = 'LEAD_UPDATED' AND entity_id = $1", str(active))
    assert audit is not None and "notes" in audit["details"]


# ------------------------------------------------------------------ assigning
async def test_reassigning_an_active_lead_moves_ownership_and_resets_the_window(manager_client, new_client, make_user, pg):
    (e1, e2), (c1, c2) = await two_employees(new_client, make_user)
    lead = (await c1.post("/api/leads", json={"client_name": "Handover", "phone": new_phone()})).json()
    await c1.patch(f"/api/leads/{lead['id']}", json={"version": lead["version"], "status": "SAVING"})
    lead_id = uuid.UUID(lead["id"])
    await pg.execute("UPDATE leads SET assigned_at = now() - interval '15 days' WHERE id = $1", lead_id)

    r = await manager_client.post(f"/api/manager/leads/{lead_id}/assign", json={"employee_id": str(e2["id"])})
    assert r.status_code == 200, r.text
    moved = r.json()
    assert moved["assigned_employee_id"] == str(e2["id"]) and moved["status"] == "SAVING"  # progress kept
    assert moved["seconds_remaining"] > 20.9 * 86400                                       # window restarted

    assert (await c1.get(f"/api/leads/{lead_id}")).status_code == 404   # old owner locked out at once
    assert (await c2.get(f"/api/leads/{lead_id}")).status_code == 200

    history = await pg.fetch("SELECT employee_id, source, end_reason FROM lead_assignments WHERE lead_id = $1 ORDER BY id", lead_id)
    assert [(h["employee_id"], h["source"], h["end_reason"]) for h in history] == [
        (e1["id"], "ENTERED", "REASSIGNED"), (e2["id"], "REASSIGNED", None)]
    syncs = {(r["employee_id"], r["sync"]) for r in await pg.fetch("SELECT employee_id, sync FROM calendar_events WHERE lead_id = $1", lead_id)}
    assert syncs == {(e1["id"], "CANCELLED"), (e2["id"], "PENDING")}
    assert await pg.fetchval("SELECT count(*) FROM audit_log WHERE action = 'LEAD_REASSIGNED' AND entity_id = $1", str(lead_id)) == 1

    again = await manager_client.post(f"/api/manager/leads/{lead_id}/assign", json={"employee_id": str(e2["id"])})
    assert again.status_code == 409 and again.json()["detail"]["code"] == "ALREADY_ACTIVE"


async def test_reassigning_an_expired_lead_puts_it_back_in_circulation(manager_client, new_client, make_user, pg):
    (e1, e2), (c1, c2) = await two_employees(new_client, make_user)
    lead_id = await seed_expired(pg, e1, status="PENDING")

    r = await manager_client.post(f"/api/manager/leads/{lead_id}/assign", json={"employee_id": str(e2["id"])})
    assert r.status_code == 200, r.text
    assert r.json()["state"] == "ACTIVE" and r.json()["status"] == "NEW"   # fresh start
    assert r.json()["seconds_remaining"] > 20.9 * 86400

    archive = await pg.fetchrow("SELECT reassigned_to, reassigned_by, reassigned_at FROM expired_clients_archive WHERE lead_id = $1", lead_id)
    assert archive["reassigned_to"] == e2["id"] and archive["reassigned_by"] is not None and archive["reassigned_at"]
    assert (await c2.get(f"/api/leads/{lead_id}")).status_code == 200
    assert (await c1.get(f"/api/leads/{lead_id}")).status_code == 404


async def test_assignee_must_be_an_active_employee(manager_client, make_user, pg):
    emp, inactive = await make_user(), await make_user()
    await pg.execute("UPDATE users SET is_active = false WHERE id = $1", inactive["id"])
    lead_id = await seed_expired(pg, emp)

    for target in (manager_client.user["id"], inactive["id"], uuid.UUID(MISSING)):
        r = await manager_client.post(f"/api/manager/leads/{lead_id}/assign", json={"employee_id": str(target)})
        assert r.status_code == 422, target
    r = await manager_client.post(f"/api/manager/leads/{MISSING}/assign", json={"employee_id": str(emp["id"])})
    assert r.status_code == 404
    assert await pg.fetchval("SELECT state FROM leads WHERE id = $1", lead_id) == "EXPIRED"  # nothing changed


async def test_manager_can_create_a_lead_for_an_employee(manager_client, new_client, make_user, pg):
    emp = await make_user()
    c = await login_client(new_client, emp)
    phone = new_phone()

    r = await manager_client.post("/api/manager/leads", json={
        "client_name": "Assigned Client", "phone": phone, "employee_id": str(emp["id"])})
    assert r.status_code == 201, r.text
    assert r.json()["source"] == "ASSIGNED" and r.json()["owner_name"] == "Test Employee"
    assert (await c.get(f"/api/leads/{r.json()['id']}")).status_code == 200

    dup = await manager_client.post("/api/manager/leads", json={
        "client_name": "Dup", "phone": phone, "employee_id": str(emp["id"])})
    assert dup.status_code == 409 and dup.json()["detail"]["lead_id"] == r.json()["id"]  # managers get the id

    pooled = await seed_expired(pg, emp, phone="0788 000 111")
    back = await manager_client.post("/api/manager/leads", json={
        "client_name": "Back again", "phone": "0788000111", "employee_id": str(emp["id"])})
    assert back.status_code == 201 and back.json()["id"] == str(pooled)

    for bad in (manager_client.user["id"], uuid.UUID(MISSING)):
        r = await manager_client.post("/api/manager/leads", json={
            "client_name": "X", "phone": new_phone(), "employee_id": str(bad)})
        assert r.status_code == 422


# -------------------------------------------------------------------- archive
async def test_archive_lists_expired_clients_and_tracks_reassignment(manager_client, make_user, pg):
    e1, e2 = await make_user(), await make_user()
    tag = uuid.uuid4().hex[:8]
    waiting = await seed_expired(pg, e1, name=f"{tag} waiting", status="PENDING")
    given = await seed_expired(pg, e1, name=f"{tag} given")
    await seed_expired(pg, e2, name=f"{tag} other owner")
    await manager_client.post(f"/api/manager/leads/{given}/assign", json={"employee_id": str(e2["id"])})

    async def get(**params):
        r = await manager_client.get("/api/manager/archive", params={"q": tag, **params})
        assert r.status_code == 200, r.text
        return r.json()

    assert (await get())["total"] == 3
    mine = await get(previous_owner_id=str(e1["id"]))
    assert {i["client_name"][9:] for i in mine["items"]} == {"waiting", "given"}
    row = next(i for i in mine["items"] if i["lead_id"] == str(waiting))
    assert row["previous_owner_name"] == "Test Employee" and row["status_at_expiry"] == "PENDING"
    assert row["ownership_history"] == [] and row["reassigned_at"] is None

    assert [i["lead_id"] for i in (await get(previous_owner_id=str(e1["id"]), reassigned=False))["items"]] == [str(waiting)]
    done = (await get(reassigned=True))["items"]
    assert [i["lead_id"] for i in done] == [str(given)] and done[0]["reassigned_to"] == str(e2["id"])
    assert done[0]["reassigned_to_name"] == "Test Employee"


# ----------------------------------------------------------------------- RBAC
@pytest.mark.parametrize(
    "method,path,body",
    [
        ("GET", "/api/manager/stats", None),
        ("GET", "/api/manager/leads", None),
        ("POST", "/api/manager/leads", {"client_name": "x", "phone": "0700123456", "employee_id": MISSING}),
        ("GET", f"/api/manager/leads/{MISSING}", None),
        ("PATCH", f"/api/manager/leads/{MISSING}", {"version": 1, "notes": "x"}),
        ("POST", f"/api/manager/leads/{MISSING}/assign", {"employee_id": MISSING}),
        ("GET", "/api/manager/archive", None),
    ],
)
async def test_employees_and_anonymous_users_are_blocked_from_every_manager_route(
    method, path, body, employee_client, new_client
):
    assert (await employee_client.request(method, path, json=body)).status_code == 403
    assert (await new_client().request(method, path, json=body)).status_code == 401

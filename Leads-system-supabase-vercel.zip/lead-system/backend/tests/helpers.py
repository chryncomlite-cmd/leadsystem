"""Seeding helpers that write straight to the database, so tests can build states
(an overdue lead, an expired lead) that the API itself will never produce."""
import random
import uuid
from datetime import datetime
from uuid import UUID

from app.services.phone import normalize_phone
from tests.conftest import do_login


def new_phone() -> str:
    return "07" + "".join(random.choice("0123456789") for _ in range(8))


def parse_dt(value: str) -> datetime:
    return datetime.fromisoformat(value)


async def login_client(new_client, user: dict):
    client = new_client()
    r = await do_login(client, user["email"], user["password"])
    assert r.status_code == 200, r.text
    client.user = user
    return client


async def seed_lead(
    pg,
    owner: dict,
    *,
    name: str | None = None,
    phone: str | None = None,
    status: str = "NEW",
    age_days: float = 0.0,
    notes: str | None = None,
) -> UUID:
    """An ACTIVE lead owned by `owner`, assigned `age_days` ago (so age_days >= 21
    gives a lead whose window has passed but the worker has not caught up yet)."""
    phone = phone or new_phone()
    lead_id = await pg.fetchval(
        """
        INSERT INTO leads (client_name, phone, phone_normalized, notes, status,
                           assigned_employee_id, created_by, entered_at, assigned_at)
        VALUES ($1, $2, $3, $4, $5::lead_status, $6, $6,
                now() - make_interval(secs => $7::float8 * 86400),
                now() - make_interval(secs => $7::float8 * 86400))
        RETURNING id
        """,
        name or f"Client {uuid.uuid4().hex[:6]}",
        phone,
        normalize_phone(phone),
        notes,
        status,
        owner["id"],
        age_days,
    )
    await pg.execute(
        """
        INSERT INTO lead_assignments (lead_id, employee_id, source, assigned_at)
        VALUES ($1, $2, 'ENTERED', now() - make_interval(secs => $3::float8 * 86400))
        """,
        lead_id,
        owner["id"],
        age_days,
    )
    return lead_id


async def expire(pg, lead_id: UUID, *, days_ago: float = 0.0) -> None:
    """What the Day-22 worker does: flag EXPIRED, strip the owner, archive a snapshot."""
    lead = await pg.fetchrow(
        "SELECT l.*, u.full_name AS owner_name FROM leads l "
        "JOIN users u ON u.id = l.assigned_employee_id WHERE l.id = $1",
        lead_id,
    )
    async with pg.transaction():
        await pg.execute(
            "UPDATE leads SET state = 'EXPIRED', assigned_employee_id = NULL, "
            "expired_at = now() - make_interval(secs => $2::float8 * 86400) WHERE id = $1",
            lead_id,
            days_ago,
        )
        await pg.execute(
            """
            INSERT INTO expired_clients_archive
              (lead_id, client_name, phone, email, notes, status_at_expiry, previous_owner_id,
               previous_owner_name, entered_at, assigned_at, expired_at, ownership_history)
            VALUES ($1, $2, $3, $4, $5, $6::lead_status, $7, $8, $9, $10,
                    now() - make_interval(secs => $11::float8 * 86400), '[]'::jsonb)
            """,
            lead_id,
            lead["client_name"],
            lead["phone"],
            lead["email"],
            lead["notes"],
            lead["status"],
            lead["assigned_employee_id"],
            lead["owner_name"],
            lead["entered_at"],
            lead["assigned_at"],
            days_ago,
        )
        await pg.execute(
            "UPDATE lead_assignments SET ended_at = now(), end_reason = 'EXPIRED' "
            "WHERE lead_id = $1 AND ended_at IS NULL",
            lead_id,
        )


async def seed_expired(pg, previous_owner: dict, **kwargs) -> UUID:
    kwargs.setdefault("age_days", 22.0)
    lead_id = await seed_lead(pg, previous_owner, **kwargs)
    await expire(pg, lead_id)
    return lead_id

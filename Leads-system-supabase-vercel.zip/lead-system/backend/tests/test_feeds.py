import hashlib
from datetime import datetime, timezone

from icalendar import Calendar

from app.services.followups import followup_schedule
from tests.helpers import login_client, seed_expired, seed_lead


def feed_path(url: str) -> str:
    return "/" + url.split("/", 3)[3]


def raw_token(url: str) -> str:
    return url.rsplit("/", 1)[1].removesuffix(".ics")


async def test_token_lifecycle_rotation_and_revocation(employee_client, new_client, pg):
    anon = new_client(origin=None)  # a calendar app: no cookie, no Origin header

    assert (await employee_client.get("/api/feeds/token")).json() == {"active": False, "created_at": None, "last_used_at": None}

    first = await employee_client.post("/api/feeds/token")
    assert first.status_code == 201
    body = first.json()
    assert body["url"].endswith(".ics") and "/feeds/" in body["url"]
    assert body["webcal_url"].startswith("webcal://") and body["webcal_url"].endswith(".ics")
    token = raw_token(body["url"])
    assert len(token) >= 43

    # only the hash is stored
    stored = await pg.fetchval("SELECT token_hash FROM calendar_feed_tokens WHERE user_id = $1 AND revoked_at IS NULL", employee_client.user["id"])
    assert bytes(stored) == hashlib.sha256(token.encode()).digest()

    status = (await employee_client.get("/api/feeds/token")).json()
    assert status["active"] is True and token not in str(status)

    ok = await anon.get(feed_path(body["url"]))
    assert ok.status_code == 200
    assert ok.headers["content-type"].startswith("text/calendar")
    assert "private" in ok.headers["cache-control"]

    second = await employee_client.post("/api/feeds/token")          # rotate
    assert (await anon.get(feed_path(body["url"]))).status_code == 404   # old URL dead at once
    assert (await anon.get(feed_path(second.json()["url"]))).status_code == 200
    assert await pg.fetchval("SELECT count(*) FROM calendar_feed_tokens WHERE user_id = $1 AND revoked_at IS NULL", employee_client.user["id"]) == 1

    assert (await employee_client.delete("/api/feeds/token")).status_code == 204
    assert (await anon.get(feed_path(second.json()["url"]))).status_code == 404
    assert (await employee_client.get("/api/feeds/token")).json()["active"] is False


async def test_feed_contains_only_my_live_leads_with_alarms(employee_client, new_client, make_user, pg):
    me, other = employee_client.user, await make_user()
    live = await seed_lead(pg, me, name="Live Client", phone="0700 777 888", status="PENDING")
    done = await seed_lead(pg, me, name="Solved Client", status="SOLVED")
    await seed_lead(pg, me, name="Overdue Client", age_days=21.5)
    await seed_expired(pg, me, name="Expired Client")
    await seed_lead(pg, other, name="Someone Elses Client")

    url = (await employee_client.post("/api/feeds/token")).json()["url"]
    r = await new_client(origin=None).get(feed_path(url))
    assert r.status_code == 200
    text = r.text
    assert text.startswith("BEGIN:VCALENDAR\r\n") and text.endswith("END:VCALENDAR\r\n")
    for hidden in ("Overdue Client", "Expired Client", "Someone Elses Client"):
        assert hidden not in text

    cal = Calendar.from_ical(text)
    events = list(cal.walk("VEVENT"))
    assert {str(e["UID"]) for e in events} == {
        f"{live}-{k}@leads.local" for k in ("day_1", "day_7", "day_14", "day_20_warning")}
    for ev in events:
        actions = sorted(str(a["ACTION"]) for a in ev.subcomponents if a.name == "VALARM")
        assert actions == ["AUDIO", "DISPLAY"]
        assert "0700 777 888" in str(ev["DESCRIPTION"])

    todos = {str(t["UID"]): t for t in cal.walk("VTODO")}
    assert set(todos) == {f"{live}-expiry@leads.local", f"{done}-expiry@leads.local"}
    assert str(todos[f"{live}-expiry@leads.local"]["STATUS"]) == "NEEDS-ACTION"
    assert str(todos[f"{done}-expiry@leads.local"]["STATUS"]) == "COMPLETED"


async def test_feed_event_times_match_the_follow_up_schedule(employee_client, new_client, pg):
    lead = await seed_lead(pg, employee_client.user, age_days=3)
    assigned_at = await pg.fetchval("SELECT assigned_at FROM leads WHERE id = $1", lead)
    expected = followup_schedule(assigned_at)

    url = (await employee_client.post("/api/feeds/token")).json()["url"]
    cal = Calendar.from_ical((await new_client(origin=None).get(feed_path(url))).text)
    starts = {str(e["UID"]).split("-")[-1].split("@")[0].upper(): e["DTSTART"].dt for e in cal.walk("VEVENT")}
    assert starts == expected


async def test_unknown_malformed_and_deactivated_tokens_all_give_the_same_404(
    employee_client, manager_client, new_client
):
    anon = new_client(origin=None)
    url = (await employee_client.post("/api/feeds/token")).json()["url"]

    for bad in ("/feeds/not-a-real-token.ics", "/feeds/.ics", "/feeds/" + "A" * 43 + ".ics"):
        r = await anon.get(bad)
        assert r.status_code == 404 and r.json() == {"detail": "Not Found"}

    await manager_client.patch(f"/api/manager/users/{employee_client.user['id']}/active", json={"is_active": False})
    assert (await anon.get(feed_path(url))).status_code == 404


async def test_fetching_the_feed_records_last_use(employee_client, new_client):
    url = (await employee_client.post("/api/feeds/token")).json()["url"]
    assert (await employee_client.get("/api/feeds/token")).json()["last_used_at"] is None
    await new_client(origin=None).get(feed_path(url))
    assert (await employee_client.get("/api/feeds/token")).json()["last_used_at"] is not None


async def test_only_employees_manage_feed_tokens(manager_client, new_client):
    assert (await manager_client.post("/api/feeds/token")).status_code == 403
    assert (await manager_client.get("/api/feeds/token")).status_code == 403
    assert (await new_client().post("/api/feeds/token")).status_code == 401

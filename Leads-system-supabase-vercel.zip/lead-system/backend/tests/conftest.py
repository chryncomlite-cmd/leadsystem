"""Integration test harness.

Needs a PostgreSQL database whose name ends in `_test` (the schema is DROPPED and
rebuilt from db/migrations on every run):

    DATABASE_URL=postgresql+asyncpg://user:pw@localhost:5432/leadsystem_test pytest
"""
import os
import uuid
from pathlib import Path

# Settings must be in place before the app modules are imported.
os.environ.setdefault("JWT_SECRET", "test-secret-" + "x" * 40)
os.environ["ENVIRONMENT"] = "test"
os.environ["COOKIE_SECURE"] = "true"
os.environ["ALLOWED_ORIGINS"] = '["http://localhost:3000"]'
os.environ["MAX_FAILED_LOGINS"] = "5"
# Cheap Argon2 for test speed. test_security checks the real defaults separately.
os.environ["ARGON2_MEMORY_KIB"] = "8192"
os.environ["ARGON2_TIME_COST"] = "2"
os.environ["ARGON2_PARALLELISM"] = "1"

import asyncpg  # noqa: E402
import httpx  # noqa: E402
import pytest  # noqa: E402
import pytest_asyncio  # noqa: E402

from app.core.config import get_settings  # noqa: E402
from app.core.db import engine  # noqa: E402
from app.core.security import hash_password  # noqa: E402
from app.main import app  # noqa: E402

MIGRATIONS = sorted((Path(__file__).resolve().parents[2] / "db/migrations").glob("*.up.sql"))
ORIGIN = "http://localhost:3000"
PASSWORD = "correct-horse-battery"


def raw_dsn() -> str:
    return get_settings().database_url.replace("postgresql+asyncpg", "postgresql")


@pytest_asyncio.fixture(scope="session", autouse=True)
async def _database():
    conn = await asyncpg.connect(raw_dsn())
    name = await conn.fetchval("SELECT current_database()")
    assert name.endswith("_test"), f"refusing to wipe database {name!r}"
    await conn.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public;")
    for migration in MIGRATIONS:
        await conn.execute(migration.read_text())
    await conn.close()
    yield
    await engine.dispose()


@pytest_asyncio.fixture
async def pg():
    conn = await asyncpg.connect(raw_dsn())
    yield conn
    await conn.close()


@pytest.fixture
def new_client():
    """Each client has its own cookie jar, i.e. behaves like a separate device."""
    clients = []

    def make(origin: str | None = ORIGIN) -> httpx.AsyncClient:
        headers = {"Origin": origin} if origin else {}
        c = httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="https://test", headers=headers
        )
        clients.append(c)
        return c

    yield make


@pytest_asyncio.fixture
async def make_user(pg):
    async def _make(role: str = "EMPLOYEE", password: str = PASSWORD, password_hash: str | None = None):
        email = f"{role.lower()}-{uuid.uuid4().hex[:10]}@leadtest.com"
        user_id = await pg.fetchval(
            "INSERT INTO users (email, full_name, role, password_hash) "
            "VALUES ($1, $2, $3::user_role, $4) RETURNING id",
            email,
            f"Test {role.title()}",
            role,
            password_hash or await hash_password(password),
        )
        return {"id": user_id, "email": email, "password": password}

    return _make


async def do_login(client: httpx.AsyncClient, email: str, password: str) -> httpx.Response:
    return await client.post("/api/auth/login", json={"email": email, "password": password})


@pytest_asyncio.fixture
async def manager_client(new_client, make_user):
    user = await make_user("SYSTEM_MANAGER")
    client = new_client()
    r = await do_login(client, user["email"], user["password"])
    assert r.status_code == 200, r.text
    client.user = user
    return client


@pytest_asyncio.fixture
async def employee_client(new_client, make_user):
    user = await make_user("EMPLOYEE")
    client = new_client()
    r = await do_login(client, user["email"], user["password"])
    assert r.status_code == 200, r.text
    client.user = user
    return client

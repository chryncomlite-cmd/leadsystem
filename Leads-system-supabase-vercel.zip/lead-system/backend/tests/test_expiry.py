"""expire_due_leads() (migration 003) and the Vercel-cron fallback endpoint."""
import importlib

from tests.helpers import login_client, new_phone, seed_lead


async def test_expires_only_due_leads(pg, make_user):
    emp = await make_user("EMPLOYEE")
    due = await seed_lead(pg, emp, age_days=21.5, status="PENDING", notes="called twice")
    fresh = await seed_lead(pg, emp, age_days=3)

    expired = await pg.fetchval("SELECT expire_due_leads()")
    assert expired >= 1

    d = await pg.fetchrow("SELECT state, assigned_employee_id, expired_at FROM leads WHERE id=$1", due)
    assert d["state"] == "EXPIRED" and d["assigned_employee_id"] is None and d["expired_at"]
    f = await pg.fetchrow("SELECT state, assigned_employee_id FROM leads WHERE id=$1", fresh)
    assert f["state"] == "ACTIVE" and f["assigned_employee_id"] == emp["id"]


async def test_archive_snapshot_history_and_side_effects(pg, make_user):
    emp = await make_user("EMPLOYEE")
    lead = await seed_lead(pg, emp, age_days=22, status="SAVING", notes="hot lead")
    await pg.execute(
        "INSERT INTO calendar_events (lead_id, employee_id, kind, starts_at) "
        "VALUES ($1,$2,'DAY_20_WARNING', now())", lead, emp["id"],
    )

    await pg.fetchval("SELECT expire_due_leads()")

    a = await pg.fetchrow("SELECT * FROM expired_clients_archive WHERE lead_id=$1", lead)
    assert a["previous_owner_id"] == emp["id"]
    assert a["previous_owner_name"] == "Test Employee"
    assert a["status_at_expiry"] == "SAVING" and a["notes"] == "hot lead"
    assert a["reassigned_at"] is None
    import json
    history = json.loads(a["ownership_history"])
    assert len(history) == 1 and history[0]["employee_id"] == str(emp["id"])

    open_rows = await pg.fetchval(
        "SELECT count(*) FROM lead_assignments WHERE lead_id=$1 AND ended_at IS NULL", lead
    )
    assert open_rows == 0
    assert await pg.fetchval(
        "SELECT end_reason::text FROM lead_assignments WHERE lead_id=$1", lead
    ) == "EXPIRED"
    assert await pg.fetchval(
        "SELECT sync::text FROM calendar_events WHERE lead_id=$1", lead
    ) == "CANCELLED"
    assert await pg.fetchval(
        "SELECT count(*) FROM lead_activities WHERE lead_id=$1 AND kind='EXPIRED'", lead
    ) == 1


async def test_is_idempotent_and_logs_the_run(pg, make_user):
    emp = await make_user("EMPLOYEE")
    lead = await seed_lead(pg, emp, age_days=25)
    await pg.fetchval("SELECT expire_due_leads()")
    assert await pg.fetchval("SELECT expire_due_leads()") == 0
    assert await pg.fetchval("SELECT count(*) FROM expired_clients_archive WHERE lead_id=$1", lead) == 1
    run = await pg.fetchrow("SELECT * FROM worker_runs WHERE job='expire_leads' ORDER BY id DESC LIMIT 1")
    assert run["finished_at"] is not None and run["error"] is None


async def test_expired_lead_can_be_claimed_after_worker_run(pg, make_user, new_client):
    owner = await make_user("EMPLOYEE")
    claimer = await make_user("EMPLOYEE")
    phone = new_phone()
    lead = await seed_lead(pg, owner, age_days=22, phone=phone)
    await pg.fetchval("SELECT expire_due_leads()")

    client = await login_client(new_client, claimer)
    r = await client.post("/api/leads", json={"client_name": "Same Client", "phone": phone})
    assert r.status_code == 201, r.text
    assert r.json()["source"] == "CLAIMED" and r.json()["id"] == str(lead)
    assert await pg.fetchval(
        "SELECT reassigned_to FROM expired_clients_archive WHERE lead_id=$1", lead
    ) == claimer["id"]


async def test_batches_drain_everything(pg, make_user):
    emp = await make_user("EMPLOYEE")
    ids = [await seed_lead(pg, emp, age_days=23) for _ in range(5)]
    assert await pg.fetchval("SELECT expire_due_leads(2)") >= 5
    left = await pg.fetchval("SELECT count(*) FROM leads WHERE id = ANY($1) AND state='ACTIVE'", ids)
    assert left == 0


async def test_rls_enabled_on_every_table(pg):
    rows = await pg.fetch(
        "SELECT relname FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace "
        "WHERE n.nspname='public' AND c.relkind='r' AND NOT c.relrowsecurity "
        "AND relname <> 'schema_migrations'"
    )
    assert [r["relname"] for r in rows] == []


# ---------------------------------------------------------------- cron endpoint
async def test_cron_endpoint(pg, make_user, new_client, monkeypatch):
    from app.routers import cron as cron_mod
    from pydantic import SecretStr

    emp = await make_user("EMPLOYEE")
    lead = await seed_lead(pg, emp, age_days=22)
    client = new_client(origin=None)

    monkeypatch.setattr(cron_mod.settings, "cron_secret", None)
    assert (await client.get("/api/cron/expire")).status_code == 404  # not configured

    monkeypatch.setattr(cron_mod.settings, "cron_secret", SecretStr("s" * 40))
    assert (await client.get("/api/cron/expire")).status_code == 401
    assert (await client.get("/api/cron/expire", headers={"Authorization": "Bearer nope"})).status_code == 401

    r = await client.get("/api/cron/expire", headers={"Authorization": "Bearer " + "s" * 40})
    assert r.status_code == 200 and r.json()["expired"] >= 1
    assert await pg.fetchval("SELECT state::text FROM leads WHERE id=$1", lead) == "EXPIRED"


# ---------------------------------------------------------------- db url handling
def test_supabase_url_handling(monkeypatch):
    import app.core.config as config
    import app.core.db as db

    monkeypatch.setattr(db.settings, "database_url",
        config.Settings.model_validate({
            "jwt_secret": "x" * 40,
            "database_url": "postgresql://postgres.abc:p%40ss@aws-0-eu-west-1.pooler.supabase.com:6543/postgres?sslmode=require",
        }).database_url)
    url, kwargs = db.build_engine_args()
    assert url.startswith("postgresql+asyncpg://postgres.abc:p%40ss@") and "sslmode" not in url
    ca = kwargs["connect_args"]
    assert ca["ssl"] == "require" and ca["statement_cache_size"] == 0
    assert callable(ca["prepared_statement_name_func"])

    monkeypatch.setattr(db.settings, "database_url", "postgresql+asyncpg://u:p@localhost:5432/x")
    _, kwargs = db.build_engine_args()
    assert kwargs["connect_args"] == {} and kwargs["pool_size"] == db.settings.db_pool_size

import time

import jwt
import pytest
from argon2 import PasswordHasher, Type

from app.core.config import Settings
from app.core.security import (
    create_access_token,
    decode_access_token,
    hash_password,
    needs_rehash,
    verify_password,
)

SECRET = "test-secret-" + "x" * 40


def test_default_argon2_parameters_are_high_cost(monkeypatch):
    for var in ("ARGON2_MEMORY_KIB", "ARGON2_TIME_COST", "ARGON2_PARALLELISM"):
        monkeypatch.delenv(var, raising=False)
    s = Settings(_env_file=None, jwt_secret=SECRET)
    assert (s.argon2_memory_kib, s.argon2_time_cost, s.argon2_parallelism) == (65536, 3, 2)

    hasher = PasswordHasher(
        time_cost=s.argon2_time_cost,
        memory_cost=s.argon2_memory_kib,
        parallelism=s.argon2_parallelism,
        type=Type.ID,
    )
    assert hasher.hash("some password").startswith("$argon2id$v=19$m=65536,t=3,p=2$")


async def test_every_hash_has_its_own_salt():
    a = await hash_password("same-password-123")
    b = await hash_password("same-password-123")
    assert a != b
    assert a.split("$")[4] != b.split("$")[4]  # the salt segment differs
    assert await verify_password(a, "same-password-123")
    assert await verify_password(b, "same-password-123")


async def test_wrong_password_and_garbage_hash_fail_closed():
    h = await hash_password("right-password-123")
    assert not await verify_password(h, "wrong-password-123")
    assert not await verify_password("not-a-hash", "right-password-123")


async def test_needs_rehash_detects_weaker_parameters():
    weak = PasswordHasher(time_cost=1, memory_cost=1024, parallelism=1, type=Type.ID).hash("x" * 12)
    assert needs_rehash(weak)
    assert not needs_rehash(await hash_password("x" * 12))


def test_token_round_trip():
    claims = decode_access_token(create_access_token("11111111-1111-1111-1111-111111111111", "EMPLOYEE", 3))
    assert claims["sub"] == "11111111-1111-1111-1111-111111111111"
    assert claims["tv"] == 3


def test_token_rejects_tampering_expiry_and_alg_none():
    good = create_access_token("11111111-1111-1111-1111-111111111111", "EMPLOYEE", 0)
    payload = {"sub": "x", "tv": 0, "iat": int(time.time())}

    with pytest.raises(jwt.InvalidTokenError):
        decode_access_token(good[:-3] + ("aaa" if not good.endswith("aaa") else "bbb"))
    with pytest.raises(jwt.InvalidTokenError):
        decode_access_token(jwt.encode({**payload, "exp": int(time.time()) - 5}, SECRET, "HS256"))
    with pytest.raises(jwt.InvalidTokenError):
        decode_access_token(jwt.encode({**payload, "exp": int(time.time()) + 60}, "y" * 40, "HS256"))
    with pytest.raises(jwt.InvalidTokenError):
        decode_access_token(jwt.encode({**payload, "exp": int(time.time()) + 60}, None, "none"))

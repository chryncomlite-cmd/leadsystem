import asyncio
import time

import jwt
from argon2 import PasswordHasher, Type

from tests.conftest import ORIGIN, PASSWORD, do_login

SECRET = "test-secret-" + "x" * 40


# --------------------------------------------------------------------------
# Login, cookies, enumeration
# --------------------------------------------------------------------------
async def test_login_sets_httponly_secure_samesite_cookie(new_client, make_user):
    user = await make_user()
    r = await do_login(new_client(), user["email"], user["password"])
    assert r.status_code == 200
    assert r.json()["role"] == "EMPLOYEE"
    assert "password" not in r.text
    cookie = r.headers["set-cookie"].lower()
    for flag in ("httponly", "secure", "samesite=lax", "path=/"):
        assert flag in cookie


async def test_unknown_user_and_wrong_password_look_identical(new_client, make_user):
    user = await make_user()
    c = new_client()
    wrong = await do_login(c, user["email"], "definitely-not-it")
    unknown = await do_login(c, "nobody-here@leadtest.com", "definitely-not-it")
    assert wrong.status_code == unknown.status_code == 401
    assert wrong.json() == unknown.json()


async def test_unknown_user_still_pays_the_hashing_cost(new_client, monkeypatch):
    """Timing equalisation: a missing account must run a dummy Argon2 verify."""
    from app.routers import auth as auth_router

    calls = []
    real = auth_router.verify_dummy

    async def spy():
        calls.append(1)
        await real()

    monkeypatch.setattr(auth_router, "verify_dummy", spy)
    r = await do_login(new_client(), "ghost-user@leadtest.com", "whatever-password")
    assert r.status_code == 401 and calls == [1]


async def test_login_is_case_insensitive_on_email(new_client, make_user):
    user = await make_user()
    r = await do_login(new_client(), user["email"].upper(), user["password"])
    assert r.status_code == 200


async def test_lockout_after_repeated_failures_then_recovery(new_client, make_user, pg):
    user = await make_user()
    c = new_client()
    for _ in range(5):
        assert (await do_login(c, user["email"], "wrong-password-1")).status_code == 401

    blocked = await do_login(c, user["email"], user["password"])  # correct password, still refused
    assert blocked.status_code == 429
    assert int(blocked.headers["retry-after"]) > 0

    await pg.execute("UPDATE users SET locked_until = now() - interval '1 minute' WHERE id = $1", user["id"])
    ok = await do_login(c, user["email"], user["password"])
    assert ok.status_code == 200
    count = await pg.fetchval("SELECT failed_login_count FROM users WHERE id = $1", user["id"])
    assert count == 0


async def test_parallel_guesses_cannot_outrun_the_lockout(new_client, make_user, pg):
    user = await make_user()
    results = await asyncio.gather(
        *[do_login(new_client(), user["email"], f"guess-number-{i:02d}") for i in range(20)]
    )
    codes = sorted(r.status_code for r in results)
    assert codes.count(401) == 5 and codes.count(429) == 15


async def test_concurrent_logins_all_succeed(new_client, make_user):
    users = [await make_user() for _ in range(30)]
    results = await asyncio.gather(*[do_login(new_client(), u["email"], u["password"]) for u in users])
    assert all(r.status_code == 200 for r in results)


async def test_hash_is_upgraded_on_login_when_parameters_were_weaker(new_client, make_user, pg):
    weak = PasswordHasher(time_cost=1, memory_cost=1024, parallelism=1, type=Type.ID).hash(PASSWORD)
    user = await make_user(password_hash=weak)
    assert (await do_login(new_client(), user["email"], PASSWORD)).status_code == 200
    stored = await pg.fetchval("SELECT password_hash FROM users WHERE id = $1", user["id"])
    assert stored != weak and "m=8192,t=2,p=1" in stored


async def test_audit_log_records_success_and_failure(new_client, make_user, pg):
    user = await make_user()
    c = new_client()
    await do_login(c, user["email"], "wrong-password-1")
    await do_login(c, user["email"], user["password"])
    actions = await pg.fetch(
        "SELECT action FROM audit_log WHERE actor_id = $1 ORDER BY id", user["id"]
    )
    assert [a["action"] for a in actions] == ["LOGIN_FAILED", "LOGIN"]


# --------------------------------------------------------------------------
# Sessions: forged tokens, origin guard
# --------------------------------------------------------------------------
async def test_requests_without_or_with_forged_tokens_are_rejected(new_client, make_user):
    user = await make_user()
    c = new_client()
    assert (await c.get("/api/auth/me")).status_code == 401

    now = int(time.time())
    base = {"sub": str(user["id"]), "tv": 0, "iat": now}
    forged = {
        "expired": jwt.encode({**base, "exp": now - 10}, SECRET, "HS256"),
        "wrong_secret": jwt.encode({**base, "exp": now + 600}, "z" * 40, "HS256"),
        "alg_none": jwt.encode({**base, "exp": now + 600}, None, "none"),
        "garbage": "not.a.jwt",
    }
    for name, token in forged.items():
        r = await c.get("/api/auth/me", headers={"Cookie": f"lead_session={token}"})
        assert r.status_code == 401, name


async def test_token_for_a_deleted_user_is_rejected(employee_client, pg):
    assert (await employee_client.get("/api/auth/me")).status_code == 200
    await pg.execute("DELETE FROM users WHERE id = $1", employee_client.user["id"])
    assert (await employee_client.get("/api/auth/me")).status_code == 401


async def test_origin_guard_blocks_cross_site_writes(new_client, make_user):
    user = await make_user()
    body = {"email": user["email"], "password": user["password"]}

    assert (await new_client(origin=None).post("/api/auth/login", json=body)).status_code == 403
    assert (await new_client(origin="https://evil.example").post("/api/auth/login", json=body)).status_code == 403
    assert (await new_client(origin=ORIGIN).post("/api/auth/login", json=body)).status_code == 200
    # Referer is accepted when Origin is absent
    c = new_client(origin=None)
    assert (await c.post("/api/auth/login", json=body, headers={"Referer": ORIGIN + "/login"})).status_code == 200
    # safe methods are unaffected
    assert (await new_client(origin=None).get("/healthz")).status_code == 200


async def test_security_headers_present(new_client):
    r = await new_client().get("/api/auth/me")
    assert r.headers["cache-control"] == "no-store"
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"


# --------------------------------------------------------------------------
# RBAC
# --------------------------------------------------------------------------
async def test_employee_is_forbidden_from_manager_routes(employee_client, manager_client, new_client):
    assert (await new_client().get("/api/manager/users")).status_code == 401
    assert (await employee_client.get("/api/manager/users")).status_code == 403
    assert (
        await employee_client.post(
            "/api/manager/users",
            json={"email": "x-y@leadtest.com", "full_name": "X", "password": PASSWORD},
        )
    ).status_code == 403
    assert (await manager_client.get("/api/manager/users")).status_code == 200


async def test_demoted_manager_loses_access_immediately(manager_client, pg):
    assert (await manager_client.get("/api/manager/users")).status_code == 200
    await pg.execute(
        "UPDATE users SET role = 'EMPLOYEE' WHERE id = $1", manager_client.user["id"]
    )
    assert (await manager_client.get("/api/manager/users")).status_code == 403


# --------------------------------------------------------------------------
# User administration
# --------------------------------------------------------------------------
async def test_manager_creates_employee_who_can_log_in(manager_client, new_client):
    r = await manager_client.post(
        "/api/manager/users",
        json={"email": "New.Hire@leadtest.com", "full_name": " New Hire ", "password": "a-long-enough-pass"},
    )
    assert r.status_code == 201, r.text
    assert r.json()["role"] == "EMPLOYEE" and r.json()["full_name"] == "New Hire"
    assert "password" not in r.text

    dup = await manager_client.post(
        "/api/manager/users",
        json={"email": "new.hire@leadtest.com", "full_name": "Dup", "password": "a-long-enough-pass"},
    )
    assert dup.status_code == 409

    assert (await do_login(new_client(), "new.hire@leadtest.com", "a-long-enough-pass")).status_code == 200


async def test_password_policy_is_enforced(manager_client):
    short = await manager_client.post(
        "/api/manager/users",
        json={"email": "short@leadtest.com", "full_name": "S", "password": "tooshort"},
    )
    same = await manager_client.post(
        "/api/manager/users",
        json={"email": "same-as-email@leadtest.com", "full_name": "S", "password": "same-as-email@leadtest.com"},
    )
    assert short.status_code == 422 and same.status_code == 422


async def test_deactivation_ends_live_sessions_and_blocks_login(employee_client, manager_client, new_client):
    uid = employee_client.user["id"]
    assert (await employee_client.get("/api/auth/me")).status_code == 200

    r = await manager_client.patch(f"/api/manager/users/{uid}/active", json={"is_active": False})
    assert r.status_code == 200 and r.json()["is_active"] is False

    assert (await employee_client.get("/api/auth/me")).status_code == 401
    assert (await do_login(new_client(), employee_client.user["email"], PASSWORD)).status_code == 401

    await manager_client.patch(f"/api/manager/users/{uid}/active", json={"is_active": True})
    assert (await do_login(new_client(), employee_client.user["email"], PASSWORD)).status_code == 200


async def test_manager_cannot_deactivate_self_and_unknown_user_is_404(manager_client):
    own = manager_client.user["id"]
    assert (await manager_client.patch(f"/api/manager/users/{own}/active", json={"is_active": False})).status_code == 400
    missing = "00000000-0000-0000-0000-00000000dead"
    assert (await manager_client.patch(f"/api/manager/users/{missing}/active", json={"is_active": True})).status_code == 404


async def test_manager_password_reset_revokes_sessions_and_unlocks(employee_client, manager_client, new_client, pg):
    uid = employee_client.user["id"]
    await pg.execute("UPDATE users SET locked_until = now() + interval '10 minutes' WHERE id = $1", uid)

    r = await manager_client.put(f"/api/manager/users/{uid}/password", json={"new_password": "brand-new-password-1"})
    assert r.status_code == 200

    assert (await employee_client.get("/api/auth/me")).status_code == 401  # old session gone
    assert (await do_login(new_client(), employee_client.user["email"], "brand-new-password-1")).status_code == 200


async def test_list_users_filters(manager_client, employee_client):
    r = await manager_client.get("/api/manager/users", params={"role": "EMPLOYEE", "is_active": "true"})
    assert r.status_code == 200
    users = r.json()
    assert users and all(u["role"] == "EMPLOYEE" and u["is_active"] for u in users)
    assert any(u["id"] == str(employee_client.user["id"]) for u in users)


# --------------------------------------------------------------------------
# Session lifecycle
# --------------------------------------------------------------------------
async def test_password_change_signs_out_other_devices(make_user, new_client):
    user = await make_user()
    laptop, phone = new_client(), new_client()
    await do_login(laptop, user["email"], user["password"])
    await do_login(phone, user["email"], user["password"])

    r = await laptop.post(
        "/api/auth/change-password",
        json={"current_password": user["password"], "new_password": "a-new-strong-password"},
    )
    assert r.status_code == 200

    assert (await laptop.get("/api/auth/me")).status_code == 200  # got a fresh cookie
    assert (await phone.get("/api/auth/me")).status_code == 401
    assert (await do_login(new_client(), user["email"], user["password"])).status_code == 401
    assert (await do_login(new_client(), user["email"], "a-new-strong-password")).status_code == 200


async def test_change_password_needs_correct_current_password(employee_client):
    r = await employee_client.post(
        "/api/auth/change-password",
        json={"current_password": "wrong-current-pass", "new_password": "a-new-strong-password"},
    )
    assert r.status_code == 400


async def test_logout_clears_cookie_and_logout_all_revokes_every_device(make_user, new_client):
    user = await make_user()
    a, b = new_client(), new_client()
    await do_login(a, user["email"], user["password"])
    await do_login(b, user["email"], user["password"])

    out = await a.post("/api/auth/logout")
    assert out.status_code == 204 and "max-age=0" in out.headers["set-cookie"].lower()
    assert (await a.get("/api/auth/me")).status_code == 401
    assert (await b.get("/api/auth/me")).status_code == 200  # plain logout is per-device

    assert (await b.post("/api/auth/logout-all")).status_code == 204
    c = new_client()
    await do_login(c, user["email"], user["password"])
    assert (await c.get("/api/auth/me")).status_code == 200


async def test_refresh_reissues_but_honours_absolute_session_limit(employee_client, new_client):
    assert (await employee_client.post("/api/auth/refresh")).status_code == 200

    now = int(time.time())
    old_login = jwt.encode(
        {"sub": str(employee_client.user["id"]), "tv": 0, "at": now - 13 * 3600, "iat": now, "exp": now + 600},
        SECRET,
        "HS256",
    )
    r = await new_client().post("/api/auth/refresh", headers={"Cookie": f"lead_session={old_login}"})
    assert r.status_code == 401

"""Create the first SYSTEM_MANAGER account.

    python -m scripts.create_manager --email boss@company.com --name "Jane Doe"

The password is read from the MANAGER_PASSWORD environment variable or prompted
for (hidden). It is never accepted on the command line.
"""
import argparse
import asyncio
import getpass
import os
import sys

from sqlalchemy import text

from app.core.config import get_settings
from app.core.db import SessionLocal, engine
from app.core.security import hash_password


async def main(email: str, name: str) -> int:
    settings = get_settings()
    password = os.environ.get("MANAGER_PASSWORD") or getpass.getpass("Password: ")
    if len(password) < settings.min_password_length:
        print(f"Password must be at least {settings.min_password_length} characters", file=sys.stderr)
        return 1

    password_hash = await hash_password(password)
    async with SessionLocal() as db:
        row = (
            await db.execute(
                text(
                    """
                    INSERT INTO users (email, full_name, role, password_hash)
                    VALUES (CAST(CAST(:email AS text) AS citext), :name, 'SYSTEM_MANAGER', :hash)
                    ON CONFLICT (email) DO NOTHING
                    RETURNING id
                    """
                ),
                {"email": email, "name": name, "hash": password_hash},
            )
        ).first()
        await db.commit()
    await engine.dispose()

    if row is None:
        print(f"An account for {email} already exists; nothing changed.", file=sys.stderr)
        return 1
    print(f"Created SYSTEM_MANAGER {email} ({row[0]})")
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--email", required=True)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    sys.exit(asyncio.run(main(args.email, args.name)))

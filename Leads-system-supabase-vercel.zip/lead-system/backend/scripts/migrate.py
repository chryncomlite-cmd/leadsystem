"""Apply db/migrations/*.up.sql in order, once each (works against Supabase).

    python -m scripts.migrate              # apply everything pending
    python -m scripts.migrate --status     # show applied / pending
    python -m scripts.migrate --baseline 002   # mark 001..002 applied without running
                                               # (schema was already created by hand)

Use the Supabase *session* pooler or direct connection (port 5432) in DATABASE_URL
for this script. The transaction pooler (6543) is meant for the running API.
"""
import argparse
import asyncio
import os
import sys
from pathlib import Path

import asyncpg
from sqlalchemy.engine import make_url

MIGRATIONS = Path(__file__).resolve().parents[2] / "db" / "migrations"


def connect_kwargs() -> dict:
    raw = os.environ.get("DATABASE_URL")
    if not raw:
        sys.exit("Set DATABASE_URL (see backend/.env.example)")
    for prefix in ("postgresql+asyncpg://", "postgres://"):
        if raw.startswith(prefix):
            raw = "postgresql://" + raw[len(prefix):]
    url = make_url(raw)
    query = dict(url.query)
    sslmode = query.get("sslmode")
    host = url.host or ""
    use_ssl = sslmode in {"require", "verify-ca", "verify-full"} or host.endswith(
        (".supabase.com", ".supabase.co")
    )
    return dict(
        host=host, port=url.port or 5432, user=url.username, password=url.password,
        database=url.database, ssl="require" if use_ssl else None,
        statement_cache_size=0,
    )


async def main(args: argparse.Namespace) -> int:
    files = sorted(MIGRATIONS.glob("*.up.sql"))
    conn = await asyncpg.connect(**connect_kwargs())
    try:
        await conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations ("
            "version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())"
        )
        done = {r["version"] for r in await conn.fetch("SELECT version FROM schema_migrations")}
        versions = {f.name.split("_", 1)[0]: f for f in files}

        if args.baseline:
            for v, f in versions.items():
                if v <= args.baseline:
                    await conn.execute(
                        "INSERT INTO schema_migrations (version) VALUES ($1) ON CONFLICT DO NOTHING", v
                    )
                    print(f"baselined {f.name}")
            return 0

        if args.status:
            for v, f in versions.items():
                print(("applied  " if v in done else "pending  ") + f.name)
            return 0

        pending = [(v, f) for v, f in versions.items() if v not in done]
        if not pending:
            print("Database is up to date.")
        for v, f in pending:
            print(f"applying {f.name} ...", flush=True)
            await conn.execute(f.read_text())  # each file wraps itself in BEGIN/COMMIT
            await conn.execute("INSERT INTO schema_migrations (version) VALUES ($1)", v)
        return 0
    finally:
        await conn.close()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--status", action="store_true")
    p.add_argument("--baseline", metavar="VERSION")
    sys.exit(asyncio.run(main(p.parse_args())))

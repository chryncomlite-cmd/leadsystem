-- Run ONCE in the Supabase SQL Editor, after enabling the pg_cron extension
-- (Dashboard -> Database -> Extensions -> pg_cron).
-- Expires due leads every hour, on the hour, inside the database.
-- No Vercel cron plan limits, no HTTP hop, no secrets.

SELECT cron.schedule(
  'expire-leads-hourly',
  '0 * * * *',
  $$ SELECT public.expire_due_leads(); $$
);

-- Check it:   SELECT * FROM cron.job;
-- History:    SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 10;
-- Remove:     SELECT cron.unschedule('expire-leads-hourly');

-- Migration 002 rollback (restores the 001 view; leaves the pg_trgm extension installed)
BEGIN;

DROP VIEW IF EXISTS v_employee_conversion;
CREATE VIEW v_employee_conversion AS
SELECT
  u.id AS employee_id,
  u.full_name,
  count(l.id)                                        AS active_leads,
  count(l.id) FILTER (WHERE l.status = 'SOLVED')     AS solved_leads,
  COALESCE(a.expired_count, 0)                       AS expired_leads,
  CASE WHEN count(l.id) + COALESCE(a.expired_count,0) = 0 THEN 0
       ELSE round(100.0 * count(l.id) FILTER (WHERE l.status = 'SOLVED')
            / (count(l.id) + COALESCE(a.expired_count,0)), 1) END AS conversion_pct
FROM users u
LEFT JOIN leads l ON l.assigned_employee_id = u.id AND l.state = 'ACTIVE'
LEFT JOIN (
  SELECT previous_owner_id, count(*) AS expired_count
  FROM expired_clients_archive GROUP BY previous_owner_id
) a ON a.previous_owner_id = u.id
WHERE u.role = 'EMPLOYEE'
GROUP BY u.id, u.full_name, a.expired_count;

DROP INDEX IF EXISTS idx_archive_name_trgm;
DROP INDEX IF EXISTS idx_leads_phone_trgm;
DROP INDEX IF EXISTS idx_leads_name_trgm;

COMMIT;

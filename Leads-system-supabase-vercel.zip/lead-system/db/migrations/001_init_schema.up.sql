-- =====================================================================
-- Lead Follow-Up & Ownership Management System
-- Migration 001: core schema (PostgreSQL 15+)
-- =====================================================================
BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS citext;     -- case-insensitive email

-- ---------------------------------------------------------------------
-- ENUMS
-- ---------------------------------------------------------------------
CREATE TYPE user_role         AS ENUM ('EMPLOYEE', 'SYSTEM_MANAGER');
CREATE TYPE lead_state        AS ENUM ('ACTIVE', 'EXPIRED');            -- ownership lifecycle
CREATE TYPE lead_status       AS ENUM ('NEW', 'PENDING', 'SAVING', 'SOLVED'); -- sales pipeline
CREATE TYPE assignment_source AS ENUM ('ENTERED', 'CLAIMED', 'ASSIGNED', 'REASSIGNED');
CREATE TYPE assignment_end    AS ENUM ('EXPIRED', 'REASSIGNED', 'MANAGER_REMOVED');
CREATE TYPE calendar_kind     AS ENUM ('DAY_1', 'DAY_7', 'DAY_14', 'DAY_20_WARNING');
CREATE TYPE sync_status       AS ENUM ('PENDING', 'SYNCED', 'FAILED', 'CANCELLED');

-- ---------------------------------------------------------------------
-- Generic updated_at trigger
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END $$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- USERS
-- password_hash stores the full Argon2id encoded string
-- ($argon2id$v=19$m=...,t=...,p=...$<unique salt>$<hash>), so every
-- account carries its own random salt and its own cost parameters.
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email              citext NOT NULL UNIQUE,
  full_name          text   NOT NULL,
  role               user_role NOT NULL DEFAULT 'EMPLOYEE',
  password_hash      text   NOT NULL,
  is_active          boolean NOT NULL DEFAULT true,
  failed_login_count integer NOT NULL DEFAULT 0,
  locked_until       timestamptz,
  last_login_at      timestamptz,
  token_version      integer NOT NULL DEFAULT 0,   -- bump to revoke all JWTs/sessions
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_role_active ON users (role) WHERE is_active;
CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------
-- LEADS
-- state  = ownership lifecycle (ACTIVE / EXPIRED)
-- status = pipeline stage (NEW / PENDING / SAVING / SOLVED)
-- entered_at = when the lead was first captured (never changes)
-- assigned_at = start of the current 21-day window (resets on reassign)
-- expires_at = assigned_at + 21 days  => visible through day 21, gone day 22
-- ---------------------------------------------------------------------
CREATE TABLE leads (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name           text NOT NULL,
  phone                 text NOT NULL,
  phone_normalized      text NOT NULL,           -- digits only, set by API; duplicate guard
  email                 citext,
  notes                 text,
  status                lead_status NOT NULL DEFAULT 'NEW',
  state                 lead_state  NOT NULL DEFAULT 'ACTIVE',
  assigned_employee_id  uuid REFERENCES users(id) ON DELETE RESTRICT,
  created_by            uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  entered_at            timestamptz NOT NULL DEFAULT now(),
  assigned_at           timestamptz NOT NULL DEFAULT now(),
  expires_at            timestamptz NOT NULL,
  solved_at             timestamptz,
  expired_at            timestamptz,
  version               integer NOT NULL DEFAULT 1,   -- optimistic locking
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),

  -- ACTIVE leads must have an owner; EXPIRED leads must not.
  CONSTRAINT chk_owner_matches_state CHECK (
    (state = 'ACTIVE'  AND assigned_employee_id IS NOT NULL AND expired_at IS NULL) OR
    (state = 'EXPIRED' AND assigned_employee_id IS NULL     AND expired_at IS NOT NULL)
  ),
  CONSTRAINT chk_solved_timestamp CHECK (
    (status = 'SOLVED') = (solved_at IS NOT NULL)
  )
);

-- expires_at is maintained by trigger (timestamptz + interval is not
-- IMMUTABLE, so a GENERATED column is not permitted).
CREATE OR REPLACE FUNCTION leads_set_expiry() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' OR NEW.assigned_at IS DISTINCT FROM OLD.assigned_at THEN
    NEW.expires_at = NEW.assigned_at + interval '21 days';
  END IF;
  IF NEW.status = 'SOLVED' AND (TG_OP = 'INSERT' OR OLD.status <> 'SOLVED') THEN
    NEW.solved_at = COALESCE(NEW.solved_at, now());
  ELSIF NEW.status <> 'SOLVED' THEN
    NEW.solved_at = NULL;
  END IF;
  IF TG_OP = 'UPDATE' THEN
    NEW.version = OLD.version + 1;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_leads_expiry BEFORE INSERT OR UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION leads_set_expiry();
CREATE TRIGGER trg_leads_updated BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Employee dashboard: "my active leads, soonest expiry first"
CREATE INDEX idx_leads_owner_active
  ON leads (assigned_employee_id, expires_at) WHERE state = 'ACTIVE';
-- Expiration worker: range scan on due leads only
CREATE INDEX idx_leads_due_for_expiry
  ON leads (expires_at) WHERE state = 'ACTIVE';
-- Manager stats / filters
CREATE INDEX idx_leads_state_status ON leads (state, status);
CREATE INDEX idx_leads_entered_at   ON leads (entered_at DESC);
-- Prevent two employees owning the same client simultaneously
CREATE UNIQUE INDEX uq_leads_active_phone
  ON leads (phone_normalized) WHERE state = 'ACTIVE';

-- ---------------------------------------------------------------------
-- LEAD ASSIGNMENTS (full ownership history)
-- ---------------------------------------------------------------------
CREATE TABLE lead_assignments (
  id           bigserial PRIMARY KEY,
  lead_id      uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  employee_id  uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  assigned_by  uuid REFERENCES users(id) ON DELETE SET NULL,  -- NULL = system
  source       assignment_source NOT NULL,
  assigned_at  timestamptz NOT NULL DEFAULT now(),
  ended_at     timestamptz,
  end_reason   assignment_end,
  CONSTRAINT chk_end_pair CHECK ((ended_at IS NULL) = (end_reason IS NULL))
);
CREATE INDEX idx_assignments_lead     ON lead_assignments (lead_id, assigned_at DESC);
CREATE INDEX idx_assignments_employee ON lead_assignments (employee_id, assigned_at DESC);
CREATE UNIQUE INDEX uq_assignments_one_open
  ON lead_assignments (lead_id) WHERE ended_at IS NULL;

-- ---------------------------------------------------------------------
-- EXPIRED CLIENTS ARCHIVE
-- ---------------------------------------------------------------------
CREATE TABLE expired_clients_archive (
  id                   bigserial PRIMARY KEY,
  lead_id              uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  client_name          text NOT NULL,
  phone                text NOT NULL,
  email                citext,
  notes                text,
  status_at_expiry     lead_status NOT NULL,
  previous_owner_id    uuid REFERENCES users(id) ON DELETE SET NULL,
  previous_owner_name  text NOT NULL,                 -- denormalised snapshot
  entered_at           timestamptz NOT NULL,
  assigned_at          timestamptz NOT NULL,
  expired_at           timestamptz NOT NULL DEFAULT now(),
  ownership_history    jsonb NOT NULL DEFAULT '[]'::jsonb,  -- all prior owners
  -- filled when a manager reassigns the lead back into circulation
  reassigned_at        timestamptz,
  reassigned_to        uuid REFERENCES users(id) ON DELETE SET NULL,
  reassigned_by        uuid REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT chk_reassign_triplet CHECK (
    (reassigned_at IS NULL) = (reassigned_to IS NULL)
  )
);
CREATE INDEX idx_archive_expired_at ON expired_clients_archive (expired_at DESC);
CREATE INDEX idx_archive_prev_owner ON expired_clients_archive (previous_owner_id, expired_at DESC);
CREATE INDEX idx_archive_lead       ON expired_clients_archive (lead_id);
CREATE INDEX idx_archive_open       ON expired_clients_archive (expired_at DESC)
  WHERE reassigned_at IS NULL;

-- ---------------------------------------------------------------------
-- LEAD ACTIVITIES (follow-up log: calls, notes, status changes)
-- ---------------------------------------------------------------------
CREATE TABLE lead_activities (
  id          bigserial PRIMARY KEY,
  lead_id     uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  actor_id    uuid REFERENCES users(id) ON DELETE SET NULL,  -- NULL = system
  kind        text NOT NULL,        -- CREATED | NOTE | STATUS_CHANGE | CALL | EXPIRED | REASSIGNED
  from_status lead_status,
  to_status   lead_status,
  body        text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_activities_lead ON lead_activities (lead_id, created_at DESC);

-- ---------------------------------------------------------------------
-- CALENDAR INTEGRATION
-- ---------------------------------------------------------------------
CREATE TABLE google_calendar_connections (
  user_id                 uuid PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  google_account_email    text NOT NULL,
  calendar_id             text NOT NULL DEFAULT 'primary',
  refresh_token_encrypted bytea NOT NULL,   -- AES-256-GCM, key from env/KMS, never plaintext
  scopes                  text[] NOT NULL,
  connected_at            timestamptz NOT NULL DEFAULT now(),
  revoked_at              timestamptz
);

-- Per-employee tokenised .ics feed. Only the SHA-256 of the token is stored;
-- the raw token is shown once at creation. Rotating = revoke + insert.
CREATE TABLE calendar_feed_tokens (
  id          bigserial PRIMARY KEY,
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  bytea NOT NULL UNIQUE,
  created_at  timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz,
  revoked_at  timestamptz
);
CREATE UNIQUE INDEX uq_feed_token_one_active
  ON calendar_feed_tokens (user_id) WHERE revoked_at IS NULL;

CREATE TABLE calendar_events (
  id               bigserial PRIMARY KEY,
  lead_id          uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  employee_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind             calendar_kind NOT NULL,
  starts_at        timestamptz NOT NULL,
  google_event_id  text,
  sync             sync_status NOT NULL DEFAULT 'PENDING',
  attempts         integer NOT NULL DEFAULT 0,
  last_error       text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (lead_id, employee_id, kind)
);
CREATE INDEX idx_calevents_employee_time ON calendar_events (employee_id, starts_at);
CREATE INDEX idx_calevents_pending       ON calendar_events (created_at) WHERE sync IN ('PENDING','FAILED');
CREATE TRIGGER trg_calevents_updated BEFORE UPDATE ON calendar_events
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------
-- AUDIT LOG & WORKER RUNS
-- ---------------------------------------------------------------------
CREATE TABLE audit_log (
  id          bigserial PRIMARY KEY,
  actor_id    uuid REFERENCES users(id) ON DELETE SET NULL,
  action      text NOT NULL,           -- LOGIN, LOGIN_FAILED, LEAD_REASSIGN, ARCHIVE_VIEW ...
  entity_type text,
  entity_id   text,
  ip          inet,
  details     jsonb,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_actor_time  ON audit_log (actor_id, created_at DESC);
CREATE INDEX idx_audit_entity      ON audit_log (entity_type, entity_id);

CREATE TABLE worker_runs (
  id            bigserial PRIMARY KEY,
  job           text NOT NULL,
  started_at    timestamptz NOT NULL DEFAULT now(),
  finished_at   timestamptz,
  processed     integer NOT NULL DEFAULT 0,
  error         text
);
CREATE INDEX idx_worker_runs_job ON worker_runs (job, started_at DESC);

-- ---------------------------------------------------------------------
-- MANAGER REPORTING VIEWS (deliverables 6, 7, 8)
-- ---------------------------------------------------------------------
-- Totals + pipeline breakdown across all clients ever tracked
CREATE VIEW v_client_totals AS
SELECT
  count(*)                                         AS total_clients,
  count(*) FILTER (WHERE status = 'SOLVED')        AS solved_clients,
  count(*) FILTER (WHERE status = 'NEW')           AS status_new,
  count(*) FILTER (WHERE status = 'PENDING')       AS status_pending,
  count(*) FILTER (WHERE status = 'SAVING')        AS status_saving,
  count(*) FILTER (WHERE state  = 'ACTIVE')        AS active_clients,
  count(*) FILTER (WHERE state  = 'EXPIRED')       AS expired_clients
FROM leads;

-- Per-employee conversion (current owner for ACTIVE rows; archive covers lost ones)
CREATE VIEW v_employee_conversion AS
SELECT
  u.id AS employee_id,
  u.full_name,
  count(l.id)                                        AS active_leads,
  count(l.id) FILTER (WHERE l.status = 'SOLVED')     AS solved_leads,
  COALESCE(a.expired_count, 0)                       AS expired_leads,
  CASE WHEN count(l.id) + COALESCE(a.expired_count,0) = 0 THEN 0
       ELSE round(100.0 * count(l.id) FILTER (WHERE l.status = 'SOLVED')
            / (count(l.id) + COALESCE(a.expired_count,0)), 1) END AS conversion_pct
FROM users u
LEFT JOIN leads l ON l.assigned_employee_id = u.id AND l.state = 'ACTIVE'
LEFT JOIN (
  SELECT previous_owner_id, count(*) AS expired_count
  FROM expired_clients_archive GROUP BY previous_owner_id
) a ON a.previous_owner_id = u.id
WHERE u.role = 'EMPLOYEE'
GROUP BY u.id, u.full_name, a.expired_count;

COMMIT;

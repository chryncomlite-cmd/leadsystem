-- Migration 001 rollback
BEGIN;

DROP VIEW IF EXISTS v_employee_conversion;
DROP VIEW IF EXISTS v_client_totals;

DROP TABLE IF EXISTS worker_runs;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS calendar_events;
DROP TABLE IF EXISTS calendar_feed_tokens;
DROP TABLE IF EXISTS google_calendar_connections;
DROP TABLE IF EXISTS lead_activities;
DROP TABLE IF EXISTS expired_clients_archive;
DROP TABLE IF EXISTS lead_assignments;
DROP TABLE IF EXISTS leads;
DROP TABLE IF EXISTS users;

DROP FUNCTION IF EXISTS leads_set_expiry();
DROP FUNCTION IF EXISTS set_updated_at();

DROP TYPE IF EXISTS sync_status;
DROP TYPE IF EXISTS calendar_kind;
DROP TYPE IF EXISTS assignment_end;
DROP TYPE IF EXISTS assignment_source;
DROP TYPE IF EXISTS lead_status;
DROP TYPE IF EXISTS lead_state;
DROP TYPE IF EXISTS user_role;

COMMIT;

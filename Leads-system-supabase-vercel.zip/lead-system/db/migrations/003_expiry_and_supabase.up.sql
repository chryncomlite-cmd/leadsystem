-- =====================================================================
-- Migration 003: Day-22 expiry job (in the database) + Supabase hardening
-- =====================================================================
BEGIN;

-- ---------------------------------------------------------------------
-- expire_due_leads(): the "hourly worker", as one atomic SQL function.
-- Every ACTIVE lead whose 21-day window has ended is snapshotted into
-- expired_clients_archive, loses its owner and becomes EXPIRED.
-- FOR UPDATE SKIP LOCKED means overlapping runs (pg_cron + Vercel cron,
-- or a retry) never block or double-process a lead.
-- Returns the number of leads expired. Safe to call at any time.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION expire_due_leads(batch_limit integer DEFAULT 2000)
RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  v_run   bigint;
  v_ids   uuid[];
  v_total integer := 0;
BEGIN
  INSERT INTO worker_runs (job) VALUES ('expire_leads') RETURNING id INTO v_run;

  LOOP
    SELECT array_agg(d.id) INTO v_ids
    FROM (
      SELECT id FROM leads
      WHERE state = 'ACTIVE' AND expires_at <= now()
      ORDER BY expires_at
      LIMIT batch_limit
      FOR UPDATE SKIP LOCKED
    ) d;

    EXIT WHEN v_ids IS NULL;

    -- 1. snapshot (must run before the owner is stripped)
    INSERT INTO expired_clients_archive
      (lead_id, client_name, phone, email, notes, status_at_expiry,
       previous_owner_id, previous_owner_name, entered_at, assigned_at,
       expired_at, ownership_history)
    SELECT l.id, l.client_name, l.phone, l.email, l.notes, l.status,
           l.assigned_employee_id, u.full_name, l.entered_at, l.assigned_at,
           now(),
           COALESCE((
             SELECT jsonb_agg(jsonb_build_object(
                      'employee_id',   a.employee_id,
                      'employee_name', au.full_name,
                      'source',        a.source,
                      'assigned_at',   a.assigned_at,
                      'ended_at',      a.ended_at,
                      'end_reason',    a.end_reason) ORDER BY a.assigned_at)
             FROM lead_assignments a JOIN users au ON au.id = a.employee_id
             WHERE a.lead_id = l.id
           ), '[]'::jsonb)
    FROM leads l JOIN users u ON u.id = l.assigned_employee_id
    WHERE l.id = ANY (v_ids);

    -- 2. close the open ownership row
    UPDATE lead_assignments SET ended_at = now(), end_reason = 'EXPIRED'
    WHERE lead_id = ANY (v_ids) AND ended_at IS NULL;

    -- 3. stop reminders (the Google sync worker deletes already-pushed copies)
    UPDATE calendar_events SET sync = 'CANCELLED'
    WHERE lead_id = ANY (v_ids) AND sync <> 'CANCELLED';

    -- 4. activity trail (actor NULL = system)
    INSERT INTO lead_activities (lead_id, actor_id, kind, body)
    SELECT unnest(v_ids), NULL, 'EXPIRED', 'Ownership ended after 21 days';

    -- 5. release the lead into the pool
    UPDATE leads
    SET state = 'EXPIRED', assigned_employee_id = NULL, expired_at = now()
    WHERE id = ANY (v_ids);

    v_total := v_total + cardinality(v_ids);
  END LOOP;

  UPDATE worker_runs SET finished_at = clock_timestamp(), processed = v_total
  WHERE id = v_run;
  RETURN v_total;
END $$;

-- ---------------------------------------------------------------------
-- Supabase exposes the `public` schema through its Data API (PostgREST)
-- using the public anon key. This app never uses that API: it talks to
-- Postgres directly. So lock the tables down completely:
--   * RLS on, with NO policies  -> anon / authenticated see zero rows
--   * all privileges revoked from those roles (views and functions too)
-- The API connects as `postgres`, which bypasses RLS, so it is unaffected.
-- On plain PostgreSQL (tests, local dev) the roles don't exist and the
-- REVOKEs are skipped.
-- ---------------------------------------------------------------------
DO $$
DECLARE
  t text;
  r text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'users', 'leads', 'lead_assignments', 'expired_clients_archive',
    'lead_activities', 'google_calendar_connections', 'calendar_feed_tokens',
    'calendar_events', 'audit_log', 'worker_runs'
  ] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
  END LOOP;

  FOREACH r IN ARRAY ARRAY['anon', 'authenticated'] LOOP
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = r) THEN
      EXECUTE format('REVOKE ALL ON ALL TABLES    IN SCHEMA public FROM %I', r);
      EXECUTE format('REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM %I', r);
      EXECUTE format('REVOKE ALL ON FUNCTION public.expire_due_leads(integer) FROM %I', r);
    END IF;
  END LOOP;
END $$;
REVOKE ALL ON FUNCTION expire_due_leads(integer) FROM PUBLIC;

COMMIT;

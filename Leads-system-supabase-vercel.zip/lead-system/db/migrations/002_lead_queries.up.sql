-- =====================================================================
-- Migration 002: search indexes and a corrected employee-conversion view
-- =====================================================================
BEGIN;

-- Fast ILIKE '%text%' search over every lead / archive row for managers
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX idx_leads_name_trgm   ON leads USING gin (client_name gin_trgm_ops);
CREATE INDEX idx_leads_phone_trgm  ON leads USING gin (phone_normalized gin_trgm_ops);
CREATE INDEX idx_archive_name_trgm ON expired_clients_archive USING gin (client_name gin_trgm_ops);

-- v_employee_conversion in 001 counted SOLVED only among ACTIVE leads. Because
-- every lead (solved or not) expires on Day 22 and moves to the archive, an
-- employee would silently lose credit for solved clients. This version credits
-- archived SOLVED leads to their previous owner.
--
--   conversion_pct        = solved / everything the employee has handled
--                           (active + archived), so in-progress leads count against it
--   closed_conversion_pct = solved / (solved + lost), only finished outcomes
DROP VIEW v_employee_conversion;
CREATE VIEW v_employee_conversion AS
WITH active AS (
  SELECT assigned_employee_id AS employee_id,
         count(*)                                  AS active_leads,
         count(*) FILTER (WHERE status = 'SOLVED') AS active_solved
  FROM leads
  WHERE state = 'ACTIVE'
  GROUP BY assigned_employee_id
), archived AS (
  SELECT previous_owner_id AS employee_id,
         count(*) FILTER (WHERE status_at_expiry = 'SOLVED')  AS archived_solved,
         count(*) FILTER (WHERE status_at_expiry <> 'SOLVED') AS lost_leads
  FROM expired_clients_archive
  WHERE previous_owner_id IS NOT NULL
  GROUP BY previous_owner_id
), per AS (
  SELECT u.id AS employee_id, u.full_name, u.email, u.is_active,
         COALESCE(a.active_leads, 0)    AS active_leads,
         COALESCE(a.active_solved, 0)   AS active_solved,
         COALESCE(r.archived_solved, 0) AS archived_solved,
         COALESCE(r.lost_leads, 0)      AS lost_leads
  FROM users u
  LEFT JOIN active   a ON a.employee_id = u.id
  LEFT JOIN archived r ON r.employee_id = u.id
  WHERE u.role = 'EMPLOYEE'
)
SELECT employee_id, full_name, email, is_active,
       active_leads,
       active_solved + archived_solved                      AS solved_leads,
       lost_leads,
       active_leads + archived_solved + lost_leads          AS total_handled,
       CASE WHEN active_leads + archived_solved + lost_leads = 0 THEN 0
            ELSE round(100.0 * (active_solved + archived_solved)
                       / (active_leads + archived_solved + lost_leads), 1) END AS conversion_pct,
       CASE WHEN active_solved + archived_solved + lost_leads = 0 THEN 0
            ELSE round(100.0 * (active_solved + archived_solved)
                       / (active_solved + archived_solved + lost_leads), 1) END AS closed_conversion_pct
FROM per;

COMMIT;

BEGIN;
DROP FUNCTION IF EXISTS expire_due_leads(integer);
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'users', 'leads', 'lead_assignments', 'expired_clients_archive',
    'lead_activities', 'google_calendar_connections', 'calendar_feed_tokens',
    'calendar_events', 'audit_log', 'worker_runs'
  ] LOOP
    EXECUTE format('ALTER TABLE public.%I DISABLE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;
COMMIT;
